/**
 */
package FiniteStateMachines.impl;

import FiniteStateMachines.FiniteStateMachinesPackage;
import FiniteStateMachines.State;
import FiniteStateMachines.Transition;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link FiniteStateMachines.impl.StateImpl#isIsEndState <em>Is End State</em>}</li>
 *   <li>{@link FiniteStateMachines.impl.StateImpl#isIsStartState <em>Is Start State</em>}</li>
 *   <li>{@link FiniteStateMachines.impl.StateImpl#getName <em>Name</em>}</li>
 *   <li>{@link FiniteStateMachines.impl.StateImpl#getTransitions <em>Transitions</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StateImpl extends EObjectImpl implements State {
	/**
	 * The default value of the '{@link #isIsEndState() <em>Is End State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsEndState()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_END_STATE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsEndState() <em>Is End State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsEndState()
	 * @generated
	 * @ordered
	 */
	protected boolean isEndState = IS_END_STATE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsStartState() <em>Is Start State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsStartState()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_START_STATE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsStartState() <em>Is Start State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsStartState()
	 * @generated
	 * @ordered
	 */
	protected boolean isStartState = IS_START_STATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTransitions() <em>Transitions</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransitions()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transitions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return FiniteStateMachinesPackage.Literals.STATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsEndState() {
		return isEndState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsEndState(boolean newIsEndState) {
		boolean oldIsEndState = isEndState;
		isEndState = newIsEndState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FiniteStateMachinesPackage.STATE__IS_END_STATE,
					oldIsEndState, isEndState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsStartState() {
		return isStartState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsStartState(boolean newIsStartState) {
		boolean oldIsStartState = isStartState;
		isStartState = newIsStartState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FiniteStateMachinesPackage.STATE__IS_START_STATE,
					oldIsStartState, isStartState));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FiniteStateMachinesPackage.STATE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransitions() {
		if (transitions == null) {
			transitions = new EObjectWithInverseResolvingEList<Transition>(Transition.class, this,
					FiniteStateMachinesPackage.STATE__TRANSITIONS, FiniteStateMachinesPackage.TRANSITION__START_STATE);
		}
		return transitions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getTransitions()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			return ((InternalEList<?>) getTransitions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__IS_END_STATE:
			return isIsEndState();
		case FiniteStateMachinesPackage.STATE__IS_START_STATE:
			return isIsStartState();
		case FiniteStateMachinesPackage.STATE__NAME:
			return getName();
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			return getTransitions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__IS_END_STATE:
			setIsEndState((Boolean) newValue);
			return;
		case FiniteStateMachinesPackage.STATE__IS_START_STATE:
			setIsStartState((Boolean) newValue);
			return;
		case FiniteStateMachinesPackage.STATE__NAME:
			setName((String) newValue);
			return;
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			getTransitions().clear();
			getTransitions().addAll((Collection<? extends Transition>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__IS_END_STATE:
			setIsEndState(IS_END_STATE_EDEFAULT);
			return;
		case FiniteStateMachinesPackage.STATE__IS_START_STATE:
			setIsStartState(IS_START_STATE_EDEFAULT);
			return;
		case FiniteStateMachinesPackage.STATE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			getTransitions().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case FiniteStateMachinesPackage.STATE__IS_END_STATE:
			return isEndState != IS_END_STATE_EDEFAULT;
		case FiniteStateMachinesPackage.STATE__IS_START_STATE:
			return isStartState != IS_START_STATE_EDEFAULT;
		case FiniteStateMachinesPackage.STATE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case FiniteStateMachinesPackage.STATE__TRANSITIONS:
			return transitions != null && !transitions.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (isEndState: ");
		result.append(isEndState);
		result.append(", isStartState: ");
		result.append(isStartState);
		result.append(", name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //StateImpl
