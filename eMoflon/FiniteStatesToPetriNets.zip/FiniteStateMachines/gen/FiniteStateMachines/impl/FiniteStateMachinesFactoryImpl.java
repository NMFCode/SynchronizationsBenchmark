/**
 */
package FiniteStateMachines.impl;

import FiniteStateMachines.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FiniteStateMachinesFactoryImpl extends EFactoryImpl implements FiniteStateMachinesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static FiniteStateMachinesFactory init() {
		try {
			FiniteStateMachinesFactory theFiniteStateMachinesFactory = (FiniteStateMachinesFactory) EPackage.Registry.INSTANCE
					.getEFactory(FiniteStateMachinesPackage.eNS_URI);
			if (theFiniteStateMachinesFactory != null) {
				return theFiniteStateMachinesFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new FiniteStateMachinesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStateMachinesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case FiniteStateMachinesPackage.FINITE_STATE_MACHINE:
			return createFiniteStateMachine();
		case FiniteStateMachinesPackage.STATE:
			return createState();
		case FiniteStateMachinesPackage.TRANSITION:
			return createTransition();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStateMachine createFiniteStateMachine() {
		FiniteStateMachineImpl finiteStateMachine = new FiniteStateMachineImpl();
		return finiteStateMachine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transition createTransition() {
		TransitionImpl transition = new TransitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStateMachinesPackage getFiniteStateMachinesPackage() {
		return (FiniteStateMachinesPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static FiniteStateMachinesPackage getPackage() {
		return FiniteStateMachinesPackage.eINSTANCE;
	}

} //FiniteStateMachinesFactoryImpl
