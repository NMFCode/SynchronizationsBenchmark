/**
 */
package FiniteStateMachines;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FiniteStateMachines.Transition#getStartState <em>Start State</em>}</li>
 *   <li>{@link FiniteStateMachines.Transition#getEndState <em>End State</em>}</li>
 *   <li>{@link FiniteStateMachines.Transition#getInput <em>Input</em>}</li>
 * </ul>
 * </p>
 *
 * @see FiniteStateMachines.FiniteStateMachinesPackage#getTransition()
 * @model
 * @generated
 */
public interface Transition extends EObject {
	/**
	 * Returns the value of the '<em><b>Start State</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link FiniteStateMachines.State#getTransitions <em>Transitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start State</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start State</em>' reference.
	 * @see #setStartState(State)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getTransition_StartState()
	 * @see FiniteStateMachines.State#getTransitions
	 * @model opposite="transitions" required="true"
	 * @generated
	 */
	State getStartState();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.Transition#getStartState <em>Start State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start State</em>' reference.
	 * @see #getStartState()
	 * @generated
	 */
	void setStartState(State value);

	/**
	 * Returns the value of the '<em><b>End State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End State</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End State</em>' reference.
	 * @see #setEndState(State)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getTransition_EndState()
	 * @model required="true"
	 * @generated
	 */
	State getEndState();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.Transition#getEndState <em>End State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End State</em>' reference.
	 * @see #getEndState()
	 * @generated
	 */
	void setEndState(State value);

	/**
	 * Returns the value of the '<em><b>Input</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Input</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input</em>' attribute.
	 * @see #setInput(String)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getTransition_Input()
	 * @model required="true"
	 * @generated
	 */
	String getInput();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.Transition#getInput <em>Input</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input</em>' attribute.
	 * @see #getInput()
	 * @generated
	 */
	void setInput(String value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Transition
