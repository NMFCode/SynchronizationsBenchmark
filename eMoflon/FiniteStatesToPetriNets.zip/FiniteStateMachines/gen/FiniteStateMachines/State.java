/**
 */
package FiniteStateMachines;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link FiniteStateMachines.State#isIsEndState <em>Is End State</em>}</li>
 *   <li>{@link FiniteStateMachines.State#isIsStartState <em>Is Start State</em>}</li>
 *   <li>{@link FiniteStateMachines.State#getName <em>Name</em>}</li>
 *   <li>{@link FiniteStateMachines.State#getTransitions <em>Transitions</em>}</li>
 * </ul>
 * </p>
 *
 * @see FiniteStateMachines.FiniteStateMachinesPackage#getState()
 * @model
 * @generated
 */
public interface State extends EObject {
	/**
	 * Returns the value of the '<em><b>Is End State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is End State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is End State</em>' attribute.
	 * @see #setIsEndState(boolean)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getState_IsEndState()
	 * @model required="true"
	 * @generated
	 */
	boolean isIsEndState();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.State#isIsEndState <em>Is End State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is End State</em>' attribute.
	 * @see #isIsEndState()
	 * @generated
	 */
	void setIsEndState(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Start State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Start State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Start State</em>' attribute.
	 * @see #setIsStartState(boolean)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getState_IsStartState()
	 * @model required="true"
	 * @generated
	 */
	boolean isIsStartState();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.State#isIsStartState <em>Is Start State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Start State</em>' attribute.
	 * @see #isIsStartState()
	 * @generated
	 */
	void setIsStartState(boolean value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getState_Name()
	 * @model id="true" required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link FiniteStateMachines.State#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Transitions</b></em>' reference list.
	 * The list contents are of type {@link FiniteStateMachines.Transition}.
	 * It is bidirectional and its opposite is '{@link FiniteStateMachines.Transition#getStartState <em>Start State</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transitions</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transitions</em>' reference list.
	 * @see FiniteStateMachines.FiniteStateMachinesPackage#getState_Transitions()
	 * @see FiniteStateMachines.Transition#getStartState
	 * @model opposite="startState"
	 * @generated
	 */
	EList<Transition> getTransitions();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // State
