/**
 */
package FiniteStatesToPetriNets;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see FiniteStatesToPetriNets.FiniteStatesToPetriNetsPackage
 * @generated
 */
public interface FiniteStatesToPetriNetsFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FiniteStatesToPetriNetsFactory eINSTANCE = FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>State To Place</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State To Place</em>'.
	 * @generated
	 */
	StateToPlace createStateToPlace();

	/**
	 * Returns a new object of class '<em>End State To Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>End State To Transition</em>'.
	 * @generated
	 */
	EndStateToTransition createEndStateToTransition();

	/**
	 * Returns a new object of class '<em>Transition To Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transition To Transition</em>'.
	 * @generated
	 */
	TransitionToTransition createTransitionToTransition();

	/**
	 * Returns a new object of class '<em>State Machine To Petri Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State Machine To Petri Net</em>'.
	 * @generated
	 */
	StateMachineToPetriNet createStateMachineToPetriNet();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	FiniteStatesToPetriNetsPackage getFiniteStatesToPetriNetsPackage();

} //FiniteStatesToPetriNetsFactory
