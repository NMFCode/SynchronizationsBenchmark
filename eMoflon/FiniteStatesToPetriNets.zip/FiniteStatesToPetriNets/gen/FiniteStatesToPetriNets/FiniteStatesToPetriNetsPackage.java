/**
 */
package FiniteStatesToPetriNets;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.moflon.tgg.runtime.RuntimePackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory
 * @model kind="package"
 * @generated
 */
public interface FiniteStatesToPetriNetsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "FiniteStatesToPetriNets";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/plugin/FiniteStatesToPetriNets/model/FiniteStatesToPetriNets.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "FiniteStatesToPetriNets";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FiniteStatesToPetriNetsPackage eINSTANCE = FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl.init();

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.impl.StateToPlaceImpl <em>State To Place</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.impl.StateToPlaceImpl
	 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getStateToPlace()
	 * @generated
	 */
	int STATE_TO_PLACE = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE__SOURCE = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE__TARGET = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>State To Place</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_FEATURE_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>State To Place</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_OPERATION_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.impl.EndStateToTransitionImpl <em>End State To Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.impl.EndStateToTransitionImpl
	 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getEndStateToTransition()
	 * @generated
	 */
	int END_STATE_TO_TRANSITION = 1;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION__SOURCE = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION__TARGET = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>End State To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION_FEATURE_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>End State To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION_OPERATION_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.impl.TransitionToTransitionImpl <em>Transition To Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.impl.TransitionToTransitionImpl
	 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getTransitionToTransition()
	 * @generated
	 */
	int TRANSITION_TO_TRANSITION = 2;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION__SOURCE = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION__TARGET = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Transition To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION_FEATURE_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Transition To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION_OPERATION_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.impl.StateMachineToPetriNetImpl <em>State Machine To Petri Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.impl.StateMachineToPetriNetImpl
	 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getStateMachineToPetriNet()
	 * @generated
	 */
	int STATE_MACHINE_TO_PETRI_NET = 3;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_TO_PETRI_NET__SOURCE = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_TO_PETRI_NET__TARGET = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>State Machine To Petri Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_TO_PETRI_NET_FEATURE_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>State Machine To Petri Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_TO_PETRI_NET_OPERATION_COUNT = RuntimePackage.ABSTRACT_CORRESPONDENCE_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.StateToPlace <em>State To Place</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State To Place</em>'.
	 * @see FiniteStatesToPetriNets.StateToPlace
	 * @generated
	 */
	EClass getStateToPlace();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.StateToPlace#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see FiniteStatesToPetriNets.StateToPlace#getSource()
	 * @see #getStateToPlace()
	 * @generated
	 */
	EReference getStateToPlace_Source();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.StateToPlace#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see FiniteStatesToPetriNets.StateToPlace#getTarget()
	 * @see #getStateToPlace()
	 * @generated
	 */
	EReference getStateToPlace_Target();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.EndStateToTransition <em>End State To Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>End State To Transition</em>'.
	 * @see FiniteStatesToPetriNets.EndStateToTransition
	 * @generated
	 */
	EClass getEndStateToTransition();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.EndStateToTransition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see FiniteStatesToPetriNets.EndStateToTransition#getSource()
	 * @see #getEndStateToTransition()
	 * @generated
	 */
	EReference getEndStateToTransition_Source();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.EndStateToTransition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see FiniteStatesToPetriNets.EndStateToTransition#getTarget()
	 * @see #getEndStateToTransition()
	 * @generated
	 */
	EReference getEndStateToTransition_Target();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.TransitionToTransition <em>Transition To Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition To Transition</em>'.
	 * @see FiniteStatesToPetriNets.TransitionToTransition
	 * @generated
	 */
	EClass getTransitionToTransition();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.TransitionToTransition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see FiniteStatesToPetriNets.TransitionToTransition#getSource()
	 * @see #getTransitionToTransition()
	 * @generated
	 */
	EReference getTransitionToTransition_Source();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.TransitionToTransition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see FiniteStatesToPetriNets.TransitionToTransition#getTarget()
	 * @see #getTransitionToTransition()
	 * @generated
	 */
	EReference getTransitionToTransition_Target();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.StateMachineToPetriNet <em>State Machine To Petri Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State Machine To Petri Net</em>'.
	 * @see FiniteStatesToPetriNets.StateMachineToPetriNet
	 * @generated
	 */
	EClass getStateMachineToPetriNet();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.StateMachineToPetriNet#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see FiniteStatesToPetriNets.StateMachineToPetriNet#getSource()
	 * @see #getStateMachineToPetriNet()
	 * @generated
	 */
	EReference getStateMachineToPetriNet_Source();

	/**
	 * Returns the meta object for the reference '{@link FiniteStatesToPetriNets.StateMachineToPetriNet#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see FiniteStatesToPetriNets.StateMachineToPetriNet#getTarget()
	 * @see #getStateMachineToPetriNet()
	 * @generated
	 */
	EReference getStateMachineToPetriNet_Target();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	FiniteStatesToPetriNetsFactory getFiniteStatesToPetriNetsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.impl.StateToPlaceImpl <em>State To Place</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.impl.StateToPlaceImpl
		 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getStateToPlace()
		 * @generated
		 */
		EClass STATE_TO_PLACE = eINSTANCE.getStateToPlace();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_TO_PLACE__SOURCE = eINSTANCE.getStateToPlace_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_TO_PLACE__TARGET = eINSTANCE.getStateToPlace_Target();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.impl.EndStateToTransitionImpl <em>End State To Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.impl.EndStateToTransitionImpl
		 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getEndStateToTransition()
		 * @generated
		 */
		EClass END_STATE_TO_TRANSITION = eINSTANCE.getEndStateToTransition();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference END_STATE_TO_TRANSITION__SOURCE = eINSTANCE.getEndStateToTransition_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference END_STATE_TO_TRANSITION__TARGET = eINSTANCE.getEndStateToTransition_Target();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.impl.TransitionToTransitionImpl <em>Transition To Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.impl.TransitionToTransitionImpl
		 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getTransitionToTransition()
		 * @generated
		 */
		EClass TRANSITION_TO_TRANSITION = eINSTANCE.getTransitionToTransition();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION_TO_TRANSITION__SOURCE = eINSTANCE.getTransitionToTransition_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION_TO_TRANSITION__TARGET = eINSTANCE.getTransitionToTransition_Target();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.impl.StateMachineToPetriNetImpl <em>State Machine To Petri Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.impl.StateMachineToPetriNetImpl
		 * @see FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl#getStateMachineToPetriNet()
		 * @generated
		 */
		EClass STATE_MACHINE_TO_PETRI_NET = eINSTANCE.getStateMachineToPetriNet();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE_TO_PETRI_NET__SOURCE = eINSTANCE.getStateMachineToPetriNet_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE_TO_PETRI_NET__TARGET = eINSTANCE.getStateMachineToPetriNet_Target();

	}

} //FiniteStatesToPetriNetsPackage
