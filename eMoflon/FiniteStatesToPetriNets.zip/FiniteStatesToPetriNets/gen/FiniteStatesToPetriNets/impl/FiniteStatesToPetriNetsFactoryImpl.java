/**
 */
package FiniteStatesToPetriNets.impl;

import FiniteStatesToPetriNets.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FiniteStatesToPetriNetsFactoryImpl extends EFactoryImpl implements FiniteStatesToPetriNetsFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static FiniteStatesToPetriNetsFactory init() {
		try {
			FiniteStatesToPetriNetsFactory theFiniteStatesToPetriNetsFactory = (FiniteStatesToPetriNetsFactory) EPackage.Registry.INSTANCE
					.getEFactory(FiniteStatesToPetriNetsPackage.eNS_URI);
			if (theFiniteStatesToPetriNetsFactory != null) {
				return theFiniteStatesToPetriNetsFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new FiniteStatesToPetriNetsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStatesToPetriNetsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case FiniteStatesToPetriNetsPackage.STATE_TO_PLACE:
			return createStateToPlace();
		case FiniteStatesToPetriNetsPackage.END_STATE_TO_TRANSITION:
			return createEndStateToTransition();
		case FiniteStatesToPetriNetsPackage.TRANSITION_TO_TRANSITION:
			return createTransitionToTransition();
		case FiniteStatesToPetriNetsPackage.STATE_MACHINE_TO_PETRI_NET:
			return createStateMachineToPetriNet();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateToPlace createStateToPlace() {
		StateToPlaceImpl stateToPlace = new StateToPlaceImpl();
		return stateToPlace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EndStateToTransition createEndStateToTransition() {
		EndStateToTransitionImpl endStateToTransition = new EndStateToTransitionImpl();
		return endStateToTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransitionToTransition createTransitionToTransition() {
		TransitionToTransitionImpl transitionToTransition = new TransitionToTransitionImpl();
		return transitionToTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateMachineToPetriNet createStateMachineToPetriNet() {
		StateMachineToPetriNetImpl stateMachineToPetriNet = new StateMachineToPetriNetImpl();
		return stateMachineToPetriNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStatesToPetriNetsPackage getFiniteStatesToPetriNetsPackage() {
		return (FiniteStatesToPetriNetsPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static FiniteStatesToPetriNetsPackage getPackage() {
		return FiniteStatesToPetriNetsPackage.eINSTANCE;
	}

} //FiniteStatesToPetriNetsFactoryImpl
