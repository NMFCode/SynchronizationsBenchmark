/**
 */
package FiniteStatesToPetriNets.impl;

import FiniteStateMachines.FiniteStateMachinesPackage;

import FiniteStatesToPetriNets.EndStateToTransition;
import FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory;
import FiniteStatesToPetriNets.FiniteStatesToPetriNetsPackage;

import FiniteStatesToPetriNets.Rules.RulesPackage;

import FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl;

import FiniteStatesToPetriNets.StateMachineToPetriNet;
import FiniteStatesToPetriNets.StateToPlace;
import FiniteStatesToPetriNets.TransitionToTransition;

import PetriNets.PetriNetsPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.moflon.tgg.language.LanguagePackage;

import org.moflon.tgg.runtime.RuntimePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FiniteStatesToPetriNetsPackageImpl extends EPackageImpl implements FiniteStatesToPetriNetsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stateToPlaceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass endStateToTransitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitionToTransitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stateMachineToPetriNetEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see FiniteStatesToPetriNets.FiniteStatesToPetriNetsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private FiniteStatesToPetriNetsPackageImpl() {
		super(eNS_URI, FiniteStatesToPetriNetsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link FiniteStatesToPetriNetsPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static FiniteStatesToPetriNetsPackage init() {
		if (isInited)
			return (FiniteStatesToPetriNetsPackage) EPackage.Registry.INSTANCE
					.getEPackage(FiniteStatesToPetriNetsPackage.eNS_URI);

		// Obtain or create and register package
		FiniteStatesToPetriNetsPackageImpl theFiniteStatesToPetriNetsPackage = (FiniteStatesToPetriNetsPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof FiniteStatesToPetriNetsPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new FiniteStatesToPetriNetsPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		FiniteStateMachinesPackage.eINSTANCE.eClass();
		PetriNetsPackage.eINSTANCE.eClass();
		LanguagePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(RulesPackage.eNS_URI) instanceof RulesPackageImpl
						? EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI) : RulesPackage.eINSTANCE);

		// Create package meta-data objects
		theFiniteStatesToPetriNetsPackage.createPackageContents();
		theRulesPackage.createPackageContents();

		// Initialize created meta-data
		theFiniteStatesToPetriNetsPackage.initializePackageContents();
		theRulesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theFiniteStatesToPetriNetsPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(FiniteStatesToPetriNetsPackage.eNS_URI, theFiniteStatesToPetriNetsPackage);
		return theFiniteStatesToPetriNetsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStateToPlace() {
		return stateToPlaceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStateToPlace_Source() {
		return (EReference) stateToPlaceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStateToPlace_Target() {
		return (EReference) stateToPlaceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEndStateToTransition() {
		return endStateToTransitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEndStateToTransition_Source() {
		return (EReference) endStateToTransitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEndStateToTransition_Target() {
		return (EReference) endStateToTransitionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransitionToTransition() {
		return transitionToTransitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransitionToTransition_Source() {
		return (EReference) transitionToTransitionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransitionToTransition_Target() {
		return (EReference) transitionToTransitionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStateMachineToPetriNet() {
		return stateMachineToPetriNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStateMachineToPetriNet_Source() {
		return (EReference) stateMachineToPetriNetEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStateMachineToPetriNet_Target() {
		return (EReference) stateMachineToPetriNetEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FiniteStatesToPetriNetsFactory getFiniteStatesToPetriNetsFactory() {
		return (FiniteStatesToPetriNetsFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		stateToPlaceEClass = createEClass(STATE_TO_PLACE);
		createEReference(stateToPlaceEClass, STATE_TO_PLACE__SOURCE);
		createEReference(stateToPlaceEClass, STATE_TO_PLACE__TARGET);

		endStateToTransitionEClass = createEClass(END_STATE_TO_TRANSITION);
		createEReference(endStateToTransitionEClass, END_STATE_TO_TRANSITION__SOURCE);
		createEReference(endStateToTransitionEClass, END_STATE_TO_TRANSITION__TARGET);

		transitionToTransitionEClass = createEClass(TRANSITION_TO_TRANSITION);
		createEReference(transitionToTransitionEClass, TRANSITION_TO_TRANSITION__SOURCE);
		createEReference(transitionToTransitionEClass, TRANSITION_TO_TRANSITION__TARGET);

		stateMachineToPetriNetEClass = createEClass(STATE_MACHINE_TO_PETRI_NET);
		createEReference(stateMachineToPetriNetEClass, STATE_MACHINE_TO_PETRI_NET__SOURCE);
		createEReference(stateMachineToPetriNetEClass, STATE_MACHINE_TO_PETRI_NET__TARGET);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		RulesPackage theRulesPackage = (RulesPackage) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);
		RuntimePackage theRuntimePackage = (RuntimePackage) EPackage.Registry.INSTANCE
				.getEPackage(RuntimePackage.eNS_URI);
		FiniteStateMachinesPackage theFiniteStateMachinesPackage = (FiniteStateMachinesPackage) EPackage.Registry.INSTANCE
				.getEPackage(FiniteStateMachinesPackage.eNS_URI);
		PetriNetsPackage thePetriNetsPackage = (PetriNetsPackage) EPackage.Registry.INSTANCE
				.getEPackage(PetriNetsPackage.eNS_URI);

		// Add subpackages
		getESubpackages().add(theRulesPackage);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		stateToPlaceEClass.getESuperTypes().add(theRuntimePackage.getAbstractCorrespondence());
		endStateToTransitionEClass.getESuperTypes().add(theRuntimePackage.getAbstractCorrespondence());
		transitionToTransitionEClass.getESuperTypes().add(theRuntimePackage.getAbstractCorrespondence());
		stateMachineToPetriNetEClass.getESuperTypes().add(theRuntimePackage.getAbstractCorrespondence());

		// Initialize classes, features, and operations; add parameters
		initEClass(stateToPlaceEClass, StateToPlace.class, "StateToPlace", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStateToPlace_Source(), theFiniteStateMachinesPackage.getState(), null, "source", null, 1, 1,
				StateToPlace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStateToPlace_Target(), thePetriNetsPackage.getPlace(), null, "target", null, 1, 1,
				StateToPlace.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(endStateToTransitionEClass, EndStateToTransition.class, "EndStateToTransition", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEndStateToTransition_Source(), theFiniteStateMachinesPackage.getState(), null, "source", null,
				1, 1, EndStateToTransition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEndStateToTransition_Target(), thePetriNetsPackage.getTransition(), null, "target", null, 1,
				1, EndStateToTransition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transitionToTransitionEClass, TransitionToTransition.class, "TransitionToTransition", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTransitionToTransition_Source(), theFiniteStateMachinesPackage.getTransition(), null,
				"source", null, 1, 1, TransitionToTransition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTransitionToTransition_Target(), thePetriNetsPackage.getTransition(), null, "target", null, 1,
				1, TransitionToTransition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stateMachineToPetriNetEClass, StateMachineToPetriNet.class, "StateMachineToPetriNet", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStateMachineToPetriNet_Source(), theFiniteStateMachinesPackage.getFiniteStateMachine(), null,
				"source", null, 1, 1, StateMachineToPetriNet.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStateMachineToPetriNet_Target(), thePetriNetsPackage.getPetriNet(), null, "target", null, 1,
				1, StateMachineToPetriNet.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //FiniteStatesToPetriNetsPackageImpl
