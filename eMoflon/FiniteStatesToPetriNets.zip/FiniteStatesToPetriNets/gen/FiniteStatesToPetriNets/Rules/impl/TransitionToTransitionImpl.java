/**
 */
package FiniteStatesToPetriNets.Rules.impl;

import FiniteStateMachines.FiniteStateMachine;
import FiniteStateMachines.FiniteStateMachinesFactory;
import FiniteStateMachines.State;
import FiniteStateMachines.Transition;

import FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory;

import FiniteStatesToPetriNets.Rules.RulesPackage;
import FiniteStatesToPetriNets.Rules.TransitionToTransition;

import FiniteStatesToPetriNets.StateMachineToPetriNet;
import FiniteStatesToPetriNets.StateToPlace;

import PetriNets.PetriNet;
import PetriNets.PetriNetsFactory;
import PetriNets.Place;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.csp.*;
import csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transition To Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TransitionToTransitionImpl extends AbstractRuleImpl implements TransitionToTransition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransitionToTransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.Literals.TRANSITION_TO_TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		// initial bindings
		Object[] result1_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_0_1_initialbindings_blackBBBBBB(this, match, fsm, s2, tFsm, s1);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching in node [initial bindings] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s2] = " + s2
					+ ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_0_2_SolveCSP_bindingAndBlackFBBBBBB(this, match, fsm, s2, tFsm, s1);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", "
					+ "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (TransitionToTransitionImpl.pattern_TransitionToTransition_0_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = TransitionToTransitionImpl
					.pattern_TransitionToTransition_0_4_collectelementstobetranslated_blackBBBBB(match, fsm, s2, tFsm,
							s1);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", "
						+ "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ".");
			}
			TransitionToTransitionImpl.pattern_TransitionToTransition_0_4_collectelementstobetranslated_greenBBBBBFFFF(
					match, fsm, s2, tFsm, s1);
			// EMoflonEdge fsm__tFsm____transitions = (EMoflonEdge) result4_green[5];
			// EMoflonEdge tFsm__s2____endState = (EMoflonEdge) result4_green[6];
			// EMoflonEdge tFsm__s1____startState = (EMoflonEdge) result4_green[7];
			// EMoflonEdge s1__tFsm____transitions = (EMoflonEdge) result4_green[8];

			// collect context elements
			Object[] result5_black = TransitionToTransitionImpl
					.pattern_TransitionToTransition_0_5_collectcontextelements_blackBBBBB(match, fsm, s2, tFsm, s1);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", "
						+ "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ".");
			}
			TransitionToTransitionImpl.pattern_TransitionToTransition_0_5_collectcontextelements_greenBBBBFF(match, fsm,
					s2, s1);
			// EMoflonEdge fsm__s2____states = (EMoflonEdge) result5_green[4];
			// EMoflonEdge fsm__s1____states = (EMoflonEdge) result5_green[5];

			// register objects to match
			TransitionToTransitionImpl.pattern_TransitionToTransition_0_6_registerobjectstomatch_expressionBBBBBB(this,
					match, fsm, s2, tFsm, s1);
			return TransitionToTransitionImpl.pattern_TransitionToTransition_0_7_expressionF();
		} else {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_1_1_performtransformation_bindingAndBlackFFFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[0];
		State s2 = (State) result1_bindingAndBlack[1];
		StateToPlace s2ToP2 = (StateToPlace) result1_bindingAndBlack[2];
		StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result1_bindingAndBlack[3];
		Place p1 = (Place) result1_bindingAndBlack[4];
		Transition tFsm = (Transition) result1_bindingAndBlack[5];
		State s1 = (State) result1_bindingAndBlack[6];
		PetriNet pn = (PetriNet) result1_bindingAndBlack[7];
		Place p2 = (Place) result1_bindingAndBlack[8];
		StateToPlace s1Top1 = (StateToPlace) result1_bindingAndBlack[9];
		CSP csp = (CSP) result1_bindingAndBlack[10];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_1_1_performtransformation_greenFFBBBBB(p1, tFsm, pn, p2, csp);
		FiniteStatesToPetriNets.TransitionToTransition tToT = (FiniteStatesToPetriNets.TransitionToTransition) result1_green[0];
		PetriNets.Transition tPn = (PetriNets.Transition) result1_green[1];

		// collect translated elements
		Object[] result2_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_1_2_collecttranslatedelements_blackBBB(tToT, tPn, tFsm);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[tToT] = " + tToT + ", " + "[tPn] = " + tPn + ", " + "[tFsm] = " + tFsm + ".");
		}
		Object[] result2_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_1_2_collecttranslatedelements_greenFBBB(tToT, tPn, tFsm);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_1_3_bookkeepingforedges_blackBBBBBBBBBBBBB(ruleresult, tToT, fsm, s2,
						s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[tToT] = " + tToT + ", " + "[fsm] = " + fsm + ", "
					+ "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", " + "[fsmToPn] = " + fsmToPn + ", "
					+ "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1
					+ ", " + "[pn] = " + pn + ", " + "[p2] = " + p2 + ", " + "[s1Top1] = " + s1Top1 + ".");
		}
		TransitionToTransitionImpl.pattern_TransitionToTransition_1_3_bookkeepingforedges_greenBBBBBBBBBBFFFFFFFFFFF(
				ruleresult, tToT, fsm, s2, tPn, p1, tFsm, s1, pn, p2);
		// EMoflonEdge tToT__tPn____target = (EMoflonEdge) result3_green[10];
		// EMoflonEdge tPn__p2____to = (EMoflonEdge) result3_green[11];
		// EMoflonEdge p2__tPn____incoming = (EMoflonEdge) result3_green[12];
		// EMoflonEdge fsm__tFsm____transitions = (EMoflonEdge) result3_green[13];
		// EMoflonEdge tFsm__s2____endState = (EMoflonEdge) result3_green[14];
		// EMoflonEdge tPn__p1____from = (EMoflonEdge) result3_green[15];
		// EMoflonEdge p1__tPn____outgoing = (EMoflonEdge) result3_green[16];
		// EMoflonEdge tToT__tFsm____source = (EMoflonEdge) result3_green[17];
		// EMoflonEdge tFsm__s1____startState = (EMoflonEdge) result3_green[18];
		// EMoflonEdge s1__tFsm____transitions = (EMoflonEdge) result3_green[19];
		// EMoflonEdge pn__tPn____transitions = (EMoflonEdge) result3_green[20];

		// perform postprocessing story node is empty
		// register objects
		TransitionToTransitionImpl.pattern_TransitionToTransition_1_5_registerobjects_expressionBBBBBBBBBBBBBB(this,
				ruleresult, tToT, fsm, s2, s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);
		return TransitionToTransitionImpl.pattern_TransitionToTransition_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = TransitionToTransitionImpl
				.pattern_TransitionToTransition_2_2_corematch_bindingFFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result2_binding[0];
		State s2 = (State) result2_binding[1];
		Transition tFsm = (Transition) result2_binding[2];
		State s1 = (State) result2_binding[3];
		for (Object[] result2_black : TransitionToTransitionImpl
				.pattern_TransitionToTransition_2_2_corematch_blackBBFFFBBFFFB(fsm, s2, tFsm, s1, match)) {
			StateToPlace s2ToP2 = (StateToPlace) result2_black[2];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result2_black[3];
			Place p1 = (Place) result2_black[4];
			PetriNet pn = (PetriNet) result2_black[7];
			Place p2 = (Place) result2_black[8];
			StateToPlace s1Top1 = (StateToPlace) result2_black[9];
			// ForEach find context
			for (Object[] result3_black : TransitionToTransitionImpl
					.pattern_TransitionToTransition_2_3_findcontext_blackBBBBBBBBBB(fsm, s2, s2ToP2, fsmToPn, p1, tFsm,
							s1, pn, p2, s1Top1)) {
				Object[] result3_green = TransitionToTransitionImpl
						.pattern_TransitionToTransition_2_3_findcontext_greenBBBBBBBBBBFFFFFFFFFFFFFFF(fsm, s2, s2ToP2,
								fsmToPn, p1, tFsm, s1, pn, p2, s1Top1);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[10];
				// EMoflonEdge fsm__s2____states = (EMoflonEdge) result3_green[11];
				// EMoflonEdge fsmToPn__fsm____source = (EMoflonEdge) result3_green[12];
				// EMoflonEdge fsm__tFsm____transitions = (EMoflonEdge) result3_green[13];
				// EMoflonEdge tFsm__s2____endState = (EMoflonEdge) result3_green[14];
				// EMoflonEdge s2ToP2__s2____source = (EMoflonEdge) result3_green[15];
				// EMoflonEdge tFsm__s1____startState = (EMoflonEdge) result3_green[16];
				// EMoflonEdge s1__tFsm____transitions = (EMoflonEdge) result3_green[17];
				// EMoflonEdge pn__p2____places = (EMoflonEdge) result3_green[18];
				// EMoflonEdge fsmToPn__pn____target = (EMoflonEdge) result3_green[19];
				// EMoflonEdge pn__p1____places = (EMoflonEdge) result3_green[20];
				// EMoflonEdge s2ToP2__p2____target = (EMoflonEdge) result3_green[21];
				// EMoflonEdge fsm__s1____states = (EMoflonEdge) result3_green[22];
				// EMoflonEdge s1Top1__p1____target = (EMoflonEdge) result3_green[23];
				// EMoflonEdge s1Top1__s1____source = (EMoflonEdge) result3_green[24];

				// solve CSP
				Object[] result4_bindingAndBlack = TransitionToTransitionImpl
						.pattern_TransitionToTransition_2_4_solveCSP_bindingAndBlackFBBBBBBBBBBBB(this,
								isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[fsm] = " + fsm + ", "
									+ "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", " + "[fsmToPn] = " + fsmToPn
									+ ", " + "[p1] = " + p1 + ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ", "
									+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ", " + "[s1Top1] = " + s1Top1 + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (TransitionToTransitionImpl.pattern_TransitionToTransition_2_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = TransitionToTransitionImpl
							.pattern_TransitionToTransition_2_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					TransitionToTransitionImpl.pattern_TransitionToTransition_2_6_addmatchtoruleresult_greenBB(
							ruleresult, isApplicableMatch);

				} else {
				}

			}

		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		match.registerObject("fsm", fsm);
		match.registerObject("s2", s2);
		match.registerObject("tFsm", tFsm);
		match.registerObject("s1", s1);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, Transition tFsm, State s1, PetriNet pn,
			Place p2, StateToPlace s1Top1) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm.input", true, csp);
		var_tFsm_input.setValue(tFsm.getInput());
		var_tFsm_input.setType("String");

		// Create unbound variables
		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn.input", csp);
		var_tPn_input.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_tFsm_input, var_tPn_input);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("s2", s2);
		isApplicableMatch.registerObject("s2ToP2", s2ToP2);
		isApplicableMatch.registerObject("fsmToPn", fsmToPn);
		isApplicableMatch.registerObject("p1", p1);
		isApplicableMatch.registerObject("tFsm", tFsm);
		isApplicableMatch.registerObject("s1", s1);
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("p2", p2);
		isApplicableMatch.registerObject("s1Top1", s1Top1);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject s2ToP2,
			EObject fsmToPn, EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2,
			EObject s1Top1) {
		ruleresult.registerObject("tToT", tToT);
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("s2", s2);
		ruleresult.registerObject("s2ToP2", s2ToP2);
		ruleresult.registerObject("fsmToPn", fsmToPn);
		ruleresult.registerObject("tPn", tPn);
		ruleresult.registerObject("p1", p1);
		ruleresult.registerObject("tFsm", tFsm);
		ruleresult.registerObject("s1", s1);
		ruleresult.registerObject("pn", pn);
		ruleresult.registerObject("p2", p2);
		ruleresult.registerObject("s1Top1", s1Top1);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("tFsm").eClass())
				.equals("FiniteStateMachines.Transition.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		// initial bindings
		Object[] result1_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_10_1_initialbindings_blackBBBBBB(this, match, tPn, p1, pn, p2);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching in node [initial bindings] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[match] = " + match + ", " + "[tPn] = " + tPn + ", " + "[p1] = " + p1
					+ ", " + "[pn] = " + pn + ", " + "[p2] = " + p2 + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_10_2_SolveCSP_bindingAndBlackFBBBBBB(this, match, tPn, p1, pn, p2);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", "
					+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (TransitionToTransitionImpl.pattern_TransitionToTransition_10_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = TransitionToTransitionImpl
					.pattern_TransitionToTransition_10_4_collectelementstobetranslated_blackBBBBB(match, tPn, p1, pn,
							p2);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", "
						+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ".");
			}
			TransitionToTransitionImpl
					.pattern_TransitionToTransition_10_4_collectelementstobetranslated_greenBBBBBFFFFF(match, tPn, p1,
							pn, p2);
			// EMoflonEdge tPn__p2____to = (EMoflonEdge) result4_green[5];
			// EMoflonEdge p2__tPn____incoming = (EMoflonEdge) result4_green[6];
			// EMoflonEdge tPn__p1____from = (EMoflonEdge) result4_green[7];
			// EMoflonEdge p1__tPn____outgoing = (EMoflonEdge) result4_green[8];
			// EMoflonEdge pn__tPn____transitions = (EMoflonEdge) result4_green[9];

			// collect context elements
			Object[] result5_black = TransitionToTransitionImpl
					.pattern_TransitionToTransition_10_5_collectcontextelements_blackBBBBB(match, tPn, p1, pn, p2);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", "
						+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ".");
			}
			TransitionToTransitionImpl.pattern_TransitionToTransition_10_5_collectcontextelements_greenBBBBFF(match, p1,
					pn, p2);
			// EMoflonEdge pn__p2____places = (EMoflonEdge) result5_green[4];
			// EMoflonEdge pn__p1____places = (EMoflonEdge) result5_green[5];

			// register objects to match
			TransitionToTransitionImpl.pattern_TransitionToTransition_10_6_registerobjectstomatch_expressionBBBBBB(this,
					match, tPn, p1, pn, p2);
			return TransitionToTransitionImpl.pattern_TransitionToTransition_10_7_expressionF();
		} else {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_11_1_performtransformation_bindingAndBlackFFFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[0];
		State s2 = (State) result1_bindingAndBlack[1];
		StateToPlace s2ToP2 = (StateToPlace) result1_bindingAndBlack[2];
		StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result1_bindingAndBlack[3];
		PetriNets.Transition tPn = (PetriNets.Transition) result1_bindingAndBlack[4];
		Place p1 = (Place) result1_bindingAndBlack[5];
		State s1 = (State) result1_bindingAndBlack[6];
		PetriNet pn = (PetriNet) result1_bindingAndBlack[7];
		Place p2 = (Place) result1_bindingAndBlack[8];
		StateToPlace s1Top1 = (StateToPlace) result1_bindingAndBlack[9];
		CSP csp = (CSP) result1_bindingAndBlack[10];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_11_1_performtransformation_greenFBBBFBB(fsm, s2, tPn, s1, csp);
		FiniteStatesToPetriNets.TransitionToTransition tToT = (FiniteStatesToPetriNets.TransitionToTransition) result1_green[0];
		Transition tFsm = (Transition) result1_green[4];

		// collect translated elements
		Object[] result2_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_11_2_collecttranslatedelements_blackBBB(tToT, tPn, tFsm);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[tToT] = " + tToT + ", " + "[tPn] = " + tPn + ", " + "[tFsm] = " + tFsm + ".");
		}
		Object[] result2_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_11_2_collecttranslatedelements_greenFBBB(tToT, tPn, tFsm);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_11_3_bookkeepingforedges_blackBBBBBBBBBBBBB(ruleresult, tToT, fsm, s2,
						s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[tToT] = " + tToT + ", " + "[fsm] = " + fsm + ", "
					+ "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", " + "[fsmToPn] = " + fsmToPn + ", "
					+ "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1
					+ ", " + "[pn] = " + pn + ", " + "[p2] = " + p2 + ", " + "[s1Top1] = " + s1Top1 + ".");
		}
		TransitionToTransitionImpl.pattern_TransitionToTransition_11_3_bookkeepingforedges_greenBBBBBBBBBBFFFFFFFFFFF(
				ruleresult, tToT, fsm, s2, tPn, p1, tFsm, s1, pn, p2);
		// EMoflonEdge tToT__tPn____target = (EMoflonEdge) result3_green[10];
		// EMoflonEdge tPn__p2____to = (EMoflonEdge) result3_green[11];
		// EMoflonEdge p2__tPn____incoming = (EMoflonEdge) result3_green[12];
		// EMoflonEdge fsm__tFsm____transitions = (EMoflonEdge) result3_green[13];
		// EMoflonEdge tFsm__s2____endState = (EMoflonEdge) result3_green[14];
		// EMoflonEdge tPn__p1____from = (EMoflonEdge) result3_green[15];
		// EMoflonEdge p1__tPn____outgoing = (EMoflonEdge) result3_green[16];
		// EMoflonEdge tToT__tFsm____source = (EMoflonEdge) result3_green[17];
		// EMoflonEdge tFsm__s1____startState = (EMoflonEdge) result3_green[18];
		// EMoflonEdge s1__tFsm____transitions = (EMoflonEdge) result3_green[19];
		// EMoflonEdge pn__tPn____transitions = (EMoflonEdge) result3_green[20];

		// perform postprocessing story node is empty
		// register objects
		TransitionToTransitionImpl.pattern_TransitionToTransition_11_5_registerobjects_expressionBBBBBBBBBBBBBB(this,
				ruleresult, tToT, fsm, s2, s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);
		return TransitionToTransitionImpl.pattern_TransitionToTransition_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = TransitionToTransitionImpl
				.pattern_TransitionToTransition_12_2_corematch_bindingFFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		PetriNets.Transition tPn = (PetriNets.Transition) result2_binding[0];
		Place p1 = (Place) result2_binding[1];
		PetriNet pn = (PetriNet) result2_binding[2];
		Place p2 = (Place) result2_binding[3];
		for (Object[] result2_black : TransitionToTransitionImpl
				.pattern_TransitionToTransition_12_2_corematch_blackFFFFBBFBBFB(tPn, p1, pn, p2, match)) {
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[0];
			State s2 = (State) result2_black[1];
			StateToPlace s2ToP2 = (StateToPlace) result2_black[2];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result2_black[3];
			State s1 = (State) result2_black[6];
			StateToPlace s1Top1 = (StateToPlace) result2_black[9];
			// ForEach find context
			for (Object[] result3_black : TransitionToTransitionImpl
					.pattern_TransitionToTransition_12_3_findcontext_blackBBBBBBBBBB(fsm, s2, s2ToP2, fsmToPn, tPn, p1,
							s1, pn, p2, s1Top1)) {
				Object[] result3_green = TransitionToTransitionImpl
						.pattern_TransitionToTransition_12_3_findcontext_greenBBBBBBBBBBFFFFFFFFFFFFFFFF(fsm, s2,
								s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[10];
				// EMoflonEdge fsm__s2____states = (EMoflonEdge) result3_green[11];
				// EMoflonEdge tPn__p2____to = (EMoflonEdge) result3_green[12];
				// EMoflonEdge p2__tPn____incoming = (EMoflonEdge) result3_green[13];
				// EMoflonEdge fsmToPn__fsm____source = (EMoflonEdge) result3_green[14];
				// EMoflonEdge tPn__p1____from = (EMoflonEdge) result3_green[15];
				// EMoflonEdge p1__tPn____outgoing = (EMoflonEdge) result3_green[16];
				// EMoflonEdge s2ToP2__s2____source = (EMoflonEdge) result3_green[17];
				// EMoflonEdge pn__p2____places = (EMoflonEdge) result3_green[18];
				// EMoflonEdge fsmToPn__pn____target = (EMoflonEdge) result3_green[19];
				// EMoflonEdge pn__p1____places = (EMoflonEdge) result3_green[20];
				// EMoflonEdge s2ToP2__p2____target = (EMoflonEdge) result3_green[21];
				// EMoflonEdge pn__tPn____transitions = (EMoflonEdge) result3_green[22];
				// EMoflonEdge fsm__s1____states = (EMoflonEdge) result3_green[23];
				// EMoflonEdge s1Top1__p1____target = (EMoflonEdge) result3_green[24];
				// EMoflonEdge s1Top1__s1____source = (EMoflonEdge) result3_green[25];

				// solve CSP
				Object[] result4_bindingAndBlack = TransitionToTransitionImpl
						.pattern_TransitionToTransition_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBBB(this,
								isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[fsm] = " + fsm + ", "
									+ "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", " + "[fsmToPn] = " + fsmToPn
									+ ", " + "[tPn] = " + tPn + ", " + "[p1] = " + p1 + ", " + "[s1] = " + s1 + ", "
									+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ", " + "[s1Top1] = " + s1Top1 + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (TransitionToTransitionImpl.pattern_TransitionToTransition_12_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = TransitionToTransitionImpl
							.pattern_TransitionToTransition_12_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					TransitionToTransitionImpl.pattern_TransitionToTransition_12_6_addmatchtoruleresult_greenBB(
							ruleresult, isApplicableMatch);

				} else {
				}

			}

		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		match.registerObject("tPn", tPn);
		match.registerObject("p1", p1);
		match.registerObject("pn", pn);
		match.registerObject("p2", p2);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, PetriNets.Transition tPn, Place p1, State s1,
			PetriNet pn, Place p2, StateToPlace s1Top1) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn.input", true, csp);
		var_tPn_input.setValue(tPn.getInput());
		var_tPn_input.setType("String");

		// Create unbound variables
		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm.input", csp);
		var_tFsm_input.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_tFsm_input, var_tPn_input);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("s2", s2);
		isApplicableMatch.registerObject("s2ToP2", s2ToP2);
		isApplicableMatch.registerObject("fsmToPn", fsmToPn);
		isApplicableMatch.registerObject("tPn", tPn);
		isApplicableMatch.registerObject("p1", p1);
		isApplicableMatch.registerObject("s1", s1);
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("p2", p2);
		isApplicableMatch.registerObject("s1Top1", s1Top1);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject s2ToP2,
			EObject fsmToPn, EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2,
			EObject s1Top1) {
		ruleresult.registerObject("tToT", tToT);
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("s2", s2);
		ruleresult.registerObject("s2ToP2", s2ToP2);
		ruleresult.registerObject("fsmToPn", fsmToPn);
		ruleresult.registerObject("tPn", tPn);
		ruleresult.registerObject("p1", p1);
		ruleresult.registerObject("tFsm", tFsm);
		ruleresult.registerObject("s1", s1);
		ruleresult.registerObject("pn", pn);
		ruleresult.registerObject("p2", p2);
		ruleresult.registerObject("s1Top1", s1Top1);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("tPn").eClass())
				.equals("PetriNets.Transition.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_11(EMoflonEdge _edge_to) {
		// prepare return value
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : TransitionToTransitionImpl
				.pattern_TransitionToTransition_20_2_testcorematchandDECs_blackFFFFB(_edge_to)) {
			PetriNets.Transition tPn = (PetriNets.Transition) result2_black[0];
			Place p1 = (Place) result2_black[1];
			PetriNet pn = (PetriNet) result2_black[2];
			Place p2 = (Place) result2_black[3];
			Object[] result2_green = TransitionToTransitionImpl
					.pattern_TransitionToTransition_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (TransitionToTransitionImpl
					.pattern_TransitionToTransition_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(
							this, match, tPn, p1, pn, p2)) {
				// Ensure that the correct types of elements are matched
				if (TransitionToTransitionImpl
						.pattern_TransitionToTransition_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = TransitionToTransitionImpl
							.pattern_TransitionToTransition_20_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					TransitionToTransitionImpl.pattern_TransitionToTransition_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_7(EMoflonEdge _edge_transitions) {
		// prepare return value
		Object[] result1_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitionToTransitionImpl
				.pattern_TransitionToTransition_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : TransitionToTransitionImpl
				.pattern_TransitionToTransition_21_2_testcorematchandDECs_blackFFFFB(_edge_transitions)) {
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[0];
			State s2 = (State) result2_black[1];
			Transition tFsm = (Transition) result2_black[2];
			State s1 = (State) result2_black[3];
			Object[] result2_green = TransitionToTransitionImpl
					.pattern_TransitionToTransition_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (TransitionToTransitionImpl
					.pattern_TransitionToTransition_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(
							this, match, fsm, s2, tFsm, s1)) {
				// Ensure that the correct types of elements are matched
				if (TransitionToTransitionImpl
						.pattern_TransitionToTransition_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = TransitionToTransitionImpl
							.pattern_TransitionToTransition_21_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					TransitionToTransitionImpl.pattern_TransitionToTransition_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitionToTransition");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm", true, csp);
		var_tFsm_input.setValue(__helper.getValue("tFsm", "input"));
		var_tFsm_input.setType("String");

		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn", true, csp);
		var_tPn_input.setValue(__helper.getValue("tPn", "input"));
		var_tPn_input.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("TransitionToTransition");
		eq0.solve(var_tFsm_input, var_tPn_input);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_tPn_input.setBound(false);
			eq0.solve(var_tFsm_input, var_tPn_input);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("tPn", "input", var_tPn_input.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitionToTransition");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm", true, csp);
		var_tFsm_input.setValue(__helper.getValue("tFsm", "input"));
		var_tFsm_input.setType("String");

		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn", true, csp);
		var_tPn_input.setValue(__helper.getValue("tPn", "input"));
		var_tPn_input.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("TransitionToTransition");
		eq0.solve(var_tFsm_input, var_tPn_input);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_tFsm_input.setBound(false);
			eq0.solve(var_tFsm_input, var_tPn_input);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("tFsm", "input", var_tFsm_input.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {
		// prepare
		Object[] result1_black = TransitionToTransitionImpl.pattern_TransitionToTransition_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [prepare] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitionToTransitionImpl.pattern_TransitionToTransition_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		// match src trg context
		Object[] result2_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFFBB(sourceMatch,
						targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [match src trg context] failed." + " Variables: "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result2_bindingAndBlack[0];
		State s2 = (State) result2_bindingAndBlack[1];
		PetriNets.Transition tPn = (PetriNets.Transition) result2_bindingAndBlack[2];
		Place p1 = (Place) result2_bindingAndBlack[3];
		Transition tFsm = (Transition) result2_bindingAndBlack[4];
		State s1 = (State) result2_bindingAndBlack[5];
		PetriNet pn = (PetriNet) result2_bindingAndBlack[6];
		Place p2 = (Place) result2_bindingAndBlack[7];

		// solve csp
		Object[] result3_bindingAndBlack = TransitionToTransitionImpl
				.pattern_TransitionToTransition_24_3_solvecsp_bindingAndBlackFBBBBBBBBBBB(this, fsm, s2, tPn, p1, tFsm,
						s1, pn, p2, sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [solve csp] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", " + "[tPn] = " + tPn + ", "
					+ "[p1] = " + p1 + ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ", " + "[pn] = " + pn + ", "
					+ "[p2] = " + p2 + ", " + "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch
					+ ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// check CSP
		if (TransitionToTransitionImpl.pattern_TransitionToTransition_24_4_checkCSP_expressionFB(csp)) {
			// ForEach match corr context
			for (Object[] result5_black : TransitionToTransitionImpl
					.pattern_TransitionToTransition_24_5_matchcorrcontext_blackBBFFBBBBFBB(fsm, s2, p1, s1, pn, p2,
							sourceMatch, targetMatch)) {
				StateToPlace s2ToP2 = (StateToPlace) result5_black[2];
				StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result5_black[3];
				StateToPlace s1Top1 = (StateToPlace) result5_black[8];
				Object[] result5_green = TransitionToTransitionImpl
						.pattern_TransitionToTransition_24_5_matchcorrcontext_greenBBBBBF(s2ToP2, fsmToPn, s1Top1,
								sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[5];

				// create correspondence
				Object[] result6_black = TransitionToTransitionImpl
						.pattern_TransitionToTransition_24_6_createcorrespondence_blackBBBBBBBBB(fsm, s2, tPn, p1, tFsm,
								s1, pn, p2, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching in node [create correspondence] failed."
							+ " Variables: " + "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", " + "[tPn] = " + tPn + ", "
							+ "[p1] = " + p1 + ", " + "[tFsm] = " + tFsm + ", " + "[s1] = " + s1 + ", " + "[pn] = " + pn
							+ ", " + "[p2] = " + p2 + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				TransitionToTransitionImpl.pattern_TransitionToTransition_24_6_createcorrespondence_greenFBBB(tPn, tFsm,
						ccMatch);
				// FiniteStatesToPetriNets.TransitionToTransition tToT = (FiniteStatesToPetriNets.TransitionToTransition) result6_green[0];

				// add to returned result
				Object[] result7_black = TransitionToTransitionImpl
						.pattern_TransitionToTransition_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching in node [add to returned result] failed."
							+ " Variables: " + "[result] = " + result + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				TransitionToTransitionImpl.pattern_TransitionToTransition_24_7_addtoreturnedresult_greenBB(result,
						ccMatch);

			}

		} else {
		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm.input", true, csp);
		var_tFsm_input.setValue(tFsm.getInput());
		var_tFsm_input.setType("String");
		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn.input", true, csp);
		var_tPn_input.setValue(tPn.getInput());
		var_tPn_input.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_tFsm_input, var_tPn_input);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {// match tgg pattern
		Object[] result1_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_27_1_matchtggpattern_blackBBBB(fsm, s2, tFsm, s1);
		if (result1_black != null) {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_27_2_expressionF();
		} else {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {// match tgg pattern
		Object[] result1_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_28_1_matchtggpattern_blackBBBB(tPn, p1, pn, p2);
		if (result1_black != null) {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_28_2_expressionF();
		} else {
			return TransitionToTransitionImpl.pattern_TransitionToTransition_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer, StateToPlace s2ToP2Parameter) {
		// create result
		Object[] result1_black = TransitionToTransitionImpl
				.pattern_TransitionToTransition_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [create result] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitionToTransitionImpl.pattern_TransitionToTransition_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach is applicable core
		for (Object[] result2_black : TransitionToTransitionImpl
				.pattern_TransitionToTransition_29_2_isapplicablecore_blackFFFFFFFFFFBB(ruleEntryContainer,
						ruleResult)) {
			// RuleEntryList s2ToP2List = (RuleEntryList) result2_black[0];
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[1];
			State s2 = (State) result2_black[2];
			StateToPlace s2ToP2 = (StateToPlace) result2_black[3];
			Place p2 = (Place) result2_black[4];
			PetriNet pn = (PetriNet) result2_black[5];
			Place p1 = (Place) result2_black[6];
			StateToPlace s1Top1 = (StateToPlace) result2_black[7];
			State s1 = (State) result2_black[8];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result2_black[9];

			// solve CSP
			Object[] result3_bindingAndBlack = TransitionToTransitionImpl
					.pattern_TransitionToTransition_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBBB(this, isApplicableMatch,
							fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = "
						+ this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ", " + "[fsm] = " + fsm + ", "
						+ "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", " + "[fsmToPn] = " + fsmToPn + ", "
						+ "[p1] = " + p1 + ", " + "[s1] = " + s1 + ", " + "[pn] = " + pn + ", " + "[p2] = " + p2 + ", "
						+ "[s1Top1] = " + s1Top1 + ", " + "[ruleResult] = " + ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// check CSP
			if (TransitionToTransitionImpl.pattern_TransitionToTransition_29_4_checkCSP_expressionFBB(this, csp)) {
				// check nacs
				Object[] result5_black = TransitionToTransitionImpl
						.pattern_TransitionToTransition_29_5_checknacs_blackBBBBBBBBB(fsm, s2, s2ToP2, fsmToPn, p1, s1,
								pn, p2, s1Top1);
				if (result5_black != null) {

					// perform
					Object[] result6_black = TransitionToTransitionImpl
							.pattern_TransitionToTransition_29_6_perform_blackBBBBBBBBBB(fsm, s2, s2ToP2, fsmToPn, p1,
									s1, pn, p2, s1Top1, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [perform] failed." + " Variables: "
								+ "[fsm] = " + fsm + ", " + "[s2] = " + s2 + ", " + "[s2ToP2] = " + s2ToP2 + ", "
								+ "[fsmToPn] = " + fsmToPn + ", " + "[p1] = " + p1 + ", " + "[s1] = " + s1 + ", "
								+ "[pn] = " + pn + ", " + "[p2] = " + p2 + ", " + "[s1Top1] = " + s1Top1 + ", "
								+ "[ruleResult] = " + ruleResult + ".");
					}
					TransitionToTransitionImpl.pattern_TransitionToTransition_29_6_perform_greenFBBFBFBBBBB(fsm, s2, p1,
							s1, pn, p2, ruleResult, csp);
					// FiniteStatesToPetriNets.TransitionToTransition tToT = (FiniteStatesToPetriNets.TransitionToTransition) result6_green[0];
					// PetriNets.Transition tPn = (PetriNets.Transition) result6_green[3];
					// Transition tFsm = (Transition) result6_green[5];

				} else {
				}

			} else {
			}

		}
		return TransitionToTransitionImpl.pattern_TransitionToTransition_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, State s1, PetriNet pn, Place p2,
			StateToPlace s1Top1, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_tFsm_input = CSPFactoryHelper.eINSTANCE.createVariable("tFsm.input", csp);
		var_tFsm_input.setType("String");
		Variable var_tPn_input = CSPFactoryHelper.eINSTANCE.createVariable("tPn.input", csp);
		var_tPn_input.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_tFsm_input, var_tPn_input);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("s2", s2);
		isApplicableMatch.registerObject("s2ToP2", s2ToP2);
		isApplicableMatch.registerObject("fsmToPn", fsmToPn);
		isApplicableMatch.registerObject("p1", p1);
		isApplicableMatch.registerObject("s1", s1);
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("p2", p2);
		isApplicableMatch.registerObject("s1Top1", s1Top1);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE:
			return isAppropriate_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2), (Transition) arguments.get(3), (State) arguments.get(4));
		case RulesPackage.TRANSITION_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2), (Transition) arguments.get(3), (State) arguments.get(4));
			return null;
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2), (Transition) arguments.get(3), (State) arguments.get(4));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_TRANSITION_STATE_PETRINET_PLACE_STATETOPLACE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0),
					(FiniteStateMachine) arguments.get(1), (State) arguments.get(2), (StateToPlace) arguments.get(3),
					(StateMachineToPetriNet) arguments.get(4), (Place) arguments.get(5), (Transition) arguments.get(6),
					(State) arguments.get(7), (PetriNet) arguments.get(8), (Place) arguments.get(9),
					(StateToPlace) arguments.get(10));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10),
					(EObject) arguments.get(11), (EObject) arguments.get(12));
			return null;
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE:
			return isAppropriate_BWD((Match) arguments.get(0), (PetriNets.Transition) arguments.get(1),
					(Place) arguments.get(2), (PetriNet) arguments.get(3), (Place) arguments.get(4));
		case RulesPackage.TRANSITION_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (PetriNets.Transition) arguments.get(1),
					(Place) arguments.get(2), (PetriNet) arguments.get(3), (Place) arguments.get(4));
			return null;
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (PetriNets.Transition) arguments.get(1),
					(Place) arguments.get(2), (PetriNet) arguments.get(3), (Place) arguments.get(4));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_TRANSITION_PLACE_STATE_PETRINET_PLACE_STATETOPLACE:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0),
					(FiniteStateMachine) arguments.get(1), (State) arguments.get(2), (StateToPlace) arguments.get(3),
					(StateMachineToPetriNet) arguments.get(4), (PetriNets.Transition) arguments.get(5),
					(Place) arguments.get(6), (State) arguments.get(7), (PetriNet) arguments.get(8),
					(Place) arguments.get(9), (StateToPlace) arguments.get(10));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10),
					(EObject) arguments.get(11), (EObject) arguments.get(12));
			return null;
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_11__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_11((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD_EMOFLON_EDGE_7__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_7((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_STATE_TRANSITION_PLACE_TRANSITION_STATE_PETRINET_PLACE_MATCH_MATCH:
			return isApplicable_solveCsp_CC((FiniteStateMachine) arguments.get(0), (State) arguments.get(1),
					(PetriNets.Transition) arguments.get(2), (Place) arguments.get(3), (Transition) arguments.get(4),
					(State) arguments.get(5), (PetriNet) arguments.get(6), (Place) arguments.get(7),
					(Match) arguments.get(8), (Match) arguments.get(9));
		case RulesPackage.TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE_TRANSITION_STATE:
			return checkDEC_FWD((FiniteStateMachine) arguments.get(0), (State) arguments.get(1),
					(Transition) arguments.get(2), (State) arguments.get(3));
		case RulesPackage.TRANSITION_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PLACE_PETRINET_PLACE:
			return checkDEC_BWD((PetriNets.Transition) arguments.get(0), (Place) arguments.get(1),
					(PetriNet) arguments.get(2), (Place) arguments.get(3));
		case RulesPackage.TRANSITION_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE:
			return generateModel((RuleEntryContainer) arguments.get(0), (StateToPlace) arguments.get(1));
		case RulesPackage.TRANSITION_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_STATE_PETRINET_PLACE_STATETOPLACE_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0),
					(FiniteStateMachine) arguments.get(1), (State) arguments.get(2), (StateToPlace) arguments.get(3),
					(StateMachineToPetriNet) arguments.get(4), (Place) arguments.get(5), (State) arguments.get(6),
					(PetriNet) arguments.get(7), (Place) arguments.get(8), (StateToPlace) arguments.get(9),
					(ModelgeneratorRuleResult) arguments.get(10));
		case RulesPackage.TRANSITION_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_TransitionToTransition_0_1_initialbindings_blackBBBBBB(
			TransitionToTransition _this, Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		if (!s1.equals(s2)) {
			return new Object[] { _this, match, fsm, s2, tFsm, s1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_0_2_SolveCSP_bindingFBBBBBB(
			TransitionToTransition _this, Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, fsm, s2, tFsm, s1);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, fsm, s2, tFsm, s1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_0_2_SolveCSP_bindingAndBlackFBBBBBB(
			TransitionToTransition _this, Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		Object[] result_pattern_TransitionToTransition_0_2_SolveCSP_binding = pattern_TransitionToTransition_0_2_SolveCSP_bindingFBBBBBB(
				_this, match, fsm, s2, tFsm, s1);
		if (result_pattern_TransitionToTransition_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_0_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitionToTransition_0_2_SolveCSP_black = pattern_TransitionToTransition_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitionToTransition_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, fsm, s2, tFsm, s1 };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_0_3_CheckCSP_expressionFBB(TransitionToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_0_4_collectelementstobetranslated_blackBBBBB(
			Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		if (!s1.equals(s2)) {
			return new Object[] { match, fsm, s2, tFsm, s1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_0_4_collectelementstobetranslated_greenBBBBBFFFF(
			Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		EMoflonEdge fsm__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s2____endState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s1____startState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(tFsm);
		String fsm__tFsm____transitions_name_prime = "transitions";
		String tFsm__s2____endState_name_prime = "endState";
		String tFsm__s1____startState_name_prime = "startState";
		String s1__tFsm____transitions_name_prime = "transitions";
		fsm__tFsm____transitions.setSrc(fsm);
		fsm__tFsm____transitions.setTrg(tFsm);
		match.getToBeTranslatedEdges().add(fsm__tFsm____transitions);
		tFsm__s2____endState.setSrc(tFsm);
		tFsm__s2____endState.setTrg(s2);
		match.getToBeTranslatedEdges().add(tFsm__s2____endState);
		tFsm__s1____startState.setSrc(tFsm);
		tFsm__s1____startState.setTrg(s1);
		match.getToBeTranslatedEdges().add(tFsm__s1____startState);
		s1__tFsm____transitions.setSrc(s1);
		s1__tFsm____transitions.setTrg(tFsm);
		match.getToBeTranslatedEdges().add(s1__tFsm____transitions);
		fsm__tFsm____transitions.setName(fsm__tFsm____transitions_name_prime);
		tFsm__s2____endState.setName(tFsm__s2____endState_name_prime);
		tFsm__s1____startState.setName(tFsm__s1____startState_name_prime);
		s1__tFsm____transitions.setName(s1__tFsm____transitions_name_prime);
		return new Object[] { match, fsm, s2, tFsm, s1, fsm__tFsm____transitions, tFsm__s2____endState,
				tFsm__s1____startState, s1__tFsm____transitions };
	}

	public static final Object[] pattern_TransitionToTransition_0_5_collectcontextelements_blackBBBBB(Match match,
			FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		if (!s1.equals(s2)) {
			return new Object[] { match, fsm, s2, tFsm, s1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_0_5_collectcontextelements_greenBBBBFF(Match match,
			FiniteStateMachine fsm, State s2, State s1) {
		EMoflonEdge fsm__s2____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s1____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(fsm);
		match.getContextNodes().add(s2);
		match.getContextNodes().add(s1);
		String fsm__s2____states_name_prime = "states";
		String fsm__s1____states_name_prime = "states";
		fsm__s2____states.setSrc(fsm);
		fsm__s2____states.setTrg(s2);
		match.getContextEdges().add(fsm__s2____states);
		fsm__s1____states.setSrc(fsm);
		fsm__s1____states.setTrg(s1);
		match.getContextEdges().add(fsm__s1____states);
		fsm__s2____states.setName(fsm__s2____states_name_prime);
		fsm__s1____states.setName(fsm__s1____states_name_prime);
		return new Object[] { match, fsm, s2, s1, fsm__s2____states, fsm__s1____states };
	}

	public static final void pattern_TransitionToTransition_0_6_registerobjectstomatch_expressionBBBBBB(
			TransitionToTransition _this, Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		_this.registerObjectsToMatch_FWD(match, fsm, s2, tFsm, s1);

	}

	public static final boolean pattern_TransitionToTransition_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_1_1_performtransformation_bindingFFFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("fsm");
		EObject _localVariable_1 = isApplicableMatch.getObject("s2");
		EObject _localVariable_2 = isApplicableMatch.getObject("s2ToP2");
		EObject _localVariable_3 = isApplicableMatch.getObject("fsmToPn");
		EObject _localVariable_4 = isApplicableMatch.getObject("p1");
		EObject _localVariable_5 = isApplicableMatch.getObject("tFsm");
		EObject _localVariable_6 = isApplicableMatch.getObject("s1");
		EObject _localVariable_7 = isApplicableMatch.getObject("pn");
		EObject _localVariable_8 = isApplicableMatch.getObject("p2");
		EObject _localVariable_9 = isApplicableMatch.getObject("s1Top1");
		EObject tmpFsm = _localVariable_0;
		EObject tmpS2 = _localVariable_1;
		EObject tmpS2ToP2 = _localVariable_2;
		EObject tmpFsmToPn = _localVariable_3;
		EObject tmpP1 = _localVariable_4;
		EObject tmpTFsm = _localVariable_5;
		EObject tmpS1 = _localVariable_6;
		EObject tmpPn = _localVariable_7;
		EObject tmpP2 = _localVariable_8;
		EObject tmpS1Top1 = _localVariable_9;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpS2 instanceof State) {
				State s2 = (State) tmpS2;
				if (tmpS2ToP2 instanceof StateToPlace) {
					StateToPlace s2ToP2 = (StateToPlace) tmpS2ToP2;
					if (tmpFsmToPn instanceof StateMachineToPetriNet) {
						StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) tmpFsmToPn;
						if (tmpP1 instanceof Place) {
							Place p1 = (Place) tmpP1;
							if (tmpTFsm instanceof Transition) {
								Transition tFsm = (Transition) tmpTFsm;
								if (tmpS1 instanceof State) {
									State s1 = (State) tmpS1;
									if (tmpPn instanceof PetriNet) {
										PetriNet pn = (PetriNet) tmpPn;
										if (tmpP2 instanceof Place) {
											Place p2 = (Place) tmpP2;
											if (tmpS1Top1 instanceof StateToPlace) {
												StateToPlace s1Top1 = (StateToPlace) tmpS1Top1;
												return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2,
														s1Top1, isApplicableMatch };
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_1_1_performtransformation_blackBBBBBBBBBBFBB(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, StateToPlace s1Top1, TransitionToTransition _this,
			IsApplicableMatch isApplicableMatch) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
						if (tmpCsp instanceof CSP) {
							CSP csp = (CSP) tmpCsp;
							return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1, csp, _this,
									isApplicableMatch };
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_1_1_performtransformation_bindingAndBlackFFFFFFFFFFFBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitionToTransition_1_1_performtransformation_binding = pattern_TransitionToTransition_1_1_performtransformation_bindingFFFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitionToTransition_1_1_performtransformation_binding != null) {
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_TransitionToTransition_1_1_performtransformation_binding[0];
			State s2 = (State) result_pattern_TransitionToTransition_1_1_performtransformation_binding[1];
			StateToPlace s2ToP2 = (StateToPlace) result_pattern_TransitionToTransition_1_1_performtransformation_binding[2];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result_pattern_TransitionToTransition_1_1_performtransformation_binding[3];
			Place p1 = (Place) result_pattern_TransitionToTransition_1_1_performtransformation_binding[4];
			Transition tFsm = (Transition) result_pattern_TransitionToTransition_1_1_performtransformation_binding[5];
			State s1 = (State) result_pattern_TransitionToTransition_1_1_performtransformation_binding[6];
			PetriNet pn = (PetriNet) result_pattern_TransitionToTransition_1_1_performtransformation_binding[7];
			Place p2 = (Place) result_pattern_TransitionToTransition_1_1_performtransformation_binding[8];
			StateToPlace s1Top1 = (StateToPlace) result_pattern_TransitionToTransition_1_1_performtransformation_binding[9];

			Object[] result_pattern_TransitionToTransition_1_1_performtransformation_black = pattern_TransitionToTransition_1_1_performtransformation_blackBBBBBBBBBBFBB(
					fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1, _this, isApplicableMatch);
			if (result_pattern_TransitionToTransition_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitionToTransition_1_1_performtransformation_black[10];

				return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1, csp, _this,
						isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_1_1_performtransformation_greenFFBBBBB(Place p1,
			Transition tFsm, PetriNet pn, Place p2, CSP csp) {
		FiniteStatesToPetriNets.TransitionToTransition tToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createTransitionToTransition();
		PetriNets.Transition tPn = PetriNetsFactory.eINSTANCE.createTransition();
		Object _localVariable_0 = csp.getValue("tPn", "input");
		tToT.setSource(tFsm);
		tToT.setTarget(tPn);
		tPn.getTo().add(p2);
		tPn.getFrom().add(p1);
		pn.getTransitions().add(tPn);
		String tPn_input_prime = (String) _localVariable_0;
		tPn.setInput(tPn_input_prime);
		return new Object[] { tToT, tPn, p1, tFsm, pn, p2, csp };
	}

	public static final Object[] pattern_TransitionToTransition_1_2_collecttranslatedelements_blackBBB(
			FiniteStatesToPetriNets.TransitionToTransition tToT, PetriNets.Transition tPn, Transition tFsm) {
		return new Object[] { tToT, tPn, tFsm };
	}

	public static final Object[] pattern_TransitionToTransition_1_2_collecttranslatedelements_greenFBBB(
			FiniteStatesToPetriNets.TransitionToTransition tToT, PetriNets.Transition tPn, Transition tFsm) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(tToT);
		ruleresult.getCreatedElements().add(tPn);
		ruleresult.getTranslatedElements().add(tFsm);
		return new Object[] { ruleresult, tToT, tPn, tFsm };
	}

	public static final Object[] pattern_TransitionToTransition_1_3_bookkeepingforedges_blackBBBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject s2ToP2, EObject fsmToPn,
			EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2, EObject s1Top1) {
		if (!fsm.equals(tToT)) {
			if (!fsm.equals(s2)) {
				if (!fsm.equals(s2ToP2)) {
					if (!fsm.equals(fsmToPn)) {
						if (!fsm.equals(tPn)) {
							if (!fsm.equals(p1)) {
								if (!fsm.equals(tFsm)) {
									if (!fsm.equals(s1)) {
										if (!fsm.equals(pn)) {
											if (!fsm.equals(p2)) {
												if (!fsm.equals(s1Top1)) {
													if (!s2.equals(tToT)) {
														if (!s2.equals(s2ToP2)) {
															if (!s2.equals(tPn)) {
																if (!s2.equals(tFsm)) {
																	if (!s2ToP2.equals(tToT)) {
																		if (!s2ToP2.equals(tPn)) {
																			if (!s2ToP2.equals(tFsm)) {
																				if (!fsmToPn.equals(tToT)) {
																					if (!fsmToPn.equals(s2)) {
																						if (!fsmToPn.equals(s2ToP2)) {
																							if (!fsmToPn.equals(tPn)) {
																								if (!fsmToPn
																										.equals(p1)) {
																									if (!fsmToPn.equals(
																											tFsm)) {
																										if (!fsmToPn
																												.equals(s1)) {
																											if (!fsmToPn
																													.equals(pn)) {
																												if (!fsmToPn
																														.equals(p2)) {
																													if (!fsmToPn
																															.equals(s1Top1)) {
																														if (!tPn.equals(
																																tToT)) {
																															if (!p1.equals(
																																	tToT)) {
																																if (!p1.equals(
																																		s2)) {
																																	if (!p1.equals(
																																			s2ToP2)) {
																																		if (!p1.equals(
																																				tPn)) {
																																			if (!p1.equals(
																																					tFsm)) {
																																				if (!p1.equals(
																																						s1)) {
																																					if (!p1.equals(
																																							pn)) {
																																						if (!p1.equals(
																																								p2)) {
																																							if (!p1.equals(
																																									s1Top1)) {
																																								if (!tFsm
																																										.equals(tToT)) {
																																									if (!tFsm
																																											.equals(tPn)) {
																																										if (!s1.equals(
																																												tToT)) {
																																											if (!s1.equals(
																																													s2)) {
																																												if (!s1.equals(
																																														s2ToP2)) {
																																													if (!s1.equals(
																																															tPn)) {
																																														if (!s1.equals(
																																																tFsm)) {
																																															if (!s1.equals(
																																																	s1Top1)) {
																																																if (!pn.equals(
																																																		tToT)) {
																																																	if (!pn.equals(
																																																			s2)) {
																																																		if (!pn.equals(
																																																				s2ToP2)) {
																																																			if (!pn.equals(
																																																					tPn)) {
																																																				if (!pn.equals(
																																																						tFsm)) {
																																																					if (!pn.equals(
																																																							s1)) {
																																																						if (!pn.equals(
																																																								s1Top1)) {
																																																							if (!p2.equals(
																																																									tToT)) {
																																																								if (!p2.equals(
																																																										s2)) {
																																																									if (!p2.equals(
																																																											s2ToP2)) {
																																																										if (!p2.equals(
																																																												tPn)) {
																																																											if (!p2.equals(
																																																													tFsm)) {
																																																												if (!p2.equals(
																																																														s1)) {
																																																													if (!p2.equals(
																																																															pn)) {
																																																														if (!p2.equals(
																																																																s1Top1)) {
																																																															if (!s1Top1
																																																																	.equals(tToT)) {
																																																																if (!s1Top1
																																																																		.equals(s2)) {
																																																																	if (!s1Top1
																																																																			.equals(s2ToP2)) {
																																																																		if (!s1Top1
																																																																				.equals(tPn)) {
																																																																			if (!s1Top1
																																																																					.equals(tFsm)) {
																																																																				return new Object[] {
																																																																						ruleresult,
																																																																						tToT,
																																																																						fsm,
																																																																						s2,
																																																																						s2ToP2,
																																																																						fsmToPn,
																																																																						tPn,
																																																																						p1,
																																																																						tFsm,
																																																																						s1,
																																																																						pn,
																																																																						p2,
																																																																						s1Top1 };
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_1_3_bookkeepingforedges_greenBBBBBBBBBBFFFFFFFFFFF(
			PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject tPn, EObject p1, EObject tFsm,
			EObject s1, EObject pn, EObject p2) {
		EMoflonEdge tToT__tPn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p2____to = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2__tPn____incoming = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s2____endState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p1____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p1__tPn____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tToT__tFsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s1____startState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__tPn____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitionToTransition";
		String tToT__tPn____target_name_prime = "target";
		String tPn__p2____to_name_prime = "to";
		String p2__tPn____incoming_name_prime = "incoming";
		String fsm__tFsm____transitions_name_prime = "transitions";
		String tFsm__s2____endState_name_prime = "endState";
		String tPn__p1____from_name_prime = "from";
		String p1__tPn____outgoing_name_prime = "outgoing";
		String tToT__tFsm____source_name_prime = "source";
		String tFsm__s1____startState_name_prime = "startState";
		String s1__tFsm____transitions_name_prime = "transitions";
		String pn__tPn____transitions_name_prime = "transitions";
		tToT__tPn____target.setSrc(tToT);
		tToT__tPn____target.setTrg(tPn);
		ruleresult.getCreatedEdges().add(tToT__tPn____target);
		tPn__p2____to.setSrc(tPn);
		tPn__p2____to.setTrg(p2);
		ruleresult.getCreatedEdges().add(tPn__p2____to);
		p2__tPn____incoming.setSrc(p2);
		p2__tPn____incoming.setTrg(tPn);
		ruleresult.getCreatedEdges().add(p2__tPn____incoming);
		fsm__tFsm____transitions.setSrc(fsm);
		fsm__tFsm____transitions.setTrg(tFsm);
		ruleresult.getTranslatedEdges().add(fsm__tFsm____transitions);
		tFsm__s2____endState.setSrc(tFsm);
		tFsm__s2____endState.setTrg(s2);
		ruleresult.getTranslatedEdges().add(tFsm__s2____endState);
		tPn__p1____from.setSrc(tPn);
		tPn__p1____from.setTrg(p1);
		ruleresult.getCreatedEdges().add(tPn__p1____from);
		p1__tPn____outgoing.setSrc(p1);
		p1__tPn____outgoing.setTrg(tPn);
		ruleresult.getCreatedEdges().add(p1__tPn____outgoing);
		tToT__tFsm____source.setSrc(tToT);
		tToT__tFsm____source.setTrg(tFsm);
		ruleresult.getCreatedEdges().add(tToT__tFsm____source);
		tFsm__s1____startState.setSrc(tFsm);
		tFsm__s1____startState.setTrg(s1);
		ruleresult.getTranslatedEdges().add(tFsm__s1____startState);
		s1__tFsm____transitions.setSrc(s1);
		s1__tFsm____transitions.setTrg(tFsm);
		ruleresult.getTranslatedEdges().add(s1__tFsm____transitions);
		pn__tPn____transitions.setSrc(pn);
		pn__tPn____transitions.setTrg(tPn);
		ruleresult.getCreatedEdges().add(pn__tPn____transitions);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		tToT__tPn____target.setName(tToT__tPn____target_name_prime);
		tPn__p2____to.setName(tPn__p2____to_name_prime);
		p2__tPn____incoming.setName(p2__tPn____incoming_name_prime);
		fsm__tFsm____transitions.setName(fsm__tFsm____transitions_name_prime);
		tFsm__s2____endState.setName(tFsm__s2____endState_name_prime);
		tPn__p1____from.setName(tPn__p1____from_name_prime);
		p1__tPn____outgoing.setName(p1__tPn____outgoing_name_prime);
		tToT__tFsm____source.setName(tToT__tFsm____source_name_prime);
		tFsm__s1____startState.setName(tFsm__s1____startState_name_prime);
		s1__tFsm____transitions.setName(s1__tFsm____transitions_name_prime);
		pn__tPn____transitions.setName(pn__tPn____transitions_name_prime);
		return new Object[] { ruleresult, tToT, fsm, s2, tPn, p1, tFsm, s1, pn, p2, tToT__tPn____target, tPn__p2____to,
				p2__tPn____incoming, fsm__tFsm____transitions, tFsm__s2____endState, tPn__p1____from,
				p1__tPn____outgoing, tToT__tFsm____source, tFsm__s1____startState, s1__tFsm____transitions,
				pn__tPn____transitions };
	}

	public static final void pattern_TransitionToTransition_1_5_registerobjects_expressionBBBBBBBBBBBBBB(
			TransitionToTransition _this, PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2,
			EObject s2ToP2, EObject fsmToPn, EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2,
			EObject s1Top1) {
		_this.registerObjects_FWD(ruleresult, tToT, fsm, s2, s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);

	}

	public static final PerformRuleResult pattern_TransitionToTransition_1_6_expressionFB(
			PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_2_1_preparereturnvalue_bindingFB(
			TransitionToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_2_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitionToTransition _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_2_1_preparereturnvalue_bindingAndBlackFFB(
			TransitionToTransition _this) {
		Object[] result_pattern_TransitionToTransition_2_1_preparereturnvalue_binding = pattern_TransitionToTransition_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitionToTransition_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitionToTransition_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitionToTransition_2_1_preparereturnvalue_black = pattern_TransitionToTransition_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitionToTransition_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitionToTransition_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_2_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitionToTransition";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitionToTransition_2_2_corematch_bindingFFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("fsm");
		EObject _localVariable_1 = match.getObject("s2");
		EObject _localVariable_2 = match.getObject("tFsm");
		EObject _localVariable_3 = match.getObject("s1");
		EObject tmpFsm = _localVariable_0;
		EObject tmpS2 = _localVariable_1;
		EObject tmpTFsm = _localVariable_2;
		EObject tmpS1 = _localVariable_3;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpS2 instanceof State) {
				State s2 = (State) tmpS2;
				if (tmpTFsm instanceof Transition) {
					Transition tFsm = (Transition) tmpTFsm;
					if (tmpS1 instanceof State) {
						State s1 = (State) tmpS1;
						return new Object[] { fsm, s2, tFsm, s1, match };
					}
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_2_2_corematch_blackBBFFFBBFFFB(
			FiniteStateMachine fsm, State s2, Transition tFsm, State s1, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!s1.equals(s2)) {
			for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil
					.getOppositeReferenceTyped(fsm, StateMachineToPetriNet.class, "source")) {
				PetriNet pn = fsmToPn.getTarget();
				if (pn != null) {
					for (StateToPlace s2ToP2 : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s2,
							StateToPlace.class, "source")) {
						Place p2 = s2ToP2.getTarget();
						if (p2 != null) {
							for (StateToPlace s1Top1 : org.moflon.core.utilities.eMoflonEMFUtil
									.getOppositeReferenceTyped(s1, StateToPlace.class, "source")) {
								if (!s1Top1.equals(s2ToP2)) {
									Place p1 = s1Top1.getTarget();
									if (p1 != null) {
										if (!p1.equals(p2)) {
											_result.add(new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2,
													s1Top1, match });
										}
									}

								}
							}
						}

					}
				}

			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_2_3_findcontext_blackBBBBBBBBBB(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, StateToPlace s1Top1) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					if (fsm.getStates().contains(s2)) {
						if (fsm.equals(fsmToPn.getSource())) {
							if (fsm.getTransitions().contains(tFsm)) {
								if (s2.equals(tFsm.getEndState())) {
									if (s2.equals(s2ToP2.getSource())) {
										if (s1.equals(tFsm.getStartState())) {
											if (pn.getPlaces().contains(p2)) {
												if (pn.equals(fsmToPn.getTarget())) {
													if (pn.getPlaces().contains(p1)) {
														if (p2.equals(s2ToP2.getTarget())) {
															if (fsm.getStates().contains(s1)) {
																if (p1.equals(s1Top1.getTarget())) {
																	if (s1.equals(s1Top1.getSource())) {
																		_result.add(
																				new Object[] { fsm, s2, s2ToP2, fsmToPn,
																						p1, tFsm, s1, pn, p2, s1Top1 });
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_2_3_findcontext_greenBBBBBBBBBBFFFFFFFFFFFFFFF(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, StateToPlace s1Top1) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge fsm__s2____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s2____endState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2ToP2__s2____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s1____startState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p2____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p1____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2ToP2__p2____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s1____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1Top1__p1____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1Top1__s1____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String fsm__s2____states_name_prime = "states";
		String fsmToPn__fsm____source_name_prime = "source";
		String fsm__tFsm____transitions_name_prime = "transitions";
		String tFsm__s2____endState_name_prime = "endState";
		String s2ToP2__s2____source_name_prime = "source";
		String tFsm__s1____startState_name_prime = "startState";
		String s1__tFsm____transitions_name_prime = "transitions";
		String pn__p2____places_name_prime = "places";
		String fsmToPn__pn____target_name_prime = "target";
		String pn__p1____places_name_prime = "places";
		String s2ToP2__p2____target_name_prime = "target";
		String fsm__s1____states_name_prime = "states";
		String s1Top1__p1____target_name_prime = "target";
		String s1Top1__s1____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(fsm);
		isApplicableMatch.getAllContextElements().add(s2);
		isApplicableMatch.getAllContextElements().add(s2ToP2);
		isApplicableMatch.getAllContextElements().add(fsmToPn);
		isApplicableMatch.getAllContextElements().add(p1);
		isApplicableMatch.getAllContextElements().add(tFsm);
		isApplicableMatch.getAllContextElements().add(s1);
		isApplicableMatch.getAllContextElements().add(pn);
		isApplicableMatch.getAllContextElements().add(p2);
		isApplicableMatch.getAllContextElements().add(s1Top1);
		fsm__s2____states.setSrc(fsm);
		fsm__s2____states.setTrg(s2);
		isApplicableMatch.getAllContextElements().add(fsm__s2____states);
		fsmToPn__fsm____source.setSrc(fsmToPn);
		fsmToPn__fsm____source.setTrg(fsm);
		isApplicableMatch.getAllContextElements().add(fsmToPn__fsm____source);
		fsm__tFsm____transitions.setSrc(fsm);
		fsm__tFsm____transitions.setTrg(tFsm);
		isApplicableMatch.getAllContextElements().add(fsm__tFsm____transitions);
		tFsm__s2____endState.setSrc(tFsm);
		tFsm__s2____endState.setTrg(s2);
		isApplicableMatch.getAllContextElements().add(tFsm__s2____endState);
		s2ToP2__s2____source.setSrc(s2ToP2);
		s2ToP2__s2____source.setTrg(s2);
		isApplicableMatch.getAllContextElements().add(s2ToP2__s2____source);
		tFsm__s1____startState.setSrc(tFsm);
		tFsm__s1____startState.setTrg(s1);
		isApplicableMatch.getAllContextElements().add(tFsm__s1____startState);
		s1__tFsm____transitions.setSrc(s1);
		s1__tFsm____transitions.setTrg(tFsm);
		isApplicableMatch.getAllContextElements().add(s1__tFsm____transitions);
		pn__p2____places.setSrc(pn);
		pn__p2____places.setTrg(p2);
		isApplicableMatch.getAllContextElements().add(pn__p2____places);
		fsmToPn__pn____target.setSrc(fsmToPn);
		fsmToPn__pn____target.setTrg(pn);
		isApplicableMatch.getAllContextElements().add(fsmToPn__pn____target);
		pn__p1____places.setSrc(pn);
		pn__p1____places.setTrg(p1);
		isApplicableMatch.getAllContextElements().add(pn__p1____places);
		s2ToP2__p2____target.setSrc(s2ToP2);
		s2ToP2__p2____target.setTrg(p2);
		isApplicableMatch.getAllContextElements().add(s2ToP2__p2____target);
		fsm__s1____states.setSrc(fsm);
		fsm__s1____states.setTrg(s1);
		isApplicableMatch.getAllContextElements().add(fsm__s1____states);
		s1Top1__p1____target.setSrc(s1Top1);
		s1Top1__p1____target.setTrg(p1);
		isApplicableMatch.getAllContextElements().add(s1Top1__p1____target);
		s1Top1__s1____source.setSrc(s1Top1);
		s1Top1__s1____source.setTrg(s1);
		isApplicableMatch.getAllContextElements().add(s1Top1__s1____source);
		fsm__s2____states.setName(fsm__s2____states_name_prime);
		fsmToPn__fsm____source.setName(fsmToPn__fsm____source_name_prime);
		fsm__tFsm____transitions.setName(fsm__tFsm____transitions_name_prime);
		tFsm__s2____endState.setName(tFsm__s2____endState_name_prime);
		s2ToP2__s2____source.setName(s2ToP2__s2____source_name_prime);
		tFsm__s1____startState.setName(tFsm__s1____startState_name_prime);
		s1__tFsm____transitions.setName(s1__tFsm____transitions_name_prime);
		pn__p2____places.setName(pn__p2____places_name_prime);
		fsmToPn__pn____target.setName(fsmToPn__pn____target_name_prime);
		pn__p1____places.setName(pn__p1____places_name_prime);
		s2ToP2__p2____target.setName(s2ToP2__p2____target_name_prime);
		fsm__s1____states.setName(fsm__s1____states_name_prime);
		s1Top1__p1____target.setName(s1Top1__p1____target_name_prime);
		s1Top1__s1____source.setName(s1Top1__s1____source_name_prime);
		return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1, isApplicableMatch,
				fsm__s2____states, fsmToPn__fsm____source, fsm__tFsm____transitions, tFsm__s2____endState,
				s2ToP2__s2____source, tFsm__s1____startState, s1__tFsm____transitions, pn__p2____places,
				fsmToPn__pn____target, pn__p1____places, s2ToP2__p2____target, fsm__s1____states, s1Top1__p1____target,
				s1Top1__s1____source };
	}

	public static final Object[] pattern_TransitionToTransition_2_4_solveCSP_bindingFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, Transition tFsm, State s1, PetriNet pn,
			Place p2, StateToPlace s1Top1) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, tFsm,
				s1, pn, p2, s1Top1);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2,
					s1Top1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_2_4_solveCSP_bindingAndBlackFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, Transition tFsm, State s1, PetriNet pn,
			Place p2, StateToPlace s1Top1) {
		Object[] result_pattern_TransitionToTransition_2_4_solveCSP_binding = pattern_TransitionToTransition_2_4_solveCSP_bindingFBBBBBBBBBBBB(
				_this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2, s1Top1);
		if (result_pattern_TransitionToTransition_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_2_4_solveCSP_binding[0];

			Object[] result_pattern_TransitionToTransition_2_4_solveCSP_black = pattern_TransitionToTransition_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitionToTransition_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, tFsm, s1, pn, p2,
						s1Top1 };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_2_5_checkCSP_expressionFBB(TransitionToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitionToTransition_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitionToTransition";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitionToTransition_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_10_1_initialbindings_blackBBBBBB(
			TransitionToTransition _this, Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		if (!p1.equals(p2)) {
			return new Object[] { _this, match, tPn, p1, pn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_10_2_SolveCSP_bindingFBBBBBB(
			TransitionToTransition _this, Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, tPn, p1, pn, p2);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, tPn, p1, pn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_10_2_SolveCSP_bindingAndBlackFBBBBBB(
			TransitionToTransition _this, Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		Object[] result_pattern_TransitionToTransition_10_2_SolveCSP_binding = pattern_TransitionToTransition_10_2_SolveCSP_bindingFBBBBBB(
				_this, match, tPn, p1, pn, p2);
		if (result_pattern_TransitionToTransition_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_10_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitionToTransition_10_2_SolveCSP_black = pattern_TransitionToTransition_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitionToTransition_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, tPn, p1, pn, p2 };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_10_3_CheckCSP_expressionFBB(TransitionToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_10_4_collectelementstobetranslated_blackBBBBB(
			Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		if (!p1.equals(p2)) {
			return new Object[] { match, tPn, p1, pn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_10_4_collectelementstobetranslated_greenBBBBBFFFFF(
			Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		EMoflonEdge tPn__p2____to = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2__tPn____incoming = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p1____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p1__tPn____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__tPn____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(tPn);
		String tPn__p2____to_name_prime = "to";
		String p2__tPn____incoming_name_prime = "incoming";
		String tPn__p1____from_name_prime = "from";
		String p1__tPn____outgoing_name_prime = "outgoing";
		String pn__tPn____transitions_name_prime = "transitions";
		tPn__p2____to.setSrc(tPn);
		tPn__p2____to.setTrg(p2);
		match.getToBeTranslatedEdges().add(tPn__p2____to);
		p2__tPn____incoming.setSrc(p2);
		p2__tPn____incoming.setTrg(tPn);
		match.getToBeTranslatedEdges().add(p2__tPn____incoming);
		tPn__p1____from.setSrc(tPn);
		tPn__p1____from.setTrg(p1);
		match.getToBeTranslatedEdges().add(tPn__p1____from);
		p1__tPn____outgoing.setSrc(p1);
		p1__tPn____outgoing.setTrg(tPn);
		match.getToBeTranslatedEdges().add(p1__tPn____outgoing);
		pn__tPn____transitions.setSrc(pn);
		pn__tPn____transitions.setTrg(tPn);
		match.getToBeTranslatedEdges().add(pn__tPn____transitions);
		tPn__p2____to.setName(tPn__p2____to_name_prime);
		p2__tPn____incoming.setName(p2__tPn____incoming_name_prime);
		tPn__p1____from.setName(tPn__p1____from_name_prime);
		p1__tPn____outgoing.setName(p1__tPn____outgoing_name_prime);
		pn__tPn____transitions.setName(pn__tPn____transitions_name_prime);
		return new Object[] { match, tPn, p1, pn, p2, tPn__p2____to, p2__tPn____incoming, tPn__p1____from,
				p1__tPn____outgoing, pn__tPn____transitions };
	}

	public static final Object[] pattern_TransitionToTransition_10_5_collectcontextelements_blackBBBBB(Match match,
			PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		if (!p1.equals(p2)) {
			return new Object[] { match, tPn, p1, pn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_10_5_collectcontextelements_greenBBBBFF(Match match,
			Place p1, PetriNet pn, Place p2) {
		EMoflonEdge pn__p2____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p1____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(p1);
		match.getContextNodes().add(pn);
		match.getContextNodes().add(p2);
		String pn__p2____places_name_prime = "places";
		String pn__p1____places_name_prime = "places";
		pn__p2____places.setSrc(pn);
		pn__p2____places.setTrg(p2);
		match.getContextEdges().add(pn__p2____places);
		pn__p1____places.setSrc(pn);
		pn__p1____places.setTrg(p1);
		match.getContextEdges().add(pn__p1____places);
		pn__p2____places.setName(pn__p2____places_name_prime);
		pn__p1____places.setName(pn__p1____places_name_prime);
		return new Object[] { match, p1, pn, p2, pn__p2____places, pn__p1____places };
	}

	public static final void pattern_TransitionToTransition_10_6_registerobjectstomatch_expressionBBBBBB(
			TransitionToTransition _this, Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		_this.registerObjectsToMatch_BWD(match, tPn, p1, pn, p2);

	}

	public static final boolean pattern_TransitionToTransition_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_11_1_performtransformation_bindingFFFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("fsm");
		EObject _localVariable_1 = isApplicableMatch.getObject("s2");
		EObject _localVariable_2 = isApplicableMatch.getObject("s2ToP2");
		EObject _localVariable_3 = isApplicableMatch.getObject("fsmToPn");
		EObject _localVariable_4 = isApplicableMatch.getObject("tPn");
		EObject _localVariable_5 = isApplicableMatch.getObject("p1");
		EObject _localVariable_6 = isApplicableMatch.getObject("s1");
		EObject _localVariable_7 = isApplicableMatch.getObject("pn");
		EObject _localVariable_8 = isApplicableMatch.getObject("p2");
		EObject _localVariable_9 = isApplicableMatch.getObject("s1Top1");
		EObject tmpFsm = _localVariable_0;
		EObject tmpS2 = _localVariable_1;
		EObject tmpS2ToP2 = _localVariable_2;
		EObject tmpFsmToPn = _localVariable_3;
		EObject tmpTPn = _localVariable_4;
		EObject tmpP1 = _localVariable_5;
		EObject tmpS1 = _localVariable_6;
		EObject tmpPn = _localVariable_7;
		EObject tmpP2 = _localVariable_8;
		EObject tmpS1Top1 = _localVariable_9;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpS2 instanceof State) {
				State s2 = (State) tmpS2;
				if (tmpS2ToP2 instanceof StateToPlace) {
					StateToPlace s2ToP2 = (StateToPlace) tmpS2ToP2;
					if (tmpFsmToPn instanceof StateMachineToPetriNet) {
						StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) tmpFsmToPn;
						if (tmpTPn instanceof PetriNets.Transition) {
							PetriNets.Transition tPn = (PetriNets.Transition) tmpTPn;
							if (tmpP1 instanceof Place) {
								Place p1 = (Place) tmpP1;
								if (tmpS1 instanceof State) {
									State s1 = (State) tmpS1;
									if (tmpPn instanceof PetriNet) {
										PetriNet pn = (PetriNet) tmpPn;
										if (tmpP2 instanceof Place) {
											Place p2 = (Place) tmpP2;
											if (tmpS1Top1 instanceof StateToPlace) {
												StateToPlace s1Top1 = (StateToPlace) tmpS1Top1;
												return new Object[] { fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2,
														s1Top1, isApplicableMatch };
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_11_1_performtransformation_blackBBBBBBBBBBFBB(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn,
			PetriNets.Transition tPn, Place p1, State s1, PetriNet pn, Place p2, StateToPlace s1Top1,
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
						if (tmpCsp instanceof CSP) {
							CSP csp = (CSP) tmpCsp;
							return new Object[] { fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1, csp, _this,
									isApplicableMatch };
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_11_1_performtransformation_bindingAndBlackFFFFFFFFFFFBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitionToTransition_11_1_performtransformation_binding = pattern_TransitionToTransition_11_1_performtransformation_bindingFFFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitionToTransition_11_1_performtransformation_binding != null) {
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_TransitionToTransition_11_1_performtransformation_binding[0];
			State s2 = (State) result_pattern_TransitionToTransition_11_1_performtransformation_binding[1];
			StateToPlace s2ToP2 = (StateToPlace) result_pattern_TransitionToTransition_11_1_performtransformation_binding[2];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result_pattern_TransitionToTransition_11_1_performtransformation_binding[3];
			PetriNets.Transition tPn = (PetriNets.Transition) result_pattern_TransitionToTransition_11_1_performtransformation_binding[4];
			Place p1 = (Place) result_pattern_TransitionToTransition_11_1_performtransformation_binding[5];
			State s1 = (State) result_pattern_TransitionToTransition_11_1_performtransformation_binding[6];
			PetriNet pn = (PetriNet) result_pattern_TransitionToTransition_11_1_performtransformation_binding[7];
			Place p2 = (Place) result_pattern_TransitionToTransition_11_1_performtransformation_binding[8];
			StateToPlace s1Top1 = (StateToPlace) result_pattern_TransitionToTransition_11_1_performtransformation_binding[9];

			Object[] result_pattern_TransitionToTransition_11_1_performtransformation_black = pattern_TransitionToTransition_11_1_performtransformation_blackBBBBBBBBBBFBB(
					fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1, _this, isApplicableMatch);
			if (result_pattern_TransitionToTransition_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitionToTransition_11_1_performtransformation_black[10];

				return new Object[] { fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1, csp, _this,
						isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_11_1_performtransformation_greenFBBBFBB(
			FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, State s1, CSP csp) {
		FiniteStatesToPetriNets.TransitionToTransition tToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createTransitionToTransition();
		Transition tFsm = FiniteStateMachinesFactory.eINSTANCE.createTransition();
		Object _localVariable_0 = csp.getValue("tFsm", "input");
		tToT.setTarget(tPn);
		fsm.getTransitions().add(tFsm);
		tFsm.setEndState(s2);
		tToT.setSource(tFsm);
		tFsm.setStartState(s1);
		String tFsm_input_prime = (String) _localVariable_0;
		tFsm.setInput(tFsm_input_prime);
		return new Object[] { tToT, fsm, s2, tPn, tFsm, s1, csp };
	}

	public static final Object[] pattern_TransitionToTransition_11_2_collecttranslatedelements_blackBBB(
			FiniteStatesToPetriNets.TransitionToTransition tToT, PetriNets.Transition tPn, Transition tFsm) {
		return new Object[] { tToT, tPn, tFsm };
	}

	public static final Object[] pattern_TransitionToTransition_11_2_collecttranslatedelements_greenFBBB(
			FiniteStatesToPetriNets.TransitionToTransition tToT, PetriNets.Transition tPn, Transition tFsm) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(tToT);
		ruleresult.getTranslatedElements().add(tPn);
		ruleresult.getCreatedElements().add(tFsm);
		return new Object[] { ruleresult, tToT, tPn, tFsm };
	}

	public static final Object[] pattern_TransitionToTransition_11_3_bookkeepingforedges_blackBBBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject s2ToP2, EObject fsmToPn,
			EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2, EObject s1Top1) {
		if (!fsm.equals(tToT)) {
			if (!fsm.equals(s2)) {
				if (!fsm.equals(s2ToP2)) {
					if (!fsm.equals(fsmToPn)) {
						if (!fsm.equals(tPn)) {
							if (!fsm.equals(p1)) {
								if (!fsm.equals(tFsm)) {
									if (!fsm.equals(s1)) {
										if (!fsm.equals(pn)) {
											if (!fsm.equals(p2)) {
												if (!fsm.equals(s1Top1)) {
													if (!s2.equals(tToT)) {
														if (!s2.equals(s2ToP2)) {
															if (!s2.equals(tPn)) {
																if (!s2.equals(tFsm)) {
																	if (!s2ToP2.equals(tToT)) {
																		if (!s2ToP2.equals(tPn)) {
																			if (!s2ToP2.equals(tFsm)) {
																				if (!fsmToPn.equals(tToT)) {
																					if (!fsmToPn.equals(s2)) {
																						if (!fsmToPn.equals(s2ToP2)) {
																							if (!fsmToPn.equals(tPn)) {
																								if (!fsmToPn
																										.equals(p1)) {
																									if (!fsmToPn.equals(
																											tFsm)) {
																										if (!fsmToPn
																												.equals(s1)) {
																											if (!fsmToPn
																													.equals(pn)) {
																												if (!fsmToPn
																														.equals(p2)) {
																													if (!fsmToPn
																															.equals(s1Top1)) {
																														if (!tPn.equals(
																																tToT)) {
																															if (!p1.equals(
																																	tToT)) {
																																if (!p1.equals(
																																		s2)) {
																																	if (!p1.equals(
																																			s2ToP2)) {
																																		if (!p1.equals(
																																				tPn)) {
																																			if (!p1.equals(
																																					tFsm)) {
																																				if (!p1.equals(
																																						s1)) {
																																					if (!p1.equals(
																																							pn)) {
																																						if (!p1.equals(
																																								p2)) {
																																							if (!p1.equals(
																																									s1Top1)) {
																																								if (!tFsm
																																										.equals(tToT)) {
																																									if (!tFsm
																																											.equals(tPn)) {
																																										if (!s1.equals(
																																												tToT)) {
																																											if (!s1.equals(
																																													s2)) {
																																												if (!s1.equals(
																																														s2ToP2)) {
																																													if (!s1.equals(
																																															tPn)) {
																																														if (!s1.equals(
																																																tFsm)) {
																																															if (!s1.equals(
																																																	s1Top1)) {
																																																if (!pn.equals(
																																																		tToT)) {
																																																	if (!pn.equals(
																																																			s2)) {
																																																		if (!pn.equals(
																																																				s2ToP2)) {
																																																			if (!pn.equals(
																																																					tPn)) {
																																																				if (!pn.equals(
																																																						tFsm)) {
																																																					if (!pn.equals(
																																																							s1)) {
																																																						if (!pn.equals(
																																																								s1Top1)) {
																																																							if (!p2.equals(
																																																									tToT)) {
																																																								if (!p2.equals(
																																																										s2)) {
																																																									if (!p2.equals(
																																																											s2ToP2)) {
																																																										if (!p2.equals(
																																																												tPn)) {
																																																											if (!p2.equals(
																																																													tFsm)) {
																																																												if (!p2.equals(
																																																														s1)) {
																																																													if (!p2.equals(
																																																															pn)) {
																																																														if (!p2.equals(
																																																																s1Top1)) {
																																																															if (!s1Top1
																																																																	.equals(tToT)) {
																																																																if (!s1Top1
																																																																		.equals(s2)) {
																																																																	if (!s1Top1
																																																																			.equals(s2ToP2)) {
																																																																		if (!s1Top1
																																																																				.equals(tPn)) {
																																																																			if (!s1Top1
																																																																					.equals(tFsm)) {
																																																																				return new Object[] {
																																																																						ruleresult,
																																																																						tToT,
																																																																						fsm,
																																																																						s2,
																																																																						s2ToP2,
																																																																						fsmToPn,
																																																																						tPn,
																																																																						p1,
																																																																						tFsm,
																																																																						s1,
																																																																						pn,
																																																																						p2,
																																																																						s1Top1 };
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_11_3_bookkeepingforedges_greenBBBBBBBBBBFFFFFFFFFFF(
			PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2, EObject tPn, EObject p1, EObject tFsm,
			EObject s1, EObject pn, EObject p2) {
		EMoflonEdge tToT__tPn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p2____to = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2__tPn____incoming = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s2____endState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p1____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p1__tPn____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tToT__tFsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tFsm__s1____startState = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1__tFsm____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__tPn____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitionToTransition";
		String tToT__tPn____target_name_prime = "target";
		String tPn__p2____to_name_prime = "to";
		String p2__tPn____incoming_name_prime = "incoming";
		String fsm__tFsm____transitions_name_prime = "transitions";
		String tFsm__s2____endState_name_prime = "endState";
		String tPn__p1____from_name_prime = "from";
		String p1__tPn____outgoing_name_prime = "outgoing";
		String tToT__tFsm____source_name_prime = "source";
		String tFsm__s1____startState_name_prime = "startState";
		String s1__tFsm____transitions_name_prime = "transitions";
		String pn__tPn____transitions_name_prime = "transitions";
		tToT__tPn____target.setSrc(tToT);
		tToT__tPn____target.setTrg(tPn);
		ruleresult.getCreatedEdges().add(tToT__tPn____target);
		tPn__p2____to.setSrc(tPn);
		tPn__p2____to.setTrg(p2);
		ruleresult.getTranslatedEdges().add(tPn__p2____to);
		p2__tPn____incoming.setSrc(p2);
		p2__tPn____incoming.setTrg(tPn);
		ruleresult.getTranslatedEdges().add(p2__tPn____incoming);
		fsm__tFsm____transitions.setSrc(fsm);
		fsm__tFsm____transitions.setTrg(tFsm);
		ruleresult.getCreatedEdges().add(fsm__tFsm____transitions);
		tFsm__s2____endState.setSrc(tFsm);
		tFsm__s2____endState.setTrg(s2);
		ruleresult.getCreatedEdges().add(tFsm__s2____endState);
		tPn__p1____from.setSrc(tPn);
		tPn__p1____from.setTrg(p1);
		ruleresult.getTranslatedEdges().add(tPn__p1____from);
		p1__tPn____outgoing.setSrc(p1);
		p1__tPn____outgoing.setTrg(tPn);
		ruleresult.getTranslatedEdges().add(p1__tPn____outgoing);
		tToT__tFsm____source.setSrc(tToT);
		tToT__tFsm____source.setTrg(tFsm);
		ruleresult.getCreatedEdges().add(tToT__tFsm____source);
		tFsm__s1____startState.setSrc(tFsm);
		tFsm__s1____startState.setTrg(s1);
		ruleresult.getCreatedEdges().add(tFsm__s1____startState);
		s1__tFsm____transitions.setSrc(s1);
		s1__tFsm____transitions.setTrg(tFsm);
		ruleresult.getCreatedEdges().add(s1__tFsm____transitions);
		pn__tPn____transitions.setSrc(pn);
		pn__tPn____transitions.setTrg(tPn);
		ruleresult.getTranslatedEdges().add(pn__tPn____transitions);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		tToT__tPn____target.setName(tToT__tPn____target_name_prime);
		tPn__p2____to.setName(tPn__p2____to_name_prime);
		p2__tPn____incoming.setName(p2__tPn____incoming_name_prime);
		fsm__tFsm____transitions.setName(fsm__tFsm____transitions_name_prime);
		tFsm__s2____endState.setName(tFsm__s2____endState_name_prime);
		tPn__p1____from.setName(tPn__p1____from_name_prime);
		p1__tPn____outgoing.setName(p1__tPn____outgoing_name_prime);
		tToT__tFsm____source.setName(tToT__tFsm____source_name_prime);
		tFsm__s1____startState.setName(tFsm__s1____startState_name_prime);
		s1__tFsm____transitions.setName(s1__tFsm____transitions_name_prime);
		pn__tPn____transitions.setName(pn__tPn____transitions_name_prime);
		return new Object[] { ruleresult, tToT, fsm, s2, tPn, p1, tFsm, s1, pn, p2, tToT__tPn____target, tPn__p2____to,
				p2__tPn____incoming, fsm__tFsm____transitions, tFsm__s2____endState, tPn__p1____from,
				p1__tPn____outgoing, tToT__tFsm____source, tFsm__s1____startState, s1__tFsm____transitions,
				pn__tPn____transitions };
	}

	public static final void pattern_TransitionToTransition_11_5_registerobjects_expressionBBBBBBBBBBBBBB(
			TransitionToTransition _this, PerformRuleResult ruleresult, EObject tToT, EObject fsm, EObject s2,
			EObject s2ToP2, EObject fsmToPn, EObject tPn, EObject p1, EObject tFsm, EObject s1, EObject pn, EObject p2,
			EObject s1Top1) {
		_this.registerObjects_BWD(ruleresult, tToT, fsm, s2, s2ToP2, fsmToPn, tPn, p1, tFsm, s1, pn, p2, s1Top1);

	}

	public static final PerformRuleResult pattern_TransitionToTransition_11_6_expressionFB(
			PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_12_1_preparereturnvalue_bindingFB(
			TransitionToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_12_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitionToTransition _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_12_1_preparereturnvalue_bindingAndBlackFFB(
			TransitionToTransition _this) {
		Object[] result_pattern_TransitionToTransition_12_1_preparereturnvalue_binding = pattern_TransitionToTransition_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitionToTransition_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitionToTransition_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitionToTransition_12_1_preparereturnvalue_black = pattern_TransitionToTransition_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitionToTransition_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitionToTransition_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitionToTransition";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitionToTransition_12_2_corematch_bindingFFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("tPn");
		EObject _localVariable_1 = match.getObject("p1");
		EObject _localVariable_2 = match.getObject("pn");
		EObject _localVariable_3 = match.getObject("p2");
		EObject tmpTPn = _localVariable_0;
		EObject tmpP1 = _localVariable_1;
		EObject tmpPn = _localVariable_2;
		EObject tmpP2 = _localVariable_3;
		if (tmpTPn instanceof PetriNets.Transition) {
			PetriNets.Transition tPn = (PetriNets.Transition) tmpTPn;
			if (tmpP1 instanceof Place) {
				Place p1 = (Place) tmpP1;
				if (tmpPn instanceof PetriNet) {
					PetriNet pn = (PetriNet) tmpPn;
					if (tmpP2 instanceof Place) {
						Place p2 = (Place) tmpP2;
						return new Object[] { tPn, p1, pn, p2, match };
					}
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_12_2_corematch_blackFFFFBBFBBFB(
			PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!p1.equals(p2)) {
			for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(pn,
					StateMachineToPetriNet.class, "target")) {
				FiniteStateMachine fsm = fsmToPn.getSource();
				if (fsm != null) {
					for (StateToPlace s2ToP2 : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(p2,
							StateToPlace.class, "target")) {
						State s2 = s2ToP2.getSource();
						if (s2 != null) {
							for (StateToPlace s1Top1 : org.moflon.core.utilities.eMoflonEMFUtil
									.getOppositeReferenceTyped(p1, StateToPlace.class, "target")) {
								if (!s1Top1.equals(s2ToP2)) {
									State s1 = s1Top1.getSource();
									if (s1 != null) {
										if (!s1.equals(s2)) {
											_result.add(new Object[] { fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2,
													s1Top1, match });
										}
									}

								}
							}
						}

					}
				}

			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_12_3_findcontext_blackBBBBBBBBBB(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn,
			PetriNets.Transition tPn, Place p1, State s1, PetriNet pn, Place p2, StateToPlace s1Top1) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					if (fsm.getStates().contains(s2)) {
						if (tPn.getTo().contains(p2)) {
							if (fsm.equals(fsmToPn.getSource())) {
								if (tPn.getFrom().contains(p1)) {
									if (s2.equals(s2ToP2.getSource())) {
										if (pn.getPlaces().contains(p2)) {
											if (pn.equals(fsmToPn.getTarget())) {
												if (pn.getPlaces().contains(p1)) {
													if (p2.equals(s2ToP2.getTarget())) {
														if (pn.getTransitions().contains(tPn)) {
															if (fsm.getStates().contains(s1)) {
																if (p1.equals(s1Top1.getTarget())) {
																	if (s1.equals(s1Top1.getSource())) {
																		_result.add(new Object[] { fsm, s2, s2ToP2,
																				fsmToPn, tPn, p1, s1, pn, p2, s1Top1 });
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_12_3_findcontext_greenBBBBBBBBBBFFFFFFFFFFFFFFFF(
			FiniteStateMachine fsm, State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn,
			PetriNets.Transition tPn, Place p1, State s1, PetriNet pn, Place p2, StateToPlace s1Top1) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge fsm__s2____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p2____to = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2__tPn____incoming = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge tPn__p1____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p1__tPn____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2ToP2__s2____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p2____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p1____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2ToP2__p2____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__tPn____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s1____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1Top1__p1____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s1Top1__s1____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String fsm__s2____states_name_prime = "states";
		String tPn__p2____to_name_prime = "to";
		String p2__tPn____incoming_name_prime = "incoming";
		String fsmToPn__fsm____source_name_prime = "source";
		String tPn__p1____from_name_prime = "from";
		String p1__tPn____outgoing_name_prime = "outgoing";
		String s2ToP2__s2____source_name_prime = "source";
		String pn__p2____places_name_prime = "places";
		String fsmToPn__pn____target_name_prime = "target";
		String pn__p1____places_name_prime = "places";
		String s2ToP2__p2____target_name_prime = "target";
		String pn__tPn____transitions_name_prime = "transitions";
		String fsm__s1____states_name_prime = "states";
		String s1Top1__p1____target_name_prime = "target";
		String s1Top1__s1____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(fsm);
		isApplicableMatch.getAllContextElements().add(s2);
		isApplicableMatch.getAllContextElements().add(s2ToP2);
		isApplicableMatch.getAllContextElements().add(fsmToPn);
		isApplicableMatch.getAllContextElements().add(tPn);
		isApplicableMatch.getAllContextElements().add(p1);
		isApplicableMatch.getAllContextElements().add(s1);
		isApplicableMatch.getAllContextElements().add(pn);
		isApplicableMatch.getAllContextElements().add(p2);
		isApplicableMatch.getAllContextElements().add(s1Top1);
		fsm__s2____states.setSrc(fsm);
		fsm__s2____states.setTrg(s2);
		isApplicableMatch.getAllContextElements().add(fsm__s2____states);
		tPn__p2____to.setSrc(tPn);
		tPn__p2____to.setTrg(p2);
		isApplicableMatch.getAllContextElements().add(tPn__p2____to);
		p2__tPn____incoming.setSrc(p2);
		p2__tPn____incoming.setTrg(tPn);
		isApplicableMatch.getAllContextElements().add(p2__tPn____incoming);
		fsmToPn__fsm____source.setSrc(fsmToPn);
		fsmToPn__fsm____source.setTrg(fsm);
		isApplicableMatch.getAllContextElements().add(fsmToPn__fsm____source);
		tPn__p1____from.setSrc(tPn);
		tPn__p1____from.setTrg(p1);
		isApplicableMatch.getAllContextElements().add(tPn__p1____from);
		p1__tPn____outgoing.setSrc(p1);
		p1__tPn____outgoing.setTrg(tPn);
		isApplicableMatch.getAllContextElements().add(p1__tPn____outgoing);
		s2ToP2__s2____source.setSrc(s2ToP2);
		s2ToP2__s2____source.setTrg(s2);
		isApplicableMatch.getAllContextElements().add(s2ToP2__s2____source);
		pn__p2____places.setSrc(pn);
		pn__p2____places.setTrg(p2);
		isApplicableMatch.getAllContextElements().add(pn__p2____places);
		fsmToPn__pn____target.setSrc(fsmToPn);
		fsmToPn__pn____target.setTrg(pn);
		isApplicableMatch.getAllContextElements().add(fsmToPn__pn____target);
		pn__p1____places.setSrc(pn);
		pn__p1____places.setTrg(p1);
		isApplicableMatch.getAllContextElements().add(pn__p1____places);
		s2ToP2__p2____target.setSrc(s2ToP2);
		s2ToP2__p2____target.setTrg(p2);
		isApplicableMatch.getAllContextElements().add(s2ToP2__p2____target);
		pn__tPn____transitions.setSrc(pn);
		pn__tPn____transitions.setTrg(tPn);
		isApplicableMatch.getAllContextElements().add(pn__tPn____transitions);
		fsm__s1____states.setSrc(fsm);
		fsm__s1____states.setTrg(s1);
		isApplicableMatch.getAllContextElements().add(fsm__s1____states);
		s1Top1__p1____target.setSrc(s1Top1);
		s1Top1__p1____target.setTrg(p1);
		isApplicableMatch.getAllContextElements().add(s1Top1__p1____target);
		s1Top1__s1____source.setSrc(s1Top1);
		s1Top1__s1____source.setTrg(s1);
		isApplicableMatch.getAllContextElements().add(s1Top1__s1____source);
		fsm__s2____states.setName(fsm__s2____states_name_prime);
		tPn__p2____to.setName(tPn__p2____to_name_prime);
		p2__tPn____incoming.setName(p2__tPn____incoming_name_prime);
		fsmToPn__fsm____source.setName(fsmToPn__fsm____source_name_prime);
		tPn__p1____from.setName(tPn__p1____from_name_prime);
		p1__tPn____outgoing.setName(p1__tPn____outgoing_name_prime);
		s2ToP2__s2____source.setName(s2ToP2__s2____source_name_prime);
		pn__p2____places.setName(pn__p2____places_name_prime);
		fsmToPn__pn____target.setName(fsmToPn__pn____target_name_prime);
		pn__p1____places.setName(pn__p1____places_name_prime);
		s2ToP2__p2____target.setName(s2ToP2__p2____target_name_prime);
		pn__tPn____transitions.setName(pn__tPn____transitions_name_prime);
		fsm__s1____states.setName(fsm__s1____states_name_prime);
		s1Top1__p1____target.setName(s1Top1__p1____target_name_prime);
		s1Top1__s1____source.setName(s1Top1__s1____source_name_prime);
		return new Object[] { fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1, isApplicableMatch,
				fsm__s2____states, tPn__p2____to, p2__tPn____incoming, fsmToPn__fsm____source, tPn__p1____from,
				p1__tPn____outgoing, s2ToP2__s2____source, pn__p2____places, fsmToPn__pn____target, pn__p1____places,
				s2ToP2__p2____target, pn__tPn____transitions, fsm__s1____states, s1Top1__p1____target,
				s1Top1__s1____source };
	}

	public static final Object[] pattern_TransitionToTransition_12_4_solveCSP_bindingFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, PetriNets.Transition tPn, Place p1, State s1,
			PetriNet pn, Place p2, StateToPlace s1Top1) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1,
				pn, p2, s1Top1);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2,
					s1Top1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, PetriNets.Transition tPn, Place p1, State s1,
			PetriNet pn, Place p2, StateToPlace s1Top1) {
		Object[] result_pattern_TransitionToTransition_12_4_solveCSP_binding = pattern_TransitionToTransition_12_4_solveCSP_bindingFBBBBBBBBBBBB(
				_this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2, s1Top1);
		if (result_pattern_TransitionToTransition_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_12_4_solveCSP_binding[0];

			Object[] result_pattern_TransitionToTransition_12_4_solveCSP_black = pattern_TransitionToTransition_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitionToTransition_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, tPn, p1, s1, pn, p2,
						s1Top1 };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_12_5_checkCSP_expressionFBB(TransitionToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitionToTransition_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitionToTransition";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitionToTransition_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_20_1_preparereturnvalue_bindingFB(
			TransitionToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitionToTransition _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitionToTransition _this) {
		Object[] result_pattern_TransitionToTransition_20_1_preparereturnvalue_binding = pattern_TransitionToTransition_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitionToTransition_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitionToTransition_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitionToTransition_20_1_preparereturnvalue_black = pattern_TransitionToTransition_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitionToTransition_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitionToTransition_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitionToTransition_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Object[] pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_0BBB(
			PetriNets.Transition tPn, Place p1, Place p2) {
		if (!p1.equals(p2)) {
			for (Place __DEC_tPn_from_835998 : tPn.getFrom()) {
				if (!p1.equals(__DEC_tPn_from_835998)) {
					if (!p2.equals(__DEC_tPn_from_835998)) {
						return new Object[] { tPn, p1, p2 };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_1BBB(
			PetriNets.Transition tPn, Place p1, Place p2) {
		if (!p1.equals(p2)) {
			for (Place __DEC_tPn_to_178654 : tPn.getTo()) {
				if (!p1.equals(__DEC_tPn_to_178654)) {
					if (!p2.equals(__DEC_tPn_to_178654)) {
						return new Object[] { tPn, p1, p2 };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_2BB(
			PetriNets.Transition tPn, Place p2) {
		if (tPn.getFrom().contains(p2)) {
			return new Object[] { tPn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_3BB(
			PetriNets.Transition tPn, Place p1) {
		if (tPn.getTo().contains(p1)) {
			return new Object[] { tPn, p1 };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_20_2_testcorematchandDECs_blackFFFFB(
			EMoflonEdge _edge_to) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpTPn = _edge_to.getSrc();
		if (tmpTPn instanceof PetriNets.Transition) {
			PetriNets.Transition tPn = (PetriNets.Transition) tmpTPn;
			EObject tmpP2 = _edge_to.getTrg();
			if (tmpP2 instanceof Place) {
				Place p2 = (Place) tmpP2;
				if (tPn.getTo().contains(p2)) {
					if (pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_2BB(tPn, p2) == null) {
						for (Place p1 : tPn.getFrom()) {
							if (!p1.equals(p2)) {
								if (pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_0BBB(tPn, p1,
										p2) == null) {
									if (pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_1BBB(tPn, p1,
											p2) == null) {
										if (pattern_TransitionToTransition_20_2_testcorematchandDECs_black_nac_3BB(tPn,
												p1) == null) {
											for (PetriNet pn : org.moflon.core.utilities.eMoflonEMFUtil
													.getOppositeReferenceTyped(tPn, PetriNet.class, "transitions")) {
												if (pn.getPlaces().contains(p2)) {
													if (pn.getPlaces().contains(p1)) {
														_result.add(new Object[] { tPn, p1, pn, p2, _edge_to });
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitionToTransition_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(
			TransitionToTransition _this, Match match, PetriNets.Transition tPn, Place p1, PetriNet pn, Place p2) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, tPn, p1, pn, p2);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitionToTransition _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitionToTransition_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_21_1_preparereturnvalue_bindingFB(
			TransitionToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitionToTransition _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_21_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitionToTransition _this) {
		Object[] result_pattern_TransitionToTransition_21_1_preparereturnvalue_binding = pattern_TransitionToTransition_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitionToTransition_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitionToTransition_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitionToTransition_21_1_preparereturnvalue_black = pattern_TransitionToTransition_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitionToTransition_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitionToTransition_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitionToTransition_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_21_2_testcorematchandDECs_blackFFFFB(
			EMoflonEdge _edge_transitions) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpFsm = _edge_transitions.getSrc();
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			EObject tmpTFsm = _edge_transitions.getTrg();
			if (tmpTFsm instanceof Transition) {
				Transition tFsm = (Transition) tmpTFsm;
				if (fsm.getTransitions().contains(tFsm)) {
					State s2 = tFsm.getEndState();
					if (s2 != null) {
						if (fsm.getStates().contains(s2)) {
							State s1 = tFsm.getStartState();
							if (s1 != null) {
								if (!s1.equals(s2)) {
									if (fsm.getStates().contains(s1)) {
										_result.add(new Object[] { fsm, s2, tFsm, s1, _edge_transitions });
									}
								}
							}

						}
					}

				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitionToTransition_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(
			TransitionToTransition _this, Match match, FiniteStateMachine fsm, State s2, Transition tFsm, State s1) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, fsm, s2, tFsm, s1);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitionToTransition _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitionToTransition_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_24_1_prepare_blackB(TransitionToTransition _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitionToTransition_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_TransitionToTransition_24_2_matchsrctrgcontext_bindingFFFFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		EObject _localVariable_0 = sourceMatch.getObject("fsm");
		EObject _localVariable_1 = sourceMatch.getObject("s2");
		EObject _localVariable_2 = targetMatch.getObject("tPn");
		EObject _localVariable_3 = targetMatch.getObject("p1");
		EObject _localVariable_4 = sourceMatch.getObject("tFsm");
		EObject _localVariable_5 = sourceMatch.getObject("s1");
		EObject _localVariable_6 = targetMatch.getObject("pn");
		EObject _localVariable_7 = targetMatch.getObject("p2");
		EObject tmpFsm = _localVariable_0;
		EObject tmpS2 = _localVariable_1;
		EObject tmpTPn = _localVariable_2;
		EObject tmpP1 = _localVariable_3;
		EObject tmpTFsm = _localVariable_4;
		EObject tmpS1 = _localVariable_5;
		EObject tmpPn = _localVariable_6;
		EObject tmpP2 = _localVariable_7;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpS2 instanceof State) {
				State s2 = (State) tmpS2;
				if (tmpTPn instanceof PetriNets.Transition) {
					PetriNets.Transition tPn = (PetriNets.Transition) tmpTPn;
					if (tmpP1 instanceof Place) {
						Place p1 = (Place) tmpP1;
						if (tmpTFsm instanceof Transition) {
							Transition tFsm = (Transition) tmpTFsm;
							if (tmpS1 instanceof State) {
								State s1 = (State) tmpS1;
								if (tmpPn instanceof PetriNet) {
									PetriNet pn = (PetriNet) tmpPn;
									if (tmpP2 instanceof Place) {
										Place p2 = (Place) tmpP2;
										return new Object[] { fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch,
												targetMatch };
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_24_2_matchsrctrgcontext_blackBBBBBBBBBB(
			FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, Place p1, Transition tFsm, State s1,
			PetriNet pn, Place p2, Match sourceMatch, Match targetMatch) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!sourceMatch.equals(targetMatch)) {
					return new Object[] { fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding = pattern_TransitionToTransition_24_2_matchsrctrgcontext_bindingFFFFFFFFBB(
				sourceMatch, targetMatch);
		if (result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding != null) {
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[0];
			State s2 = (State) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[1];
			PetriNets.Transition tPn = (PetriNets.Transition) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[2];
			Place p1 = (Place) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[3];
			Transition tFsm = (Transition) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[4];
			State s1 = (State) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[5];
			PetriNet pn = (PetriNet) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[6];
			Place p2 = (Place) result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_binding[7];

			Object[] result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_black = pattern_TransitionToTransition_24_2_matchsrctrgcontext_blackBBBBBBBBBB(
					fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch);
			if (result_pattern_TransitionToTransition_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_24_3_solvecsp_bindingFBBBBBBBBBBB(
			TransitionToTransition _this, FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_8 = _this.isApplicable_solveCsp_CC(fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch,
				targetMatch);
		CSP csp = _localVariable_8;
		if (csp != null) {
			return new Object[] { csp, _this, fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_24_3_solvecsp_bindingAndBlackFBBBBBBBBBBB(
			TransitionToTransition _this, FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, Place p1,
			Transition tFsm, State s1, PetriNet pn, Place p2, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitionToTransition_24_3_solvecsp_binding = pattern_TransitionToTransition_24_3_solvecsp_bindingFBBBBBBBBBBB(
				_this, fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch);
		if (result_pattern_TransitionToTransition_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_24_3_solvecsp_binding[0];

			Object[] result_pattern_TransitionToTransition_24_3_solvecsp_black = pattern_TransitionToTransition_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_TransitionToTransition_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, fsm, s2, tPn, p1, tFsm, s1, pn, p2, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_24_5_matchcorrcontext_blackBBFFBBBBFBB(
			FiniteStateMachine fsm, State s2, Place p1, State s1, PetriNet pn, Place p2, Match sourceMatch,
			Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!sourceMatch.equals(targetMatch)) {
					for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil
							.getOppositeReferenceTyped(fsm, StateMachineToPetriNet.class, "source")) {
						if (pn.equals(fsmToPn.getTarget())) {
							for (StateToPlace s2ToP2 : org.moflon.core.utilities.eMoflonEMFUtil
									.getOppositeReferenceTyped(s2, StateToPlace.class, "source")) {
								if (p2.equals(s2ToP2.getTarget())) {
									for (StateToPlace s1Top1 : org.moflon.core.utilities.eMoflonEMFUtil
											.getOppositeReferenceTyped(p1, StateToPlace.class, "target")) {
										if (!s1Top1.equals(s2ToP2)) {
											if (s1.equals(s1Top1.getSource())) {
												_result.add(new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2,
														s1Top1, sourceMatch, targetMatch });
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_24_5_matchcorrcontext_greenBBBBBF(StateToPlace s2ToP2,
			StateMachineToPetriNet fsmToPn, StateToPlace s1Top1, Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "TransitionToTransition";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(s2ToP2);
		ccMatch.getAllContextElements().add(fsmToPn);
		ccMatch.getAllContextElements().add(s1Top1);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { s2ToP2, fsmToPn, s1Top1, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_TransitionToTransition_24_6_createcorrespondence_blackBBBBBBBBB(
			FiniteStateMachine fsm, State s2, PetriNets.Transition tPn, Place p1, Transition tFsm, State s1,
			PetriNet pn, Place p2, CCMatch ccMatch) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				return new Object[] { fsm, s2, tPn, p1, tFsm, s1, pn, p2, ccMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_24_6_createcorrespondence_greenFBBB(
			PetriNets.Transition tPn, Transition tFsm, CCMatch ccMatch) {
		FiniteStatesToPetriNets.TransitionToTransition tToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createTransitionToTransition();
		tToT.setTarget(tPn);
		tToT.setSource(tFsm);
		ccMatch.getCreateCorr().add(tToT);
		return new Object[] { tToT, tPn, tFsm, ccMatch };
	}

	public static final Object[] pattern_TransitionToTransition_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_TransitionToTransition_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "TransitionToTransition";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitionToTransition_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_27_1_matchtggpattern_blackBBBB(FiniteStateMachine fsm,
			State s2, Transition tFsm, State s1) {
		if (!s1.equals(s2)) {
			if (fsm.getStates().contains(s2)) {
				if (fsm.getTransitions().contains(tFsm)) {
					if (s2.equals(tFsm.getEndState())) {
						if (s1.equals(tFsm.getStartState())) {
							if (fsm.getStates().contains(s1)) {
								return new Object[] { fsm, s2, tFsm, s1 };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_0BBB(
			PetriNets.Transition tPn, Place p1, Place p2) {
		if (!p1.equals(p2)) {
			for (Place __DEC_tPn_from_105797 : tPn.getFrom()) {
				if (!p1.equals(__DEC_tPn_from_105797)) {
					if (!p2.equals(__DEC_tPn_from_105797)) {
						return new Object[] { tPn, p1, p2 };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_1BBB(
			PetriNets.Transition tPn, Place p1, Place p2) {
		if (!p1.equals(p2)) {
			for (Place __DEC_tPn_to_430396 : tPn.getTo()) {
				if (!p1.equals(__DEC_tPn_to_430396)) {
					if (!p2.equals(__DEC_tPn_to_430396)) {
						return new Object[] { tPn, p1, p2 };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_2BB(
			PetriNets.Transition tPn, Place p2) {
		if (tPn.getFrom().contains(p2)) {
			return new Object[] { tPn, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_3BB(
			PetriNets.Transition tPn, Place p1) {
		if (tPn.getTo().contains(p1)) {
			return new Object[] { tPn, p1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_28_1_matchtggpattern_blackBBBB(PetriNets.Transition tPn,
			Place p1, PetriNet pn, Place p2) {
		if (!p1.equals(p2)) {
			if (tPn.getTo().contains(p2)) {
				if (tPn.getFrom().contains(p1)) {
					if (pn.getPlaces().contains(p2)) {
						if (pn.getPlaces().contains(p1)) {
							if (pn.getTransitions().contains(tPn)) {
								if (pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_0BBB(tPn, p1,
										p2) == null) {
									if (pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_1BBB(tPn, p1,
											p2) == null) {
										if (pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_2BB(tPn,
												p2) == null) {
											if (pattern_TransitionToTransition_28_1_matchtggpattern_black_nac_3BB(tPn,
													p1) == null) {
												return new Object[] { tPn, p1, pn, p2 };
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitionToTransition_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_29_1_createresult_blackB(TransitionToTransition _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitionToTransition_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, FiniteStateMachine fsm) {
		if (ruleResult.getSourceObjects().contains(fsm)) {
			return new Object[] { ruleResult, fsm };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, State s2) {
		if (ruleResult.getSourceObjects().contains(s2)) {
			return new Object[] { ruleResult, s2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, StateToPlace s2ToP2) {
		if (ruleResult.getCorrObjects().contains(s2ToP2)) {
			return new Object[] { ruleResult, s2ToP2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_3BB(
			ModelgeneratorRuleResult ruleResult, Place p2) {
		if (ruleResult.getTargetObjects().contains(p2)) {
			return new Object[] { ruleResult, p2 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_4BB(
			ModelgeneratorRuleResult ruleResult, PetriNet pn) {
		if (ruleResult.getTargetObjects().contains(pn)) {
			return new Object[] { ruleResult, pn };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_5BB(
			ModelgeneratorRuleResult ruleResult, Place p1) {
		if (ruleResult.getTargetObjects().contains(p1)) {
			return new Object[] { ruleResult, p1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_6BB(
			ModelgeneratorRuleResult ruleResult, StateToPlace s1Top1) {
		if (ruleResult.getCorrObjects().contains(s1Top1)) {
			return new Object[] { ruleResult, s1Top1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_7BB(
			ModelgeneratorRuleResult ruleResult, State s1) {
		if (ruleResult.getSourceObjects().contains(s1)) {
			return new Object[] { ruleResult, s1 };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_8BB(
			ModelgeneratorRuleResult ruleResult, StateMachineToPetriNet fsmToPn) {
		if (ruleResult.getCorrObjects().contains(fsmToPn)) {
			return new Object[] { ruleResult, fsmToPn };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitionToTransition_29_2_isapplicablecore_blackFFFFFFFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList s2ToP2List : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpS2ToP2 : s2ToP2List.getEntryObjects()) {
				if (tmpS2ToP2 instanceof StateToPlace) {
					StateToPlace s2ToP2 = (StateToPlace) tmpS2ToP2;
					State s2 = s2ToP2.getSource();
					if (s2 != null) {
						Place p2 = s2ToP2.getTarget();
						if (p2 != null) {
							if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_2BB(ruleResult,
									s2ToP2) == null) {
								if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_1BB(ruleResult,
										s2) == null) {
									if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_3BB(ruleResult,
											p2) == null) {
										for (FiniteStateMachine fsm : org.moflon.core.utilities.eMoflonEMFUtil
												.getOppositeReferenceTyped(s2, FiniteStateMachine.class, "states")) {
											if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_0BB(
													ruleResult, fsm) == null) {
												for (State s1 : fsm.getStates()) {
													if (!s1.equals(s2)) {
														if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_7BB(
																ruleResult, s1) == null) {
															for (PetriNet pn : org.moflon.core.utilities.eMoflonEMFUtil
																	.getOppositeReferenceTyped(p2, PetriNet.class,
																			"places")) {
																if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_4BB(
																		ruleResult, pn) == null) {
																	for (Place p1 : pn.getPlaces()) {
																		if (!p1.equals(p2)) {
																			if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_5BB(
																					ruleResult, p1) == null) {
																				for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil
																						.getOppositeReferenceTyped(fsm,
																								StateMachineToPetriNet.class,
																								"source")) {
																					if (pn.equals(
																							fsmToPn.getTarget())) {
																						if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_8BB(
																								ruleResult,
																								fsmToPn) == null) {
																							for (StateToPlace s1Top1 : org.moflon.core.utilities.eMoflonEMFUtil
																									.getOppositeReferenceTyped(
																											s1,
																											StateToPlace.class,
																											"source")) {
																								if (!s1Top1.equals(
																										s2ToP2)) {
																									if (p1.equals(s1Top1
																											.getTarget())) {
																										if (pattern_TransitionToTransition_29_2_isapplicablecore_black_nac_6BB(
																												ruleResult,
																												s1Top1) == null) {
																											_result.add(
																													new Object[] {
																															s2ToP2List,
																															fsm,
																															s2,
																															s2ToP2,
																															p2,
																															pn,
																															p1,
																															s1Top1,
																															s1,
																															fsmToPn,
																															ruleEntryContainer,
																															ruleResult });
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_29_3_solveCSP_bindingFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, State s1, PetriNet pn, Place p2,
			StateToPlace s1Top1, ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, s1, pn,
				p2, s1Top1, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1,
					ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitionToTransition_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBBB(
			TransitionToTransition _this, IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm, State s2,
			StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, State s1, PetriNet pn, Place p2,
			StateToPlace s1Top1, ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_TransitionToTransition_29_3_solveCSP_binding = pattern_TransitionToTransition_29_3_solveCSP_bindingFBBBBBBBBBBBB(
				_this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1, ruleResult);
		if (result_pattern_TransitionToTransition_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitionToTransition_29_3_solveCSP_binding[0];

			Object[] result_pattern_TransitionToTransition_29_3_solveCSP_black = pattern_TransitionToTransition_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_TransitionToTransition_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1,
						ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitionToTransition_29_4_checkCSP_expressionFBB(TransitionToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitionToTransition_29_5_checknacs_blackBBBBBBBBB(FiniteStateMachine fsm,
			State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, State s1, PetriNet pn, Place p2,
			StateToPlace s1Top1) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1 };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_6_perform_blackBBBBBBBBBB(FiniteStateMachine fsm,
			State s2, StateToPlace s2ToP2, StateMachineToPetriNet fsmToPn, Place p1, State s1, PetriNet pn, Place p2,
			StateToPlace s1Top1, ModelgeneratorRuleResult ruleResult) {
		if (!p1.equals(p2)) {
			if (!s1.equals(s2)) {
				if (!s1Top1.equals(s2ToP2)) {
					return new Object[] { fsm, s2, s2ToP2, fsmToPn, p1, s1, pn, p2, s1Top1, ruleResult };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitionToTransition_29_6_perform_greenFBBFBFBBBBB(FiniteStateMachine fsm,
			State s2, Place p1, State s1, PetriNet pn, Place p2, ModelgeneratorRuleResult ruleResult, CSP csp) {
		FiniteStatesToPetriNets.TransitionToTransition tToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createTransitionToTransition();
		PetriNets.Transition tPn = PetriNetsFactory.eINSTANCE.createTransition();
		Transition tFsm = FiniteStateMachinesFactory.eINSTANCE.createTransition();
		Object _localVariable_0 = csp.getValue("tPn", "input");
		Object _localVariable_1 = csp.getValue("tFsm", "input");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		ruleResult.getCorrObjects().add(tToT);
		tToT.setTarget(tPn);
		tPn.getTo().add(p2);
		tPn.getFrom().add(p1);
		pn.getTransitions().add(tPn);
		ruleResult.getTargetObjects().add(tPn);
		fsm.getTransitions().add(tFsm);
		tFsm.setEndState(s2);
		tToT.setSource(tFsm);
		tFsm.setStartState(s1);
		ruleResult.getSourceObjects().add(tFsm);
		String tPn_input_prime = (String) _localVariable_0;
		String tFsm_input_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		tPn.setInput(tPn_input_prime);
		tFsm.setInput(tFsm_input_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { tToT, fsm, s2, tPn, p1, tFsm, s1, pn, p2, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_TransitionToTransition_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TransitionToTransitionImpl
