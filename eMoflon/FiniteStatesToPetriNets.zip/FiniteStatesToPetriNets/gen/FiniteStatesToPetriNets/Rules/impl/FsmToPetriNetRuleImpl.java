/**
 */
package FiniteStatesToPetriNets.Rules.impl;

import FiniteStateMachines.FiniteStateMachine;
import FiniteStateMachines.FiniteStateMachinesFactory;

import FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory;

import FiniteStatesToPetriNets.Rules.FsmToPetriNetRule;
import FiniteStatesToPetriNets.Rules.RulesPackage;

import FiniteStatesToPetriNets.StateMachineToPetriNet;

import PetriNets.PetriNet;
import PetriNets.PetriNetsFactory;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.csp.*;
import csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fsm To Petri Net Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class FsmToPetriNetRuleImpl extends AbstractRuleImpl implements FsmToPetriNetRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FsmToPetriNetRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.Literals.FSM_TO_PETRI_NET_RULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, FiniteStateMachine fsm) {
		// initial bindings
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_1_initialbindings_blackBBB(this,
				match, fsm);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching in node [initial bindings] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[match] = " + match + ", " + "[fsm] = " + fsm + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_0_2_SolveCSP_bindingAndBlackFBBB(this, match, fsm);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[fsm] = " + fsm + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_0_4_collectelementstobetranslated_blackBB(match, fsm);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ".");
			}
			FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_4_collectelementstobetranslated_greenBB(match, fsm);

			// collect context elements
			Object[] result5_black = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_0_5_collectcontextelements_blackBB(match, fsm);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ".");
			}
			// register objects to match
			FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_6_registerobjectstomatch_expressionBBB(this, match, fsm);
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_7_expressionF();
		} else {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_1_1_performtransformation_bindingAndBlackFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[0];
		CSP csp = (CSP) result1_bindingAndBlack[1];
		Object[] result1_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_1_1_performtransformation_greenBFFB(fsm, csp);
		StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result1_green[1];
		PetriNet pn = (PetriNet) result1_green[2];

		// collect translated elements
		Object[] result2_black = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_1_2_collecttranslatedelements_blackBBB(fsm, fsmToPn, pn);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[fsm] = " + fsm + ", " + "[fsmToPn] = " + fsmToPn + ", " + "[pn] = " + pn + ".");
		}
		Object[] result2_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_1_2_collecttranslatedelements_greenFBBB(fsm, fsmToPn, pn);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_1_3_bookkeepingforedges_blackBBBB(ruleresult, fsm, fsmToPn, pn);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[fsm] = " + fsm + ", " + "[fsmToPn] = " + fsmToPn + ", "
					+ "[pn] = " + pn + ".");
		}
		FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_1_3_bookkeepingforedges_greenBBBBFF(ruleresult, fsm, fsmToPn,
				pn);
		// EMoflonEdge fsmToPn__fsm____source = (EMoflonEdge) result3_green[4];
		// EMoflonEdge fsmToPn__pn____target = (EMoflonEdge) result3_green[5];

		// perform postprocessing story node is empty
		// register objects
		FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_1_5_registerobjects_expressionBBBBB(this, ruleresult, fsm,
				fsmToPn, pn);
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_2_corematch_bindingFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result2_binding[0];
		for (Object[] result2_black : FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_2_corematch_blackBB(fsm,
				match)) {
			// ForEach find context
			for (Object[] result3_black : FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_3_findcontext_blackB(fsm)) {
				Object[] result3_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_3_findcontext_greenBF(fsm);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[1];

				// solve CSP
				Object[] result4_bindingAndBlack = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_2_4_solveCSP_bindingAndBlackFBBB(this, isApplicableMatch, fsm);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[fsm] = " + fsm + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = FsmToPetriNetRuleImpl
							.pattern_FsmToPetriNetRule_2_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, FiniteStateMachine fsm) {
		match.registerObject("fsm", fsm);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, FiniteStateMachine fsm) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm.id", true, csp);
		var_fsm_id.setValue(fsm.getId());
		var_fsm_id.setType("String");

		// Create unbound variables
		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn.id", csp);
		var_pn_id.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_fsm_id, var_pn_id);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("fsm", fsm);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("fsmToPn", fsmToPn);
		ruleresult.registerObject("pn", pn);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("fsm").eClass())
				.equals("FiniteStateMachines.FiniteStateMachine.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, PetriNet pn) {
		// initial bindings
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_1_initialbindings_blackBBB(this,
				match, pn);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching in node [initial bindings] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[match] = " + match + ", " + "[pn] = " + pn + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_10_2_SolveCSP_bindingAndBlackFBBB(this, match, pn);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[pn] = " + pn + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_10_4_collectelementstobetranslated_blackBB(match, pn);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[pn] = " + pn + ".");
			}
			FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_4_collectelementstobetranslated_greenBB(match, pn);

			// collect context elements
			Object[] result5_black = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_10_5_collectcontextelements_blackBB(match, pn);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[pn] = " + pn + ".");
			}
			// register objects to match
			FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_6_registerobjectstomatch_expressionBBB(this, match, pn);
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_7_expressionF();
		} else {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_11_1_performtransformation_bindingAndBlackFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		PetriNet pn = (PetriNet) result1_bindingAndBlack[0];
		CSP csp = (CSP) result1_bindingAndBlack[1];
		Object[] result1_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_11_1_performtransformation_greenFFBB(pn, csp);
		FiniteStateMachine fsm = (FiniteStateMachine) result1_green[0];
		StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result1_green[1];

		// collect translated elements
		Object[] result2_black = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_11_2_collecttranslatedelements_blackBBB(fsm, fsmToPn, pn);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[fsm] = " + fsm + ", " + "[fsmToPn] = " + fsmToPn + ", " + "[pn] = " + pn + ".");
		}
		Object[] result2_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_11_2_collecttranslatedelements_greenFBBB(fsm, fsmToPn, pn);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_11_3_bookkeepingforedges_blackBBBB(ruleresult, fsm, fsmToPn, pn);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[fsm] = " + fsm + ", " + "[fsmToPn] = " + fsmToPn + ", "
					+ "[pn] = " + pn + ".");
		}
		FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_11_3_bookkeepingforedges_greenBBBBFF(ruleresult, fsm, fsmToPn,
				pn);
		// EMoflonEdge fsmToPn__fsm____source = (EMoflonEdge) result3_green[4];
		// EMoflonEdge fsmToPn__pn____target = (EMoflonEdge) result3_green[5];

		// perform postprocessing story node is empty
		// register objects
		FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_11_5_registerobjects_expressionBBBBB(this, ruleresult, fsm,
				fsmToPn, pn);
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_2_corematch_bindingFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		PetriNet pn = (PetriNet) result2_binding[0];
		for (Object[] result2_black : FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_2_corematch_blackBB(pn,
				match)) {
			// ForEach find context
			for (Object[] result3_black : FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_3_findcontext_blackB(pn)) {
				Object[] result3_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_3_findcontext_greenBF(pn);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[1];

				// solve CSP
				Object[] result4_bindingAndBlack = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_12_4_solveCSP_bindingAndBlackFBBB(this, isApplicableMatch, pn);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[pn] = " + pn + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = FsmToPetriNetRuleImpl
							.pattern_FsmToPetriNetRule_12_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, PetriNet pn) {
		match.registerObject("pn", pn);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, PetriNet pn) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, PetriNet pn) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn.id", true, csp);
		var_pn_id.setValue(pn.getId());
		var_pn_id.setType("String");

		// Create unbound variables
		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm.id", csp);
		var_fsm_id.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_fsm_id, var_pn_id);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("pn", pn);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("fsmToPn", fsmToPn);
		ruleresult.registerObject("pn", pn);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true
				&& org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("pn").eClass()).equals("PetriNets.PetriNet.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_PetriNet_3(PetriNet pn) {
		// prepare return value
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_20_2_testcorematchandDECs_blackB(pn)) {
			Object[] result2_green = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBB(this,
							match, pn)) {
				// Ensure that the correct types of elements are matched
				if (FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = FsmToPetriNetRuleImpl
							.pattern_FsmToPetriNetRule_20_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_FiniteStateMachine_3(FiniteStateMachine fsm) {
		// prepare return value
		Object[] result1_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_21_2_testcorematchandDECs_blackB(fsm)) {
			Object[] result2_green = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBB(this,
							match, fsm)) {
				// Ensure that the correct types of elements are matched
				if (FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = FsmToPetriNetRuleImpl
							.pattern_FsmToPetriNetRule_21_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("FsmToPetriNetRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm", true, csp);
		var_fsm_id.setValue(__helper.getValue("fsm", "id"));
		var_fsm_id.setType("String");

		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn", true, csp);
		var_pn_id.setValue(__helper.getValue("pn", "id"));
		var_pn_id.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("FsmToPetriNetRule");
		eq0.solve(var_fsm_id, var_pn_id);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_pn_id.setBound(false);
			eq0.solve(var_fsm_id, var_pn_id);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("pn", "id", var_pn_id.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("FsmToPetriNetRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm", true, csp);
		var_fsm_id.setValue(__helper.getValue("fsm", "id"));
		var_fsm_id.setType("String");

		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn", true, csp);
		var_pn_id.setValue(__helper.getValue("pn", "id"));
		var_pn_id.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("FsmToPetriNetRule");
		eq0.solve(var_fsm_id, var_pn_id);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_fsm_id.setBound(false);
			eq0.solve(var_fsm_id, var_pn_id);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("fsm", "id", var_fsm_id.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {
		// prepare
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [prepare] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		// match src trg context
		Object[] result2_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_bindingAndBlackFFBB(sourceMatch, targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [match src trg context] failed." + " Variables: "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result2_bindingAndBlack[0];
		PetriNet pn = (PetriNet) result2_bindingAndBlack[1];

		// solve csp
		Object[] result3_bindingAndBlack = FsmToPetriNetRuleImpl
				.pattern_FsmToPetriNetRule_24_3_solvecsp_bindingAndBlackFBBBBB(this, fsm, pn, sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [solve csp] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[fsm] = " + fsm + ", " + "[pn] = " + pn + ", " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// check CSP
		if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach match corr context
			for (Object[] result5_black : FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_24_5_matchcorrcontext_blackBB(sourceMatch, targetMatch)) {
				Object[] result5_green = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_24_5_matchcorrcontext_greenBBF(sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[2];

				// create correspondence
				Object[] result6_black = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_24_6_createcorrespondence_blackBBB(fsm, pn, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException(
							"Pattern matching in node [create correspondence] failed." + " Variables: " + "[fsm] = "
									+ fsm + ", " + "[pn] = " + pn + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_6_createcorrespondence_greenBFBB(fsm, pn, ccMatch);
				// StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result6_green[1];

				// add to returned result
				Object[] result7_black = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching in node [add to returned result] failed."
							+ " Variables: " + "[result] = " + result + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(FiniteStateMachine fsm, PetriNet pn, Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm.id", true, csp);
		var_fsm_id.setValue(fsm.getId());
		var_fsm_id.setType("String");
		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn.id", true, csp);
		var_pn_id.setValue(pn.getId());
		var_pn_id.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_fsm_id, var_pn_id);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(FiniteStateMachine fsm) {// match tgg pattern
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_27_1_matchtggpattern_blackB(fsm);
		if (result1_black != null) {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_27_2_expressionF();
		} else {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(PetriNet pn) {// match tgg pattern
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_28_1_matchtggpattern_blackB(pn);
		if (result1_black != null) {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_28_2_expressionF();
		} else {
			return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer) {
		// create result
		Object[] result1_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [create result] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// is applicable core
		Object[] result2_black = FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_2_isapplicablecore_blackB(this);
		if (result2_black != null) {

			// solve CSP
			Object[] result3_bindingAndBlack = FsmToPetriNetRuleImpl
					.pattern_FsmToPetriNetRule_29_3_solveCSP_bindingAndBlackFBBB(this, isApplicableMatch, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = "
						+ this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ", " + "[ruleResult] = "
						+ ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// check CSP
			if (FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// check nacs story node is empty

				// perform
				Object[] result6_black = FsmToPetriNetRuleImpl
						.pattern_FsmToPetriNetRule_29_6_perform_blackB(ruleResult);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching in node [perform] failed." + " Variables: "
							+ "[ruleResult] = " + ruleResult + ".");
				}
				FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_6_perform_greenFFFBB(ruleResult, csp);
				// FiniteStateMachine fsm = (FiniteStateMachine) result6_green[0];
				// StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result6_green[1];
				// PetriNet pn = (PetriNet) result6_green[2];

			} else {
			}

		} else {
		}
		return FsmToPetriNetRuleImpl.pattern_FsmToPetriNetRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_fsm_id = CSPFactoryHelper.eINSTANCE.createVariable("fsm.id", csp);
		var_fsm_id.setType("String");
		Variable var_pn_id = CSPFactoryHelper.eINSTANCE.createVariable("pn.id", csp);
		var_pn_id.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_fsm_id, var_pn_id);

		// Snapshot pattern match on which CSP is solved
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE:
			return isAppropriate_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1));
			return null;
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0),
					(FiniteStateMachine) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3));
			return null;
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD__MATCH_PETRINET:
			return isAppropriate_BWD((Match) arguments.get(0), (PetriNet) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PETRINET:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (PetriNet) arguments.get(1));
			return null;
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PETRINET:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (PetriNet) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (PetriNet) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3));
			return null;
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD_PETRI_NET_3__PETRINET:
			return isAppropriate_BWD_PetriNet_3((PetriNet) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD_FINITE_STATE_MACHINE_3__FINITESTATEMACHINE:
			return isAppropriate_FWD_FiniteStateMachine_3((FiniteStateMachine) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_PETRINET_MATCH_MATCH:
			return isApplicable_solveCsp_CC((FiniteStateMachine) arguments.get(0), (PetriNet) arguments.get(1),
					(Match) arguments.get(2), (Match) arguments.get(3));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE:
			return checkDEC_FWD((FiniteStateMachine) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___CHECK_DEC_BWD__PETRINET:
			return checkDEC_BWD((PetriNet) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___GENERATE_MODEL__RULEENTRYCONTAINER:
			return generateModel((RuleEntryContainer) arguments.get(0));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0),
					(ModelgeneratorRuleResult) arguments.get(1));
		case RulesPackage.FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_1_initialbindings_blackBBB(FsmToPetriNetRule _this,
			Match match, FiniteStateMachine fsm) {
		return new Object[] { _this, match, fsm };
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_2_SolveCSP_bindingFBBB(FsmToPetriNetRule _this,
			Match match, FiniteStateMachine fsm) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, fsm);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, fsm };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_2_SolveCSP_bindingAndBlackFBBB(FsmToPetriNetRule _this,
			Match match, FiniteStateMachine fsm) {
		Object[] result_pattern_FsmToPetriNetRule_0_2_SolveCSP_binding = pattern_FsmToPetriNetRule_0_2_SolveCSP_bindingFBBB(
				_this, match, fsm);
		if (result_pattern_FsmToPetriNetRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_0_2_SolveCSP_black = pattern_FsmToPetriNetRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, fsm };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_0_3_CheckCSP_expressionFBB(FsmToPetriNetRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_4_collectelementstobetranslated_blackBB(Match match,
			FiniteStateMachine fsm) {
		return new Object[] { match, fsm };
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_4_collectelementstobetranslated_greenBB(Match match,
			FiniteStateMachine fsm) {
		match.getToBeTranslatedNodes().add(fsm);
		return new Object[] { match, fsm };
	}

	public static final Object[] pattern_FsmToPetriNetRule_0_5_collectcontextelements_blackBB(Match match,
			FiniteStateMachine fsm) {
		return new Object[] { match, fsm };
	}

	public static final void pattern_FsmToPetriNetRule_0_6_registerobjectstomatch_expressionBBB(FsmToPetriNetRule _this,
			Match match, FiniteStateMachine fsm) {
		_this.registerObjectsToMatch_FWD(match, fsm);

	}

	public static final boolean pattern_FsmToPetriNetRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_1_performtransformation_bindingFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("fsm");
		EObject tmpFsm = _localVariable_0;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			return new Object[] { fsm, isApplicableMatch };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_1_performtransformation_blackBFBB(FiniteStateMachine fsm,
			FsmToPetriNetRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { fsm, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_1_performtransformation_bindingAndBlackFFBB(
			FsmToPetriNetRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_FsmToPetriNetRule_1_1_performtransformation_binding = pattern_FsmToPetriNetRule_1_1_performtransformation_bindingFB(
				isApplicableMatch);
		if (result_pattern_FsmToPetriNetRule_1_1_performtransformation_binding != null) {
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_FsmToPetriNetRule_1_1_performtransformation_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_1_1_performtransformation_black = pattern_FsmToPetriNetRule_1_1_performtransformation_blackBFBB(
					fsm, _this, isApplicableMatch);
			if (result_pattern_FsmToPetriNetRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_FsmToPetriNetRule_1_1_performtransformation_black[1];

				return new Object[] { fsm, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_1_performtransformation_greenBFFB(FiniteStateMachine fsm,
			CSP csp) {
		StateMachineToPetriNet fsmToPn = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateMachineToPetriNet();
		PetriNet pn = PetriNetsFactory.eINSTANCE.createPetriNet();
		Object _localVariable_0 = csp.getValue("pn", "id");
		fsmToPn.setSource(fsm);
		fsmToPn.setTarget(pn);
		String pn_id_prime = (String) _localVariable_0;
		pn.setId(pn_id_prime);
		return new Object[] { fsm, fsmToPn, pn, csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_2_collecttranslatedelements_blackBBB(
			FiniteStateMachine fsm, StateMachineToPetriNet fsmToPn, PetriNet pn) {
		return new Object[] { fsm, fsmToPn, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_2_collecttranslatedelements_greenFBBB(
			FiniteStateMachine fsm, StateMachineToPetriNet fsmToPn, PetriNet pn) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getTranslatedElements().add(fsm);
		ruleresult.getCreatedLinkElements().add(fsmToPn);
		ruleresult.getCreatedElements().add(pn);
		return new Object[] { ruleresult, fsm, fsmToPn, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_3_bookkeepingforedges_blackBBBB(
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		if (!fsm.equals(fsmToPn)) {
			if (!fsm.equals(pn)) {
				if (!fsmToPn.equals(pn)) {
					return new Object[] { ruleresult, fsm, fsmToPn, pn };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_1_3_bookkeepingforedges_greenBBBBFF(
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		EMoflonEdge fsmToPn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "FsmToPetriNetRule";
		String fsmToPn__fsm____source_name_prime = "source";
		String fsmToPn__pn____target_name_prime = "target";
		fsmToPn__fsm____source.setSrc(fsmToPn);
		fsmToPn__fsm____source.setTrg(fsm);
		ruleresult.getCreatedEdges().add(fsmToPn__fsm____source);
		fsmToPn__pn____target.setSrc(fsmToPn);
		fsmToPn__pn____target.setTrg(pn);
		ruleresult.getCreatedEdges().add(fsmToPn__pn____target);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		fsmToPn__fsm____source.setName(fsmToPn__fsm____source_name_prime);
		fsmToPn__pn____target.setName(fsmToPn__pn____target_name_prime);
		return new Object[] { ruleresult, fsm, fsmToPn, pn, fsmToPn__fsm____source, fsmToPn__pn____target };
	}

	public static final void pattern_FsmToPetriNetRule_1_5_registerobjects_expressionBBBBB(FsmToPetriNetRule _this,
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		_this.registerObjects_FWD(ruleresult, fsm, fsmToPn, pn);

	}

	public static final PerformRuleResult pattern_FsmToPetriNetRule_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_1_preparereturnvalue_bindingFB(FsmToPetriNetRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			FsmToPetriNetRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			FsmToPetriNetRule _this) {
		Object[] result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_binding = pattern_FsmToPetriNetRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_black = pattern_FsmToPetriNetRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_FsmToPetriNetRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_1_preparereturnvalue_greenBF(EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "FsmToPetriNetRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_2_corematch_bindingFB(Match match) {
		EObject _localVariable_0 = match.getObject("fsm");
		EObject tmpFsm = _localVariable_0;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			return new Object[] { fsm, match };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_2_2_corematch_blackBB(FiniteStateMachine fsm,
			Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { fsm, match });
		return _result;
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_2_3_findcontext_blackB(FiniteStateMachine fsm) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { fsm });
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_3_findcontext_greenBF(FiniteStateMachine fsm) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		isApplicableMatch.getAllContextElements().add(fsm);
		return new Object[] { fsm, isApplicableMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_4_solveCSP_bindingFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, fsm);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, fsm };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_4_solveCSP_bindingAndBlackFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, FiniteStateMachine fsm) {
		Object[] result_pattern_FsmToPetriNetRule_2_4_solveCSP_binding = pattern_FsmToPetriNetRule_2_4_solveCSP_bindingFBBB(
				_this, isApplicableMatch, fsm);
		if (result_pattern_FsmToPetriNetRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_2_4_solveCSP_black = pattern_FsmToPetriNetRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, fsm };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_2_5_checkCSP_expressionFBB(FsmToPetriNetRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "FsmToPetriNetRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_FsmToPetriNetRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_1_initialbindings_blackBBB(FsmToPetriNetRule _this,
			Match match, PetriNet pn) {
		return new Object[] { _this, match, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_2_SolveCSP_bindingFBBB(FsmToPetriNetRule _this,
			Match match, PetriNet pn) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, pn);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, pn };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_2_SolveCSP_bindingAndBlackFBBB(FsmToPetriNetRule _this,
			Match match, PetriNet pn) {
		Object[] result_pattern_FsmToPetriNetRule_10_2_SolveCSP_binding = pattern_FsmToPetriNetRule_10_2_SolveCSP_bindingFBBB(
				_this, match, pn);
		if (result_pattern_FsmToPetriNetRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_10_2_SolveCSP_black = pattern_FsmToPetriNetRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, pn };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_10_3_CheckCSP_expressionFBB(FsmToPetriNetRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_4_collectelementstobetranslated_blackBB(Match match,
			PetriNet pn) {
		return new Object[] { match, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_4_collectelementstobetranslated_greenBB(Match match,
			PetriNet pn) {
		match.getToBeTranslatedNodes().add(pn);
		return new Object[] { match, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_10_5_collectcontextelements_blackBB(Match match,
			PetriNet pn) {
		return new Object[] { match, pn };
	}

	public static final void pattern_FsmToPetriNetRule_10_6_registerobjectstomatch_expressionBBB(
			FsmToPetriNetRule _this, Match match, PetriNet pn) {
		_this.registerObjectsToMatch_BWD(match, pn);

	}

	public static final boolean pattern_FsmToPetriNetRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_1_performtransformation_bindingFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("pn");
		EObject tmpPn = _localVariable_0;
		if (tmpPn instanceof PetriNet) {
			PetriNet pn = (PetriNet) tmpPn;
			return new Object[] { pn, isApplicableMatch };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_1_performtransformation_blackBFBB(PetriNet pn,
			FsmToPetriNetRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { pn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_1_performtransformation_bindingAndBlackFFBB(
			FsmToPetriNetRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_FsmToPetriNetRule_11_1_performtransformation_binding = pattern_FsmToPetriNetRule_11_1_performtransformation_bindingFB(
				isApplicableMatch);
		if (result_pattern_FsmToPetriNetRule_11_1_performtransformation_binding != null) {
			PetriNet pn = (PetriNet) result_pattern_FsmToPetriNetRule_11_1_performtransformation_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_11_1_performtransformation_black = pattern_FsmToPetriNetRule_11_1_performtransformation_blackBFBB(
					pn, _this, isApplicableMatch);
			if (result_pattern_FsmToPetriNetRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_FsmToPetriNetRule_11_1_performtransformation_black[1];

				return new Object[] { pn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_1_performtransformation_greenFFBB(PetriNet pn, CSP csp) {
		FiniteStateMachine fsm = FiniteStateMachinesFactory.eINSTANCE.createFiniteStateMachine();
		StateMachineToPetriNet fsmToPn = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateMachineToPetriNet();
		Object _localVariable_0 = csp.getValue("fsm", "id");
		fsmToPn.setSource(fsm);
		fsmToPn.setTarget(pn);
		String fsm_id_prime = (String) _localVariable_0;
		fsm.setId(fsm_id_prime);
		return new Object[] { fsm, fsmToPn, pn, csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_2_collecttranslatedelements_blackBBB(
			FiniteStateMachine fsm, StateMachineToPetriNet fsmToPn, PetriNet pn) {
		return new Object[] { fsm, fsmToPn, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_2_collecttranslatedelements_greenFBBB(
			FiniteStateMachine fsm, StateMachineToPetriNet fsmToPn, PetriNet pn) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedElements().add(fsm);
		ruleresult.getCreatedLinkElements().add(fsmToPn);
		ruleresult.getTranslatedElements().add(pn);
		return new Object[] { ruleresult, fsm, fsmToPn, pn };
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_3_bookkeepingforedges_blackBBBB(
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		if (!fsm.equals(fsmToPn)) {
			if (!fsm.equals(pn)) {
				if (!fsmToPn.equals(pn)) {
					return new Object[] { ruleresult, fsm, fsmToPn, pn };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_11_3_bookkeepingforedges_greenBBBBFF(
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		EMoflonEdge fsmToPn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "FsmToPetriNetRule";
		String fsmToPn__fsm____source_name_prime = "source";
		String fsmToPn__pn____target_name_prime = "target";
		fsmToPn__fsm____source.setSrc(fsmToPn);
		fsmToPn__fsm____source.setTrg(fsm);
		ruleresult.getCreatedEdges().add(fsmToPn__fsm____source);
		fsmToPn__pn____target.setSrc(fsmToPn);
		fsmToPn__pn____target.setTrg(pn);
		ruleresult.getCreatedEdges().add(fsmToPn__pn____target);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		fsmToPn__fsm____source.setName(fsmToPn__fsm____source_name_prime);
		fsmToPn__pn____target.setName(fsmToPn__pn____target_name_prime);
		return new Object[] { ruleresult, fsm, fsmToPn, pn, fsmToPn__fsm____source, fsmToPn__pn____target };
	}

	public static final void pattern_FsmToPetriNetRule_11_5_registerobjects_expressionBBBBB(FsmToPetriNetRule _this,
			PerformRuleResult ruleresult, EObject fsm, EObject fsmToPn, EObject pn) {
		_this.registerObjects_BWD(ruleresult, fsm, fsmToPn, pn);

	}

	public static final PerformRuleResult pattern_FsmToPetriNetRule_11_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_1_preparereturnvalue_bindingFB(FsmToPetriNetRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			FsmToPetriNetRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			FsmToPetriNetRule _this) {
		Object[] result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_binding = pattern_FsmToPetriNetRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_black = pattern_FsmToPetriNetRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_FsmToPetriNetRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "FsmToPetriNetRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_2_corematch_bindingFB(Match match) {
		EObject _localVariable_0 = match.getObject("pn");
		EObject tmpPn = _localVariable_0;
		if (tmpPn instanceof PetriNet) {
			PetriNet pn = (PetriNet) tmpPn;
			return new Object[] { pn, match };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_12_2_corematch_blackBB(PetriNet pn, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { pn, match });
		return _result;
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_12_3_findcontext_blackB(PetriNet pn) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { pn });
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_3_findcontext_greenBF(PetriNet pn) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		isApplicableMatch.getAllContextElements().add(pn);
		return new Object[] { pn, isApplicableMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_4_solveCSP_bindingFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, pn);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, pn };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_4_solveCSP_bindingAndBlackFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn) {
		Object[] result_pattern_FsmToPetriNetRule_12_4_solveCSP_binding = pattern_FsmToPetriNetRule_12_4_solveCSP_bindingFBBB(
				_this, isApplicableMatch, pn);
		if (result_pattern_FsmToPetriNetRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_12_4_solveCSP_black = pattern_FsmToPetriNetRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, pn };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_12_5_checkCSP_expressionFBB(FsmToPetriNetRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "FsmToPetriNetRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_FsmToPetriNetRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_1_preparereturnvalue_bindingFB(FsmToPetriNetRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			FsmToPetriNetRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			FsmToPetriNetRule _this) {
		Object[] result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_binding = pattern_FsmToPetriNetRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_black = pattern_FsmToPetriNetRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_FsmToPetriNetRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_20_2_testcorematchandDECs_blackB(PetriNet pn) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { pn });
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_FsmToPetriNetRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBB(
			FsmToPetriNetRule _this, Match match, PetriNet pn) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, pn);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			FsmToPetriNetRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_FsmToPetriNetRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_1_preparereturnvalue_bindingFB(FsmToPetriNetRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			FsmToPetriNetRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			FsmToPetriNetRule _this) {
		Object[] result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_binding = pattern_FsmToPetriNetRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_black = pattern_FsmToPetriNetRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_FsmToPetriNetRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_21_2_testcorematchandDECs_blackB(
			FiniteStateMachine fsm) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		_result.add(new Object[] { fsm });
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_FsmToPetriNetRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBB(
			FsmToPetriNetRule _this, Match match, FiniteStateMachine fsm) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, fsm);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			FsmToPetriNetRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_FsmToPetriNetRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_1_prepare_blackB(FsmToPetriNetRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_bindingFFBB(Match sourceMatch,
			Match targetMatch) {
		EObject _localVariable_0 = sourceMatch.getObject("fsm");
		EObject _localVariable_1 = targetMatch.getObject("pn");
		EObject tmpFsm = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				return new Object[] { fsm, pn, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_blackBBBB(FiniteStateMachine fsm,
			PetriNet pn, Match sourceMatch, Match targetMatch) {
		if (!sourceMatch.equals(targetMatch)) {
			return new Object[] { fsm, pn, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_bindingAndBlackFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_binding = pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_bindingFFBB(
				sourceMatch, targetMatch);
		if (result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_binding != null) {
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_binding[0];
			PetriNet pn = (PetriNet) result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_binding[1];

			Object[] result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_black = pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_blackBBBB(
					fsm, pn, sourceMatch, targetMatch);
			if (result_pattern_FsmToPetriNetRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { fsm, pn, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_3_solvecsp_bindingFBBBBB(FsmToPetriNetRule _this,
			FiniteStateMachine fsm, PetriNet pn, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_2 = _this.isApplicable_solveCsp_CC(fsm, pn, sourceMatch, targetMatch);
		CSP csp = _localVariable_2;
		if (csp != null) {
			return new Object[] { csp, _this, fsm, pn, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_3_solvecsp_bindingAndBlackFBBBBB(FsmToPetriNetRule _this,
			FiniteStateMachine fsm, PetriNet pn, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_FsmToPetriNetRule_24_3_solvecsp_binding = pattern_FsmToPetriNetRule_24_3_solvecsp_bindingFBBBBB(
				_this, fsm, pn, sourceMatch, targetMatch);
		if (result_pattern_FsmToPetriNetRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_24_3_solvecsp_black = pattern_FsmToPetriNetRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, fsm, pn, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_FsmToPetriNetRule_24_5_matchcorrcontext_blackBB(Match sourceMatch,
			Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			_result.add(new Object[] { sourceMatch, targetMatch });
		}
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_5_matchcorrcontext_greenBBF(Match sourceMatch,
			Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "FsmToPetriNetRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_6_createcorrespondence_blackBBB(FiniteStateMachine fsm,
			PetriNet pn, CCMatch ccMatch) {
		return new Object[] { fsm, pn, ccMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_6_createcorrespondence_greenBFBB(FiniteStateMachine fsm,
			PetriNet pn, CCMatch ccMatch) {
		StateMachineToPetriNet fsmToPn = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateMachineToPetriNet();
		fsmToPn.setSource(fsm);
		fsmToPn.setTarget(pn);
		ccMatch.getCreateCorr().add(fsmToPn);
		return new Object[] { fsm, fsmToPn, pn, ccMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_FsmToPetriNetRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "FsmToPetriNetRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_FsmToPetriNetRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_27_1_matchtggpattern_blackB(FiniteStateMachine fsm) {
		return new Object[] { fsm };
	}

	public static final boolean pattern_FsmToPetriNetRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_28_1_matchtggpattern_blackB(PetriNet pn) {
		return new Object[] { pn };
	}

	public static final boolean pattern_FsmToPetriNetRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_FsmToPetriNetRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_1_createresult_blackB(FsmToPetriNetRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_2_isapplicablecore_blackB(FsmToPetriNetRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_3_solveCSP_bindingFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_3_solveCSP_bindingAndBlackFBBB(FsmToPetriNetRule _this,
			IsApplicableMatch isApplicableMatch, ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_FsmToPetriNetRule_29_3_solveCSP_binding = pattern_FsmToPetriNetRule_29_3_solveCSP_bindingFBBB(
				_this, isApplicableMatch, ruleResult);
		if (result_pattern_FsmToPetriNetRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_FsmToPetriNetRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_FsmToPetriNetRule_29_3_solveCSP_black = pattern_FsmToPetriNetRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_FsmToPetriNetRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_FsmToPetriNetRule_29_4_checkCSP_expressionFBB(FsmToPetriNetRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_6_perform_blackB(ModelgeneratorRuleResult ruleResult) {
		return new Object[] { ruleResult };
	}

	public static final Object[] pattern_FsmToPetriNetRule_29_6_perform_greenFFFBB(ModelgeneratorRuleResult ruleResult,
			CSP csp) {
		FiniteStateMachine fsm = FiniteStateMachinesFactory.eINSTANCE.createFiniteStateMachine();
		StateMachineToPetriNet fsmToPn = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateMachineToPetriNet();
		PetriNet pn = PetriNetsFactory.eINSTANCE.createPetriNet();
		Object _localVariable_0 = csp.getValue("fsm", "id");
		Object _localVariable_1 = csp.getValue("pn", "id");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		ruleResult.getSourceObjects().add(fsm);
		fsmToPn.setSource(fsm);
		ruleResult.getCorrObjects().add(fsmToPn);
		fsmToPn.setTarget(pn);
		ruleResult.getTargetObjects().add(pn);
		String fsm_id_prime = (String) _localVariable_0;
		String pn_id_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		fsm.setId(fsm_id_prime);
		pn.setId(pn_id_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { fsm, fsmToPn, pn, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_FsmToPetriNetRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //FsmToPetriNetRuleImpl
