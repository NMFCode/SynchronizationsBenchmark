/**
 */
package FiniteStatesToPetriNets.Rules.impl;

import FiniteStateMachines.FiniteStateMachinesPackage;

import FiniteStatesToPetriNets.FiniteStatesToPetriNetsPackage;

import FiniteStatesToPetriNets.Rules.EndStateToTransition;
import FiniteStatesToPetriNets.Rules.FsmToPetriNetRule;
import FiniteStatesToPetriNets.Rules.RulesFactory;
import FiniteStatesToPetriNets.Rules.RulesPackage;
import FiniteStatesToPetriNets.Rules.StateToPlaceRule;
import FiniteStatesToPetriNets.Rules.TransitionToTransition;

import FiniteStatesToPetriNets.impl.FiniteStatesToPetriNetsPackageImpl;

import PetriNets.PetriNetsPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.moflon.tgg.language.LanguagePackage;

import org.moflon.tgg.language.csp.CspPackage;

import org.moflon.tgg.language.modelgenerator.ModelgeneratorPackage;

import org.moflon.tgg.runtime.RuntimePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RulesPackageImpl extends EPackageImpl implements RulesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass endStateToTransitionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fsmToPetriNetRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stateToPlaceRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitionToTransitionEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see FiniteStatesToPetriNets.Rules.RulesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RulesPackageImpl() {
		super(eNS_URI, RulesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link RulesPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RulesPackage init() {
		if (isInited)
			return (RulesPackage) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);

		// Obtain or create and register package
		RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof RulesPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new RulesPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		FiniteStateMachinesPackage.eINSTANCE.eClass();
		PetriNetsPackage.eINSTANCE.eClass();
		LanguagePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		FiniteStatesToPetriNetsPackageImpl theFiniteStatesToPetriNetsPackage = (FiniteStatesToPetriNetsPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(FiniteStatesToPetriNetsPackage.eNS_URI) instanceof FiniteStatesToPetriNetsPackageImpl
						? EPackage.Registry.INSTANCE.getEPackage(FiniteStatesToPetriNetsPackage.eNS_URI)
						: FiniteStatesToPetriNetsPackage.eINSTANCE);

		// Create package meta-data objects
		theRulesPackage.createPackageContents();
		theFiniteStatesToPetriNetsPackage.createPackageContents();

		// Initialize created meta-data
		theRulesPackage.initializePackageContents();
		theFiniteStatesToPetriNetsPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theRulesPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(RulesPackage.eNS_URI, theRulesPackage);
		return theRulesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEndStateToTransition() {
		return endStateToTransitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_FWD__Match_State_FiniteStateMachine() {
		return endStateToTransitionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__Perform_FWD__IsApplicableMatch() {
		return endStateToTransitionEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_FWD__Match() {
		return endStateToTransitionEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__RegisterObjectsToMatch_FWD__Match_State_FiniteStateMachine() {
		return endStateToTransitionEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_solveCsp_FWD__Match_State_FiniteStateMachine() {
		return endStateToTransitionEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_checkCsp_FWD__CSP() {
		return endStateToTransitionEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckTypes_FWD__Match() {
		return endStateToTransitionEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_BWD__Match_Transition_PetriNet_Place() {
		return endStateToTransitionEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__Perform_BWD__IsApplicableMatch() {
		return endStateToTransitionEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_BWD__Match() {
		return endStateToTransitionEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__RegisterObjectsToMatch_BWD__Match_Transition_PetriNet_Place() {
		return endStateToTransitionEClass.getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_PetriNet_Place() {
		return endStateToTransitionEClass.getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_checkCsp_BWD__CSP() {
		return endStateToTransitionEClass.getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_Transition_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet() {
		return endStateToTransitionEClass.getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_checkCsp_BWD__CSP() {
		return endStateToTransitionEClass.getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return endStateToTransitionEClass.getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckTypes_BWD__Match() {
		return endStateToTransitionEClass.getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_FWD_State_3__State() {
		return endStateToTransitionEClass.getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsAppropriate_BWD_EMoflonEdge_9__EMoflonEdge() {
		return endStateToTransitionEClass.getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckAttributes_FWD__TripleMatch() {
		return endStateToTransitionEClass.getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckAttributes_BWD__TripleMatch() {
		return endStateToTransitionEClass.getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_CC__Match_Match() {
		return endStateToTransitionEClass.getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_solveCsp_CC__Transition_PetriNet_State_FiniteStateMachine_Place_Match_Match() {
		return endStateToTransitionEClass.getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__IsApplicable_checkCsp_CC__CSP() {
		return endStateToTransitionEClass.getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckDEC_FWD__State_FiniteStateMachine() {
		return endStateToTransitionEClass.getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__CheckDEC_BWD__Transition_PetriNet_Place() {
		return endStateToTransitionEClass.getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__GenerateModel__RuleEntryContainer_StateToPlace() {
		return endStateToTransitionEClass.getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet_ModelgeneratorRuleResult() {
		return endStateToTransitionEClass.getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEndStateToTransition__GenerateModel_checkCsp_BWD__CSP() {
		return endStateToTransitionEClass.getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFsmToPetriNetRule() {
		return fsmToPetriNetRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_FWD__Match_FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__Perform_FWD__IsApplicableMatch() {
		return fsmToPetriNetRuleEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_FWD__Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_checkCsp_FWD__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_FWD__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject() {
		return fsmToPetriNetRuleEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckTypes_FWD__Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_BWD__Match_PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__Perform_BWD__IsApplicableMatch() {
		return fsmToPetriNetRuleEClass.getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_BWD__Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__RegisterObjectsToMatch_BWD__Match_PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_solveCsp_BWD__Match_PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_checkCsp_BWD__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_BWD__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject() {
		return fsmToPetriNetRuleEClass.getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckTypes_BWD__Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_BWD_PetriNet_3__PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsAppropriate_FWD_FiniteStateMachine_3__FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckAttributes_FWD__TripleMatch() {
		return fsmToPetriNetRuleEClass.getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckAttributes_BWD__TripleMatch() {
		return fsmToPetriNetRuleEClass.getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_CC__Match_Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_CC__FiniteStateMachine_PetriNet_Match_Match() {
		return fsmToPetriNetRuleEClass.getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_CC__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckDEC_FWD__FiniteStateMachine() {
		return fsmToPetriNetRuleEClass.getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__CheckDEC_BWD__PetriNet() {
		return fsmToPetriNetRuleEClass.getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__GenerateModel__RuleEntryContainer() {
		return fsmToPetriNetRuleEClass.getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult() {
		return fsmToPetriNetRuleEClass.getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getFsmToPetriNetRule__GenerateModel_checkCsp_BWD__CSP() {
		return fsmToPetriNetRuleEClass.getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStateToPlaceRule() {
		return stateToPlaceRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_FWD__Match_FiniteStateMachine_State() {
		return stateToPlaceRuleEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__Perform_FWD__IsApplicableMatch() {
		return stateToPlaceRuleEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_FWD__Match() {
		return stateToPlaceRuleEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State() {
		return stateToPlaceRuleEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State() {
		return stateToPlaceRuleEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_checkCsp_FWD__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_State() {
		return stateToPlaceRuleEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_checkCsp_FWD__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject() {
		return stateToPlaceRuleEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckTypes_FWD__Match() {
		return stateToPlaceRuleEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_BWD__Match_Place_PetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__Perform_BWD__IsApplicableMatch() {
		return stateToPlaceRuleEClass.getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_BWD__Match() {
		return stateToPlaceRuleEClass.getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__RegisterObjectsToMatch_BWD__Match_Place_PetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_solveCsp_BWD__Match_Place_PetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_checkCsp_BWD__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_Place_PetriNet_FiniteStateMachine_StateMachineToPetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_checkCsp_BWD__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject() {
		return stateToPlaceRuleEClass.getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckTypes_BWD__Match() {
		return stateToPlaceRuleEClass.getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_BWD_EMoflonEdge_10__EMoflonEdge() {
		return stateToPlaceRuleEClass.getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsAppropriate_FWD_EMoflonEdge_6__EMoflonEdge() {
		return stateToPlaceRuleEClass.getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckAttributes_FWD__TripleMatch() {
		return stateToPlaceRuleEClass.getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckAttributes_BWD__TripleMatch() {
		return stateToPlaceRuleEClass.getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_CC__Match_Match() {
		return stateToPlaceRuleEClass.getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_solveCsp_CC__Place_PetriNet_FiniteStateMachine_State_Match_Match() {
		return stateToPlaceRuleEClass.getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__IsApplicable_checkCsp_CC__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckDEC_FWD__FiniteStateMachine_State() {
		return stateToPlaceRuleEClass.getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__CheckDEC_BWD__Place_PetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__GenerateModel__RuleEntryContainer_StateMachineToPetriNet() {
		return stateToPlaceRuleEClass.getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_ModelgeneratorRuleResult() {
		return stateToPlaceRuleEClass.getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getStateToPlaceRule__GenerateModel_checkCsp_BWD__CSP() {
		return stateToPlaceRuleEClass.getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransitionToTransition() {
		return transitionToTransitionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_FWD__Match_FiniteStateMachine_State_Transition_State() {
		return transitionToTransitionEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__Perform_FWD__IsApplicableMatch() {
		return transitionToTransitionEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_FWD__Match() {
		return transitionToTransitionEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State_Transition_State() {
		return transitionToTransitionEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State_Transition_State() {
		return transitionToTransitionEClass.getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_checkCsp_FWD__CSP() {
		return transitionToTransitionEClass.getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_Transition_State_PetriNet_Place_StateToPlace() {
		return transitionToTransitionEClass.getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_checkCsp_FWD__CSP() {
		return transitionToTransitionEClass.getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return transitionToTransitionEClass.getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckTypes_FWD__Match() {
		return transitionToTransitionEClass.getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_BWD__Match_Transition_Place_PetriNet_Place() {
		return transitionToTransitionEClass.getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__Perform_BWD__IsApplicableMatch() {
		return transitionToTransitionEClass.getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_BWD__Match() {
		return transitionToTransitionEClass.getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__RegisterObjectsToMatch_BWD__Match_Transition_Place_PetriNet_Place() {
		return transitionToTransitionEClass.getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_Place_PetriNet_Place() {
		return transitionToTransitionEClass.getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_checkCsp_BWD__CSP() {
		return transitionToTransitionEClass.getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Transition_Place_State_PetriNet_Place_StateToPlace() {
		return transitionToTransitionEClass.getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_checkCsp_BWD__CSP() {
		return transitionToTransitionEClass.getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return transitionToTransitionEClass.getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckTypes_BWD__Match() {
		return transitionToTransitionEClass.getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_BWD_EMoflonEdge_11__EMoflonEdge() {
		return transitionToTransitionEClass.getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsAppropriate_FWD_EMoflonEdge_7__EMoflonEdge() {
		return transitionToTransitionEClass.getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckAttributes_FWD__TripleMatch() {
		return transitionToTransitionEClass.getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckAttributes_BWD__TripleMatch() {
		return transitionToTransitionEClass.getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_CC__Match_Match() {
		return transitionToTransitionEClass.getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_solveCsp_CC__FiniteStateMachine_State_Transition_Place_Transition_State_PetriNet_Place_Match_Match() {
		return transitionToTransitionEClass.getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__IsApplicable_checkCsp_CC__CSP() {
		return transitionToTransitionEClass.getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckDEC_FWD__FiniteStateMachine_State_Transition_State() {
		return transitionToTransitionEClass.getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__CheckDEC_BWD__Transition_Place_PetriNet_Place() {
		return transitionToTransitionEClass.getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__GenerateModel__RuleEntryContainer_StateToPlace() {
		return transitionToTransitionEClass.getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_State_PetriNet_Place_StateToPlace_ModelgeneratorRuleResult() {
		return transitionToTransitionEClass.getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitionToTransition__GenerateModel_checkCsp_BWD__CSP() {
		return transitionToTransitionEClass.getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RulesFactory getRulesFactory() {
		return (RulesFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		endStateToTransitionEClass = createEClass(END_STATE_TO_TRANSITION);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_STATE_FINITESTATEMACHINE);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_STATE_FINITESTATEMACHINE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_STATE_FINITESTATEMACHINE);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___CHECK_TYPES_FWD__MATCH);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PETRINET_PLACE);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PETRINET_PLACE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PETRINET_PLACE);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_TRANSITION_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___CHECK_TYPES_BWD__MATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD_STATE_3__STATE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_9__EMOFLONEDGE);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__TRANSITION_PETRINET_STATE_FINITESTATEMACHINE_PLACE_MATCH_MATCH);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___CHECK_DEC_FWD__STATE_FINITESTATEMACHINE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PETRINET_PLACE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE);
		createEOperation(endStateToTransitionEClass,
				END_STATE_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT);
		createEOperation(endStateToTransitionEClass, END_STATE_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP);

		fsmToPetriNetRuleEClass = createEClass(FSM_TO_PETRI_NET_RULE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___PERFORM_FWD__ISAPPLICABLEMATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_FWD__MATCH);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_TYPES_FWD__MATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD__MATCH_PETRINET);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___PERFORM_BWD__ISAPPLICABLEMATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_BWD__MATCH);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PETRINET);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PETRINET);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_TYPES_BWD__MATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD_PETRI_NET_3__PETRINET);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD_FINITE_STATE_MACHINE_3__FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CC__MATCH_MATCH);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_PETRINET_MATCH_MATCH);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___CHECK_DEC_BWD__PETRINET);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___GENERATE_MODEL__RULEENTRYCONTAINER);
		createEOperation(fsmToPetriNetRuleEClass,
				FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_MODELGENERATORRULERESULT);
		createEOperation(fsmToPetriNetRuleEClass, FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP);

		stateToPlaceRuleEClass = createEClass(STATE_TO_PLACE_RULE);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_FWD__MATCH);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_STATE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_TYPES_FWD__MATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD__MATCH_PLACE_PETRINET);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_BWD__MATCH);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PLACE_PETRINET);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PLACE_PETRINET);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PLACE_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_TYPES_BWD__MATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_10__EMOFLONEDGE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_6__EMOFLONEDGE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_CC__MATCH_MATCH);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__PLACE_PETRINET_FINITESTATEMACHINE_STATE_MATCH_MATCH);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___CHECK_DEC_BWD__PLACE_PETRINET);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_STATEMACHINETOPETRINET);
		createEOperation(stateToPlaceRuleEClass,
				STATE_TO_PLACE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT);
		createEOperation(stateToPlaceRuleEClass, STATE_TO_PLACE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP);

		transitionToTransitionEClass = createEClass(TRANSITION_TO_TRANSITION);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_TRANSITION_STATE_PETRINET_PLACE_STATETOPLACE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_FWD__CSP);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___CHECK_TYPES_FWD__MATCH);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_TRANSITION_PLACE_STATE_PETRINET_PLACE_STATETOPLACE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___CHECK_TYPES_BWD__MATCH);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_11__EMOFLONEDGE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD_EMOFLON_EDGE_7__EMOFLONEDGE);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_STATE_TRANSITION_PLACE_TRANSITION_STATE_PETRINET_PLACE_MATCH_MATCH);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE_TRANSITION_STATE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PLACE_PETRINET_PLACE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE);
		createEOperation(transitionToTransitionEClass,
				TRANSITION_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_STATE_PETRINET_PLACE_STATETOPLACE_MODELGENERATORRULERESULT);
		createEOperation(transitionToTransitionEClass, TRANSITION_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		RuntimePackage theRuntimePackage = (RuntimePackage) EPackage.Registry.INSTANCE
				.getEPackage(RuntimePackage.eNS_URI);
		FiniteStateMachinesPackage theFiniteStateMachinesPackage = (FiniteStateMachinesPackage) EPackage.Registry.INSTANCE
				.getEPackage(FiniteStateMachinesPackage.eNS_URI);
		CspPackage theCspPackage = (CspPackage) EPackage.Registry.INSTANCE.getEPackage(CspPackage.eNS_URI);
		PetriNetsPackage thePetriNetsPackage = (PetriNetsPackage) EPackage.Registry.INSTANCE
				.getEPackage(PetriNetsPackage.eNS_URI);
		FiniteStatesToPetriNetsPackage theFiniteStatesToPetriNetsPackage = (FiniteStatesToPetriNetsPackage) EPackage.Registry.INSTANCE
				.getEPackage(FiniteStatesToPetriNetsPackage.eNS_URI);
		ModelgeneratorPackage theModelgeneratorPackage = (ModelgeneratorPackage) EPackage.Registry.INSTANCE
				.getEPackage(ModelgeneratorPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		endStateToTransitionEClass.getESuperTypes().add(theRuntimePackage.getAbstractRule());
		fsmToPetriNetRuleEClass.getESuperTypes().add(theRuntimePackage.getAbstractRule());
		stateToPlaceRuleEClass.getESuperTypes().add(theRuntimePackage.getAbstractRule());
		transitionToTransitionEClass.getESuperTypes().add(theRuntimePackage.getAbstractRule());

		// Initialize classes, features, and operations; add parameters
		initEClass(endStateToTransitionEClass, EndStateToTransition.class, "EndStateToTransition", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		EOperation op = initEOperation(getEndStateToTransition__IsAppropriate_FWD__Match_State_FiniteStateMachine(),
				ecorePackage.getEBoolean(), "isAppropriate_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__Perform_FWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsApplicable_FWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__RegisterObjectsToMatch_FWD__Match_State_FiniteStateMachine(), null,
				"registerObjectsToMatch_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_solveCsp_FWD__Match_State_FiniteStateMachine(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckTypes_FWD__Match(), ecorePackage.getEBoolean(),
				"checkTypes_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_BWD__Match_Transition_PetriNet_Place(),
				ecorePackage.getEBoolean(), "isAppropriate_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__Perform_BWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsApplicable_BWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__RegisterObjectsToMatch_BWD__Match_Transition_PetriNet_Place(),
				null, "registerObjectsToMatch_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_PetriNet_Place(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getEndStateToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_Transition_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "sToP", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsmToPn", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsApplicable_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getEndStateToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject(),
				null, "registerObjects_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "sToT", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "sToP", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsmToPn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckTypes_BWD__Match(), ecorePackage.getEBoolean(),
				"checkTypes_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_FWD_State_3__State(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_FWD_State_3", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsAppropriate_BWD_EMoflonEdge_9__EMoflonEdge(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_BWD_EMoflonEdge_9", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getEMoflonEdge(), "_edge_from", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckAttributes_FWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_FWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckAttributes_BWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_BWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsApplicable_CC__Match_Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getEndStateToTransition__IsApplicable_solveCsp_CC__Transition_PetriNet_State_FiniteStateMachine_Place_Match_Match(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__IsApplicable_checkCsp_CC__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckDEC_FWD__State_FiniteStateMachine(),
				ecorePackage.getEBoolean(), "checkDEC_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__CheckDEC_BWD__Transition_PetriNet_Place(),
				ecorePackage.getEBoolean(), "checkDEC_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "t", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__GenerateModel__RuleEntryContainer_StateToPlace(),
				theRuntimePackage.getModelgeneratorRuleResult(), "generateModel", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theModelgeneratorPackage.getRuleEntryContainer(), "ruleEntryContainer", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "sToPParameter", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		op = initEOperation(
				getEndStateToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet_ModelgeneratorRuleResult(),
				theCspPackage.getCSP(), "generateModel_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "sToP", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsmToPn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getModelgeneratorRuleResult(), "ruleResult", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEndStateToTransition__GenerateModel_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"generateModel_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(fsmToPetriNetRuleEClass, FsmToPetriNetRule.class, "FsmToPetriNetRule", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_FWD__Match_FiniteStateMachine(),
				ecorePackage.getEBoolean(), "isAppropriate_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__Perform_FWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_FWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine(), null,
				"registerObjectsToMatch_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject(),
				null, "registerObjects_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsmToPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckTypes_FWD__Match(), ecorePackage.getEBoolean(), "checkTypes_FWD",
				0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_BWD__Match_PetriNet(), ecorePackage.getEBoolean(),
				"isAppropriate_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__Perform_BWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_BWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__RegisterObjectsToMatch_BWD__Match_PetriNet(), null,
				"registerObjectsToMatch_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_solveCsp_BWD__Match_PetriNet(), theCspPackage.getCSP(),
				"isAppropriate_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_PetriNet(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject(),
				null, "registerObjects_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsmToPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckTypes_BWD__Match(), ecorePackage.getEBoolean(), "checkTypes_BWD",
				0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_BWD_PetriNet_3__PetriNet(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_BWD_PetriNet_3", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsAppropriate_FWD_FiniteStateMachine_3__FiniteStateMachine(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_FWD_FiniteStateMachine_3", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckAttributes_FWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_FWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckAttributes_BWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_BWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_CC__Match_Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_solveCsp_CC__FiniteStateMachine_PetriNet_Match_Match(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__IsApplicable_checkCsp_CC__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckDEC_FWD__FiniteStateMachine(), ecorePackage.getEBoolean(),
				"checkDEC_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__CheckDEC_BWD__PetriNet(), ecorePackage.getEBoolean(), "checkDEC_BWD",
				0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__GenerateModel__RuleEntryContainer(),
				theRuntimePackage.getModelgeneratorRuleResult(), "generateModel", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theModelgeneratorPackage.getRuleEntryContainer(), "ruleEntryContainer", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		op = initEOperation(
				getFsmToPetriNetRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult(),
				theCspPackage.getCSP(), "generateModel_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getModelgeneratorRuleResult(), "ruleResult", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getFsmToPetriNetRule__GenerateModel_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"generateModel_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(stateToPlaceRuleEClass, StateToPlaceRule.class, "StateToPlaceRule", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_FWD__Match_FiniteStateMachine_State(),
				ecorePackage.getEBoolean(), "isAppropriate_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__Perform_FWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_FWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State(), null,
				"registerObjectsToMatch_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_State(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsm2pn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject(),
				null, "registerObjects_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm2pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckTypes_FWD__Match(), ecorePackage.getEBoolean(), "checkTypes_FWD",
				0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_BWD__Match_Place_PetriNet(), ecorePackage.getEBoolean(),
				"isAppropriate_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__Perform_BWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_BWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__RegisterObjectsToMatch_BWD__Match_Place_PetriNet(), null,
				"registerObjectsToMatch_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_solveCsp_BWD__Match_Place_PetriNet(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_Place_PetriNet_FiniteStateMachine_StateMachineToPetriNet(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsm2pn", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject(),
				null, "registerObjects_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm2pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckTypes_BWD__Match(), ecorePackage.getEBoolean(), "checkTypes_BWD",
				0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_BWD_EMoflonEdge_10__EMoflonEdge(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_BWD_EMoflonEdge_10", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getEMoflonEdge(), "_edge_places", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsAppropriate_FWD_EMoflonEdge_6__EMoflonEdge(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_FWD_EMoflonEdge_6", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getEMoflonEdge(), "_edge_states", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckAttributes_FWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_FWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckAttributes_BWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_BWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_CC__Match_Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__IsApplicable_solveCsp_CC__Place_PetriNet_FiniteStateMachine_State_Match_Match(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__IsApplicable_checkCsp_CC__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckDEC_FWD__FiniteStateMachine_State(), ecorePackage.getEBoolean(),
				"checkDEC_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__CheckDEC_BWD__Place_PetriNet(), ecorePackage.getEBoolean(),
				"checkDEC_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__GenerateModel__RuleEntryContainer_StateMachineToPetriNet(),
				theRuntimePackage.getModelgeneratorRuleResult(), "generateModel", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theModelgeneratorPackage.getRuleEntryContainer(), "ruleEntryContainer", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsm2pnParameter", 0, 1,
				IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getStateToPlaceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_ModelgeneratorRuleResult(),
				theCspPackage.getCSP(), "generateModel_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsm2pn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getModelgeneratorRuleResult(), "ruleResult", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getStateToPlaceRule__GenerateModel_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"generateModel_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(transitionToTransitionEClass, TransitionToTransition.class, "TransitionToTransition", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		op = initEOperation(
				getTransitionToTransition__IsAppropriate_FWD__Match_FiniteStateMachine_State_Transition_State(),
				ecorePackage.getEBoolean(), "isAppropriate_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__Perform_FWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_FWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State_Transition_State(),
				null, "registerObjectsToMatch_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State_Transition_State(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsAppropriate_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_Transition_State_PetriNet_Place_StateToPlace(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s2ToP2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsmToPn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s1Top1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_checkCsp_FWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject(),
				null, "registerObjects_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tToT", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2ToP2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsmToPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s1Top1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckTypes_FWD__Match(), ecorePackage.getEBoolean(),
				"checkTypes_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsAppropriate_BWD__Match_Transition_Place_PetriNet_Place(),
				ecorePackage.getEBoolean(), "isAppropriate_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__Perform_BWD__IsApplicableMatch(),
				theRuntimePackage.getPerformRuleResult(), "perform_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_BWD__Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__RegisterObjectsToMatch_BWD__Match_Transition_Place_PetriNet_Place(), null,
				"registerObjectsToMatch_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_Place_PetriNet_Place(),
				theCspPackage.getCSP(), "isAppropriate_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsAppropriate_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isAppropriate_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Transition_Place_State_PetriNet_Place_StateToPlace(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s2ToP2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsmToPn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s1Top1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject(),
				null, "registerObjects_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getPerformRuleResult(), "ruleresult", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tToT", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s2ToP2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "fsmToPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEObject(), "s1Top1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckTypes_BWD__Match(), ecorePackage.getEBoolean(),
				"checkTypes_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "match", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsAppropriate_BWD_EMoflonEdge_11__EMoflonEdge(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_BWD_EMoflonEdge_11", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getEMoflonEdge(), "_edge_to", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsAppropriate_FWD_EMoflonEdge_7__EMoflonEdge(),
				theRuntimePackage.getEObjectContainer(), "isAppropriate_FWD_EMoflonEdge_7", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getEMoflonEdge(), "_edge_transitions", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckAttributes_FWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_FWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckAttributes_BWD__TripleMatch(),
				theRuntimePackage.getAttributeConstraintsRuleResult(), "checkAttributes_BWD", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theRuntimePackage.getTripleMatch(), "__tripleMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_CC__Match_Match(),
				theRuntimePackage.getIsApplicableRuleResult(), "isApplicable_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__IsApplicable_solveCsp_CC__FiniteStateMachine_State_Transition_Place_Transition_State_PetriNet_Place_Match_Match(),
				theCspPackage.getCSP(), "isApplicable_solveCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "sourceMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getMatch(), "targetMatch", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__IsApplicable_checkCsp_CC__CSP(), ecorePackage.getEBoolean(),
				"isApplicable_checkCsp_CC", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckDEC_FWD__FiniteStateMachine_State_Transition_State(),
				ecorePackage.getEBoolean(), "checkDEC_FWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getTransition(), "tFsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__CheckDEC_BWD__Transition_Place_PetriNet_Place(),
				ecorePackage.getEBoolean(), "checkDEC_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getTransition(), "tPn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__GenerateModel__RuleEntryContainer_StateToPlace(),
				theRuntimePackage.getModelgeneratorRuleResult(), "generateModel", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theModelgeneratorPackage.getRuleEntryContainer(), "ruleEntryContainer", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s2ToP2Parameter", 0, 1, IS_UNIQUE,
				IS_ORDERED);

		op = initEOperation(
				getTransitionToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_State_PetriNet_Place_StateToPlace_ModelgeneratorRuleResult(),
				theCspPackage.getCSP(), "generateModel_solveCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getIsApplicableMatch(), "isApplicableMatch", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getFiniteStateMachine(), "fsm", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s2ToP2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateMachineToPetriNet(), "fsmToPn", 0, 1, IS_UNIQUE,
				IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStateMachinesPackage.getState(), "s1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPetriNet(), "pn", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, thePetriNetsPackage.getPlace(), "p2", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theFiniteStatesToPetriNetsPackage.getStateToPlace(), "s1Top1", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theRuntimePackage.getModelgeneratorRuleResult(), "ruleResult", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getTransitionToTransition__GenerateModel_checkCsp_BWD__CSP(), ecorePackage.getEBoolean(),
				"generateModel_checkCsp_BWD", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, theCspPackage.getCSP(), "csp", 0, 1, IS_UNIQUE, IS_ORDERED);
	}

} //RulesPackageImpl
