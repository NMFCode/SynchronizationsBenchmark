/**
 */
package FiniteStatesToPetriNets.Rules.impl;

import FiniteStateMachines.FiniteStateMachine;
import FiniteStateMachines.FiniteStateMachinesFactory;
import FiniteStateMachines.State;

import FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory;

import FiniteStatesToPetriNets.Rules.RulesPackage;
import FiniteStatesToPetriNets.Rules.StateToPlaceRule;

import FiniteStatesToPetriNets.StateMachineToPetriNet;
import FiniteStatesToPetriNets.StateToPlace;

import PetriNets.PetriNet;
import PetriNets.PetriNetsFactory;
import PetriNets.Place;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.csp.*;
import csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State To Place Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class StateToPlaceRuleImpl extends AbstractRuleImpl implements StateToPlaceRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateToPlaceRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.Literals.STATE_TO_PLACE_RULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, FiniteStateMachine fsm, State s) {
		// initial bindings
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_1_initialbindings_blackBBBB(this,
				match, fsm, s);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [initial bindings] failed." + " Variables: " + "[this] = " + this + ", "
							+ "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s] = " + s + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_0_2_SolveCSP_bindingAndBlackFBBBB(this, match, fsm, s);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s] = " + s + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_0_4_collectelementstobetranslated_blackBBB(match, fsm, s);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s] = " + s + ".");
			}
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_4_collectelementstobetranslated_greenBBBF(match, fsm, s);
			// EMoflonEdge fsm__s____states = (EMoflonEdge) result4_green[3];

			// collect context elements
			Object[] result5_black = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_0_5_collectcontextelements_blackBBB(match, fsm, s);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[fsm] = " + fsm + ", " + "[s] = " + s + ".");
			}
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_5_collectcontextelements_greenBB(match, fsm);

			// register objects to match
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_6_registerobjectstomatch_expressionBBBB(this, match, fsm,
					s);
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_7_expressionF();
		} else {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_1_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		PetriNet pn = (PetriNet) result1_bindingAndBlack[0];
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[1];
		StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result1_bindingAndBlack[2];
		State s = (State) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_1_1_performtransformation_greenFBFBB(pn,
				s, csp);
		Place p = (Place) result1_green[0];
		StateToPlace s2p = (StateToPlace) result1_green[2];

		// collect translated elements
		Object[] result2_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_1_2_collecttranslatedelements_blackBBB(p,
				s2p, s);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[p] = " + p + ", " + "[s2p] = " + s2p + ", " + "[s] = " + s + ".");
		}
		Object[] result2_green = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_1_2_collecttranslatedelements_greenFBBB(p, s2p, s);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_1_3_bookkeepingforedges_blackBBBBBBB(ruleresult, p, pn, fsm, s2p, fsm2pn, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ", " + "[fsm] = "
					+ fsm + ", " + "[s2p] = " + s2p + ", " + "[fsm2pn] = " + fsm2pn + ", " + "[s] = " + s + ".");
		}
		StateToPlaceRuleImpl.pattern_StateToPlaceRule_1_3_bookkeepingforedges_greenBBBBBBFFFF(ruleresult, p, pn, fsm,
				s2p, s);
		// EMoflonEdge pn__p____places = (EMoflonEdge) result3_green[6];
		// EMoflonEdge fsm__s____states = (EMoflonEdge) result3_green[7];
		// EMoflonEdge s2p__p____target = (EMoflonEdge) result3_green[8];
		// EMoflonEdge s2p__s____source = (EMoflonEdge) result3_green[9];

		// perform postprocessing story node is empty
		// register objects
		StateToPlaceRuleImpl.pattern_StateToPlaceRule_1_5_registerobjects_expressionBBBBBBBB(this, ruleresult, p, pn,
				fsm, s2p, fsm2pn, s);
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		FiniteStateMachine fsm = (FiniteStateMachine) result2_binding[0];
		State s = (State) result2_binding[1];
		for (Object[] result2_black : StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_2_corematch_blackFBFBB(fsm, s,
				match)) {
			PetriNet pn = (PetriNet) result2_black[0];
			StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result2_black[2];
			// ForEach find context
			for (Object[] result3_black : StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_3_findcontext_blackBBBB(pn,
					fsm, fsm2pn, s)) {
				Object[] result3_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_3_findcontext_greenBBBBFFFF(pn,
						fsm, fsm2pn, s);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				// EMoflonEdge fsm__s____states = (EMoflonEdge) result3_green[5];
				// EMoflonEdge fsm2pn__pn____target = (EMoflonEdge) result3_green[6];
				// EMoflonEdge fsm2pn__fsm____source = (EMoflonEdge) result3_green[7];

				// solve CSP
				Object[] result4_bindingAndBlack = StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_2_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, pn, fsm,
								fsm2pn, s);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[pn] = " + pn + ", "
									+ "[fsm] = " + fsm + ", " + "[fsm2pn] = " + fsm2pn + ", " + "[s] = " + s + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = StateToPlaceRuleImpl
							.pattern_StateToPlaceRule_2_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, FiniteStateMachine fsm, State s) {
		match.registerObject("fsm", fsm);
		match.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, FiniteStateMachine fsm, State s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn, State s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s.name", true, csp);
		var_s_name.setValue(s.getName());
		var_s_name.setType("String");

		// Create unbound variables
		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p.id", csp);
		var_p_id.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_s_name, var_p_id);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("fsm2pn", fsm2pn);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p,
			EObject fsm2pn, EObject s) {
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("pn", pn);
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("s2p", s2p);
		ruleresult.registerObject("fsm2pn", fsm2pn);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("s").eClass())
				.equals("FiniteStateMachines.State.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, Place p, PetriNet pn) {
		// initial bindings
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_1_initialbindings_blackBBBB(this,
				match, p, pn);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [initial bindings] failed." + " Variables: " + "[this] = " + this + ", "
							+ "[match] = " + match + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_10_2_SolveCSP_bindingAndBlackFBBBB(this, match, p, pn);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_10_4_collectelementstobetranslated_blackBBB(match, p, pn);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ".");
			}
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_4_collectelementstobetranslated_greenBBBF(match, p, pn);
			// EMoflonEdge pn__p____places = (EMoflonEdge) result4_green[3];

			// collect context elements
			Object[] result5_black = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_10_5_collectcontextelements_blackBBB(match, p, pn);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ".");
			}
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_5_collectcontextelements_greenBB(match, pn);

			// register objects to match
			StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_6_registerobjectstomatch_expressionBBBB(this, match, p,
					pn);
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_7_expressionF();
		} else {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_11_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		Place p = (Place) result1_bindingAndBlack[0];
		PetriNet pn = (PetriNet) result1_bindingAndBlack[1];
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[2];
		StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_11_1_performtransformation_greenBBFFB(p,
				fsm, csp);
		StateToPlace s2p = (StateToPlace) result1_green[2];
		State s = (State) result1_green[3];

		// collect translated elements
		Object[] result2_black = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_11_2_collecttranslatedelements_blackBBB(p, s2p, s);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[p] = " + p + ", " + "[s2p] = " + s2p + ", " + "[s] = " + s + ".");
		}
		Object[] result2_green = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_11_2_collecttranslatedelements_greenFBBB(p, s2p, s);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_11_3_bookkeepingforedges_blackBBBBBBB(ruleresult, p, pn, fsm, s2p, fsm2pn, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ", " + "[fsm] = "
					+ fsm + ", " + "[s2p] = " + s2p + ", " + "[fsm2pn] = " + fsm2pn + ", " + "[s] = " + s + ".");
		}
		StateToPlaceRuleImpl.pattern_StateToPlaceRule_11_3_bookkeepingforedges_greenBBBBBBFFFF(ruleresult, p, pn, fsm,
				s2p, s);
		// EMoflonEdge pn__p____places = (EMoflonEdge) result3_green[6];
		// EMoflonEdge fsm__s____states = (EMoflonEdge) result3_green[7];
		// EMoflonEdge s2p__p____target = (EMoflonEdge) result3_green[8];
		// EMoflonEdge s2p__s____source = (EMoflonEdge) result3_green[9];

		// perform postprocessing story node is empty
		// register objects
		StateToPlaceRuleImpl.pattern_StateToPlaceRule_11_5_registerobjects_expressionBBBBBBBB(this, ruleresult, p, pn,
				fsm, s2p, fsm2pn, s);
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		Place p = (Place) result2_binding[0];
		PetriNet pn = (PetriNet) result2_binding[1];
		for (Object[] result2_black : StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_2_corematch_blackBBFFB(p, pn,
				match)) {
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[2];
			StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result2_black[3];
			// ForEach find context
			for (Object[] result3_black : StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_3_findcontext_blackBBBB(p,
					pn, fsm, fsm2pn)) {
				Object[] result3_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_3_findcontext_greenBBBBFFFF(p,
						pn, fsm, fsm2pn);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				// EMoflonEdge pn__p____places = (EMoflonEdge) result3_green[5];
				// EMoflonEdge fsm2pn__pn____target = (EMoflonEdge) result3_green[6];
				// EMoflonEdge fsm2pn__fsm____source = (EMoflonEdge) result3_green[7];

				// solve CSP
				Object[] result4_bindingAndBlack = StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_12_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, p, pn,
								fsm, fsm2pn);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException(
							"Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = " + this + ", "
									+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[p] = " + p + ", "
									+ "[pn] = " + pn + ", " + "[fsm] = " + fsm + ", " + "[fsm2pn] = " + fsm2pn + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = StateToPlaceRuleImpl
							.pattern_StateToPlaceRule_12_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, Place p, PetriNet pn) {
		match.registerObject("p", p);
		match.registerObject("pn", pn);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, Place p, PetriNet pn) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, Place p, PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p.id", true, csp);
		var_p_id.setValue(p.getId());
		var_p_id.setType("String");

		// Create unbound variables
		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s.name", csp);
		var_s_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_s_name, var_p_id);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("fsm2pn", fsm2pn);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p,
			EObject fsm2pn, EObject s) {
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("pn", pn);
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("s2p", s2p);
		ruleresult.registerObject("fsm2pn", fsm2pn);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("p").eClass()).equals("PetriNets.Place.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_10(EMoflonEdge _edge_places) {
		// prepare return value
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_20_2_testcorematchandDECs_blackFFB(_edge_places)) {
			Place p = (Place) result2_black[0];
			PetriNet pn = (PetriNet) result2_black[1];
			Object[] result2_green = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, p, pn)) {
				// Ensure that the correct types of elements are matched
				if (StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(this,
								match)) {

					// Add match to rule result
					Object[] result5_black = StateToPlaceRuleImpl
							.pattern_StateToPlaceRule_20_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					StateToPlaceRuleImpl.pattern_StateToPlaceRule_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_6(EMoflonEdge _edge_states) {
		// prepare return value
		Object[] result1_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_21_2_testcorematchandDECs_blackFFB(_edge_states)) {
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[0];
			State s = (State) result2_black[1];
			Object[] result2_green = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, fsm, s)) {
				// Ensure that the correct types of elements are matched
				if (StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(this,
								match)) {

					// Add match to rule result
					Object[] result5_black = StateToPlaceRuleImpl
							.pattern_StateToPlaceRule_21_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					StateToPlaceRuleImpl.pattern_StateToPlaceRule_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("StateToPlaceRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p", true, csp);
		var_p_id.setValue(__helper.getValue("p", "id"));
		var_p_id.setType("String");

		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s", true, csp);
		var_s_name.setValue(__helper.getValue("s", "name"));
		var_s_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("StateToPlaceRule");
		eq0.solve(var_s_name, var_p_id);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_p_id.setBound(false);
			eq0.solve(var_s_name, var_p_id);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("p", "id", var_p_id.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("StateToPlaceRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p", true, csp);
		var_p_id.setValue(__helper.getValue("p", "id"));
		var_p_id.setType("String");

		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s", true, csp);
		var_s_name.setValue(__helper.getValue("s", "name"));
		var_s_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("StateToPlaceRule");
		eq0.solve(var_s_name, var_p_id);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_s_name.setBound(false);
			eq0.solve(var_s_name, var_p_id);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("s", "name", var_s_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {
		// prepare
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [prepare] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		// match src trg context
		Object[] result2_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(sourceMatch, targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [match src trg context] failed." + " Variables: "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		Place p = (Place) result2_bindingAndBlack[0];
		PetriNet pn = (PetriNet) result2_bindingAndBlack[1];
		FiniteStateMachine fsm = (FiniteStateMachine) result2_bindingAndBlack[2];
		State s = (State) result2_bindingAndBlack[3];

		// solve csp
		Object[] result3_bindingAndBlack = StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(this, p, pn, fsm, s, sourceMatch,
						targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [solve csp] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[p] = " + p + ", " + "[pn] = " + pn + ", " + "[fsm] = " + fsm + ", " + "[s] = " + s
					+ ", " + "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// check CSP
		if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach match corr context
			for (Object[] result5_black : StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_24_5_matchcorrcontext_blackBBFBB(pn, fsm, sourceMatch, targetMatch)) {
				StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result5_black[2];
				Object[] result5_green = StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_24_5_matchcorrcontext_greenBBBF(fsm2pn, sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[3];

				// create correspondence
				Object[] result6_black = StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_24_6_createcorrespondence_blackBBBBB(p, pn, fsm, s, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching in node [create correspondence] failed."
							+ " Variables: " + "[p] = " + p + ", " + "[pn] = " + pn + ", " + "[fsm] = " + fsm + ", "
							+ "[s] = " + s + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_6_createcorrespondence_greenBFBB(p, s, ccMatch);
				// StateToPlace s2p = (StateToPlace) result6_green[1];

				// add to returned result
				Object[] result7_black = StateToPlaceRuleImpl
						.pattern_StateToPlaceRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching in node [add to returned result] failed."
							+ " Variables: " + "[result] = " + result + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(Place p, PetriNet pn, FiniteStateMachine fsm, State s, Match sourceMatch,
			Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s.name", true, csp);
		var_s_name.setValue(s.getName());
		var_s_name.setType("String");
		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p.id", true, csp);
		var_p_id.setValue(p.getId());
		var_p_id.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_s_name, var_p_id);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(FiniteStateMachine fsm, State s) {// match tgg pattern
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_27_1_matchtggpattern_blackBB(fsm, s);
		if (result1_black != null) {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_27_2_expressionF();
		} else {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(Place p, PetriNet pn) {// match tgg pattern
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_28_1_matchtggpattern_blackBB(p, pn);
		if (result1_black != null) {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_28_2_expressionF();
		} else {
			return StateToPlaceRuleImpl.pattern_StateToPlaceRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer,
			StateMachineToPetriNet fsm2pnParameter) {
		// create result
		Object[] result1_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [create result] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach is applicable core
		for (Object[] result2_black : StateToPlaceRuleImpl
				.pattern_StateToPlaceRule_29_2_isapplicablecore_blackFFFFBB(ruleEntryContainer, ruleResult)) {
			// RuleEntryList fsm2pnList = (RuleEntryList) result2_black[0];
			PetriNet pn = (PetriNet) result2_black[1];
			StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result2_black[2];
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[3];

			// solve CSP
			Object[] result3_bindingAndBlack = StateToPlaceRuleImpl
					.pattern_StateToPlaceRule_29_3_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, pn, fsm,
							fsm2pn, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = "
						+ this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ", " + "[pn] = " + pn + ", "
						+ "[fsm] = " + fsm + ", " + "[fsm2pn] = " + fsm2pn + ", " + "[ruleResult] = " + ruleResult
						+ ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// check CSP
			if (StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// check nacs
				Object[] result5_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_5_checknacs_blackBBB(pn, fsm,
						fsm2pn);
				if (result5_black != null) {

					// perform
					Object[] result6_black = StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_6_perform_blackBBBB(pn,
							fsm, fsm2pn, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [perform] failed." + " Variables: "
								+ "[pn] = " + pn + ", " + "[fsm] = " + fsm + ", " + "[fsm2pn] = " + fsm2pn + ", "
								+ "[ruleResult] = " + ruleResult + ".");
					}
					StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_6_perform_greenFBBFFBB(pn, fsm, ruleResult, csp);
					// Place p = (Place) result6_green[0];
					// StateToPlace s2p = (StateToPlace) result6_green[3];
					// State s = (State) result6_green[4];

				} else {
				}

			} else {
			}

		}
		return StateToPlaceRuleImpl.pattern_StateToPlaceRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_s_name = CSPFactoryHelper.eINSTANCE.createVariable("s.name", csp);
		var_s_name.setType("String");
		Variable var_p_id = CSPFactoryHelper.eINSTANCE.createVariable("p.id", csp);
		var_p_id.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_s_name, var_p_id);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("fsm2pn", fsm2pn);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE:
			return isAppropriate_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2));
		case RulesPackage.STATE_TO_PLACE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2));
			return null;
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (FiniteStateMachine) arguments.get(1),
					(State) arguments.get(2));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_STATE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (PetriNet) arguments.get(1),
					(FiniteStateMachine) arguments.get(2), (StateMachineToPetriNet) arguments.get(3),
					(State) arguments.get(4));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6));
			return null;
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD__MATCH_PLACE_PETRINET:
			return isAppropriate_BWD((Match) arguments.get(0), (Place) arguments.get(1), (PetriNet) arguments.get(2));
		case RulesPackage.STATE_TO_PLACE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PLACE_PETRINET:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (Place) arguments.get(1), (PetriNet) arguments.get(2));
			return null;
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PLACE_PETRINET:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (Place) arguments.get(1),
					(PetriNet) arguments.get(2));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PLACE_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (Place) arguments.get(1),
					(PetriNet) arguments.get(2), (FiniteStateMachine) arguments.get(3),
					(StateMachineToPetriNet) arguments.get(4));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6));
			return null;
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_10__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_10((EMoflonEdge) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_6__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_6((EMoflonEdge) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__PLACE_PETRINET_FINITESTATEMACHINE_STATE_MATCH_MATCH:
			return isApplicable_solveCsp_CC((Place) arguments.get(0), (PetriNet) arguments.get(1),
					(FiniteStateMachine) arguments.get(2), (State) arguments.get(3), (Match) arguments.get(4),
					(Match) arguments.get(5));
		case RulesPackage.STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE:
			return checkDEC_FWD((FiniteStateMachine) arguments.get(0), (State) arguments.get(1));
		case RulesPackage.STATE_TO_PLACE_RULE___CHECK_DEC_BWD__PLACE_PETRINET:
			return checkDEC_BWD((Place) arguments.get(0), (PetriNet) arguments.get(1));
		case RulesPackage.STATE_TO_PLACE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_STATEMACHINETOPETRINET:
			return generateModel((RuleEntryContainer) arguments.get(0), (StateMachineToPetriNet) arguments.get(1));
		case RulesPackage.STATE_TO_PLACE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (PetriNet) arguments.get(1),
					(FiniteStateMachine) arguments.get(2), (StateMachineToPetriNet) arguments.get(3),
					(ModelgeneratorRuleResult) arguments.get(4));
		case RulesPackage.STATE_TO_PLACE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_StateToPlaceRule_0_1_initialbindings_blackBBBB(StateToPlaceRule _this,
			Match match, FiniteStateMachine fsm, State s) {
		return new Object[] { _this, match, fsm, s };
	}

	public static final Object[] pattern_StateToPlaceRule_0_2_SolveCSP_bindingFBBBB(StateToPlaceRule _this, Match match,
			FiniteStateMachine fsm, State s) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, fsm, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, fsm, s };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_0_2_SolveCSP_bindingAndBlackFBBBB(StateToPlaceRule _this,
			Match match, FiniteStateMachine fsm, State s) {
		Object[] result_pattern_StateToPlaceRule_0_2_SolveCSP_binding = pattern_StateToPlaceRule_0_2_SolveCSP_bindingFBBBB(
				_this, match, fsm, s);
		if (result_pattern_StateToPlaceRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_StateToPlaceRule_0_2_SolveCSP_black = pattern_StateToPlaceRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, fsm, s };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_0_3_CheckCSP_expressionFBB(StateToPlaceRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_0_4_collectelementstobetranslated_blackBBB(Match match,
			FiniteStateMachine fsm, State s) {
		return new Object[] { match, fsm, s };
	}

	public static final Object[] pattern_StateToPlaceRule_0_4_collectelementstobetranslated_greenBBBF(Match match,
			FiniteStateMachine fsm, State s) {
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(s);
		String fsm__s____states_name_prime = "states";
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		match.getToBeTranslatedEdges().add(fsm__s____states);
		fsm__s____states.setName(fsm__s____states_name_prime);
		return new Object[] { match, fsm, s, fsm__s____states };
	}

	public static final Object[] pattern_StateToPlaceRule_0_5_collectcontextelements_blackBBB(Match match,
			FiniteStateMachine fsm, State s) {
		return new Object[] { match, fsm, s };
	}

	public static final Object[] pattern_StateToPlaceRule_0_5_collectcontextelements_greenBB(Match match,
			FiniteStateMachine fsm) {
		match.getContextNodes().add(fsm);
		return new Object[] { match, fsm };
	}

	public static final void pattern_StateToPlaceRule_0_6_registerobjectstomatch_expressionBBBB(StateToPlaceRule _this,
			Match match, FiniteStateMachine fsm, State s) {
		_this.registerObjectsToMatch_FWD(match, fsm, s);

	}

	public static final boolean pattern_StateToPlaceRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_1_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("pn");
		EObject _localVariable_1 = isApplicableMatch.getObject("fsm");
		EObject _localVariable_2 = isApplicableMatch.getObject("fsm2pn");
		EObject _localVariable_3 = isApplicableMatch.getObject("s");
		EObject tmpPn = _localVariable_0;
		EObject tmpFsm = _localVariable_1;
		EObject tmpFsm2pn = _localVariable_2;
		EObject tmpS = _localVariable_3;
		if (tmpPn instanceof PetriNet) {
			PetriNet pn = (PetriNet) tmpPn;
			if (tmpFsm instanceof FiniteStateMachine) {
				FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
				if (tmpFsm2pn instanceof StateMachineToPetriNet) {
					StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) tmpFsm2pn;
					if (tmpS instanceof State) {
						State s = (State) tmpS;
						return new Object[] { pn, fsm, fsm2pn, s, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_1_1_performtransformation_blackBBBBFBB(PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn, State s, StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { pn, fsm, fsm2pn, s, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_1_1_performtransformation_bindingAndBlackFFFFFBB(
			StateToPlaceRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_StateToPlaceRule_1_1_performtransformation_binding = pattern_StateToPlaceRule_1_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_StateToPlaceRule_1_1_performtransformation_binding != null) {
			PetriNet pn = (PetriNet) result_pattern_StateToPlaceRule_1_1_performtransformation_binding[0];
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_StateToPlaceRule_1_1_performtransformation_binding[1];
			StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result_pattern_StateToPlaceRule_1_1_performtransformation_binding[2];
			State s = (State) result_pattern_StateToPlaceRule_1_1_performtransformation_binding[3];

			Object[] result_pattern_StateToPlaceRule_1_1_performtransformation_black = pattern_StateToPlaceRule_1_1_performtransformation_blackBBBBFBB(
					pn, fsm, fsm2pn, s, _this, isApplicableMatch);
			if (result_pattern_StateToPlaceRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_StateToPlaceRule_1_1_performtransformation_black[4];

				return new Object[] { pn, fsm, fsm2pn, s, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_1_1_performtransformation_greenFBFBB(PetriNet pn, State s,
			CSP csp) {
		Place p = PetriNetsFactory.eINSTANCE.createPlace();
		StateToPlace s2p = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateToPlace();
		Object _localVariable_0 = csp.getValue("p", "id");
		pn.getPlaces().add(p);
		s2p.setTarget(p);
		s2p.setSource(s);
		String p_id_prime = (String) _localVariable_0;
		p.setId(p_id_prime);
		return new Object[] { p, pn, s2p, s, csp };
	}

	public static final Object[] pattern_StateToPlaceRule_1_2_collecttranslatedelements_blackBBB(Place p,
			StateToPlace s2p, State s) {
		return new Object[] { p, s2p, s };
	}

	public static final Object[] pattern_StateToPlaceRule_1_2_collecttranslatedelements_greenFBBB(Place p,
			StateToPlace s2p, State s) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedElements().add(p);
		ruleresult.getCreatedLinkElements().add(s2p);
		ruleresult.getTranslatedElements().add(s);
		return new Object[] { ruleresult, p, s2p, s };
	}

	public static final Object[] pattern_StateToPlaceRule_1_3_bookkeepingforedges_blackBBBBBBB(
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject fsm2pn, EObject s) {
		if (!p.equals(pn)) {
			if (!p.equals(s2p)) {
				if (!p.equals(s)) {
					if (!pn.equals(s2p)) {
						if (!pn.equals(s)) {
							if (!fsm.equals(p)) {
								if (!fsm.equals(pn)) {
									if (!fsm.equals(s2p)) {
										if (!fsm.equals(fsm2pn)) {
											if (!fsm.equals(s)) {
												if (!fsm2pn.equals(p)) {
													if (!fsm2pn.equals(pn)) {
														if (!fsm2pn.equals(s2p)) {
															if (!fsm2pn.equals(s)) {
																if (!s.equals(s2p)) {
																	return new Object[] { ruleresult, p, pn, fsm, s2p,
																			fsm2pn, s };
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_1_3_bookkeepingforedges_greenBBBBBBFFFF(
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject s) {
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2p__p____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2p__s____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "StateToPlaceRule";
		String pn__p____places_name_prime = "places";
		String fsm__s____states_name_prime = "states";
		String s2p__p____target_name_prime = "target";
		String s2p__s____source_name_prime = "source";
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		ruleresult.getCreatedEdges().add(pn__p____places);
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		ruleresult.getTranslatedEdges().add(fsm__s____states);
		s2p__p____target.setSrc(s2p);
		s2p__p____target.setTrg(p);
		ruleresult.getCreatedEdges().add(s2p__p____target);
		s2p__s____source.setSrc(s2p);
		s2p__s____source.setTrg(s);
		ruleresult.getCreatedEdges().add(s2p__s____source);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		pn__p____places.setName(pn__p____places_name_prime);
		fsm__s____states.setName(fsm__s____states_name_prime);
		s2p__p____target.setName(s2p__p____target_name_prime);
		s2p__s____source.setName(s2p__s____source_name_prime);
		return new Object[] { ruleresult, p, pn, fsm, s2p, s, pn__p____places, fsm__s____states, s2p__p____target,
				s2p__s____source };
	}

	public static final void pattern_StateToPlaceRule_1_5_registerobjects_expressionBBBBBBBB(StateToPlaceRule _this,
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject fsm2pn, EObject s) {
		_this.registerObjects_FWD(ruleresult, p, pn, fsm, s2p, fsm2pn, s);

	}

	public static final PerformRuleResult pattern_StateToPlaceRule_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_2_1_preparereturnvalue_bindingFB(StateToPlaceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			StateToPlaceRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			StateToPlaceRule _this) {
		Object[] result_pattern_StateToPlaceRule_2_1_preparereturnvalue_binding = pattern_StateToPlaceRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_StateToPlaceRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_StateToPlaceRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_StateToPlaceRule_2_1_preparereturnvalue_black = pattern_StateToPlaceRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_StateToPlaceRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_StateToPlaceRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_2_1_preparereturnvalue_greenBF(EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "StateToPlaceRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_StateToPlaceRule_2_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("fsm");
		EObject _localVariable_1 = match.getObject("s");
		EObject tmpFsm = _localVariable_0;
		EObject tmpS = _localVariable_1;
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			if (tmpS instanceof State) {
				State s = (State) tmpS;
				return new Object[] { fsm, s, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_2_2_corematch_blackFBFBB(FiniteStateMachine fsm,
			State s, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (StateMachineToPetriNet fsm2pn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(fsm,
				StateMachineToPetriNet.class, "source")) {
			PetriNet pn = fsm2pn.getTarget();
			if (pn != null) {
				_result.add(new Object[] { pn, fsm, fsm2pn, s, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_2_3_findcontext_blackBBBB(PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn, State s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (fsm.getStates().contains(s)) {
			if (pn.equals(fsm2pn.getTarget())) {
				if (fsm.equals(fsm2pn.getSource())) {
					_result.add(new Object[] { pn, fsm, fsm2pn, s });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_2_3_findcontext_greenBBBBFFFF(PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn, State s) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm2pn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm2pn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String fsm__s____states_name_prime = "states";
		String fsm2pn__pn____target_name_prime = "target";
		String fsm2pn__fsm____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(pn);
		isApplicableMatch.getAllContextElements().add(fsm);
		isApplicableMatch.getAllContextElements().add(fsm2pn);
		isApplicableMatch.getAllContextElements().add(s);
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		isApplicableMatch.getAllContextElements().add(fsm__s____states);
		fsm2pn__pn____target.setSrc(fsm2pn);
		fsm2pn__pn____target.setTrg(pn);
		isApplicableMatch.getAllContextElements().add(fsm2pn__pn____target);
		fsm2pn__fsm____source.setSrc(fsm2pn);
		fsm2pn__fsm____source.setTrg(fsm);
		isApplicableMatch.getAllContextElements().add(fsm2pn__fsm____source);
		fsm__s____states.setName(fsm__s____states_name_prime);
		fsm2pn__pn____target.setName(fsm2pn__pn____target_name_prime);
		fsm2pn__fsm____source.setName(fsm2pn__fsm____source_name_prime);
		return new Object[] { pn, fsm, fsm2pn, s, isApplicableMatch, fsm__s____states, fsm2pn__pn____target,
				fsm2pn__fsm____source };
	}

	public static final Object[] pattern_StateToPlaceRule_2_4_solveCSP_bindingFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn,
			State s) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, pn, fsm, fsm2pn, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, pn, fsm, fsm2pn, s };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_2_4_solveCSP_bindingAndBlackFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn,
			State s) {
		Object[] result_pattern_StateToPlaceRule_2_4_solveCSP_binding = pattern_StateToPlaceRule_2_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, pn, fsm, fsm2pn, s);
		if (result_pattern_StateToPlaceRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_StateToPlaceRule_2_4_solveCSP_black = pattern_StateToPlaceRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, pn, fsm, fsm2pn, s };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_2_5_checkCSP_expressionFBB(StateToPlaceRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "StateToPlaceRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_StateToPlaceRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_10_1_initialbindings_blackBBBB(StateToPlaceRule _this,
			Match match, Place p, PetriNet pn) {
		return new Object[] { _this, match, p, pn };
	}

	public static final Object[] pattern_StateToPlaceRule_10_2_SolveCSP_bindingFBBBB(StateToPlaceRule _this,
			Match match, Place p, PetriNet pn) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, p, pn);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, p, pn };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_10_2_SolveCSP_bindingAndBlackFBBBB(StateToPlaceRule _this,
			Match match, Place p, PetriNet pn) {
		Object[] result_pattern_StateToPlaceRule_10_2_SolveCSP_binding = pattern_StateToPlaceRule_10_2_SolveCSP_bindingFBBBB(
				_this, match, p, pn);
		if (result_pattern_StateToPlaceRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_StateToPlaceRule_10_2_SolveCSP_black = pattern_StateToPlaceRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, p, pn };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_10_3_CheckCSP_expressionFBB(StateToPlaceRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_10_4_collectelementstobetranslated_blackBBB(Match match,
			Place p, PetriNet pn) {
		return new Object[] { match, p, pn };
	}

	public static final Object[] pattern_StateToPlaceRule_10_4_collectelementstobetranslated_greenBBBF(Match match,
			Place p, PetriNet pn) {
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(p);
		String pn__p____places_name_prime = "places";
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		match.getToBeTranslatedEdges().add(pn__p____places);
		pn__p____places.setName(pn__p____places_name_prime);
		return new Object[] { match, p, pn, pn__p____places };
	}

	public static final Object[] pattern_StateToPlaceRule_10_5_collectcontextelements_blackBBB(Match match, Place p,
			PetriNet pn) {
		return new Object[] { match, p, pn };
	}

	public static final Object[] pattern_StateToPlaceRule_10_5_collectcontextelements_greenBB(Match match,
			PetriNet pn) {
		match.getContextNodes().add(pn);
		return new Object[] { match, pn };
	}

	public static final void pattern_StateToPlaceRule_10_6_registerobjectstomatch_expressionBBBB(StateToPlaceRule _this,
			Match match, Place p, PetriNet pn) {
		_this.registerObjectsToMatch_BWD(match, p, pn);

	}

	public static final boolean pattern_StateToPlaceRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_11_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("p");
		EObject _localVariable_1 = isApplicableMatch.getObject("pn");
		EObject _localVariable_2 = isApplicableMatch.getObject("fsm");
		EObject _localVariable_3 = isApplicableMatch.getObject("fsm2pn");
		EObject tmpP = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		EObject tmpFsm = _localVariable_2;
		EObject tmpFsm2pn = _localVariable_3;
		if (tmpP instanceof Place) {
			Place p = (Place) tmpP;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				if (tmpFsm instanceof FiniteStateMachine) {
					FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
					if (tmpFsm2pn instanceof StateMachineToPetriNet) {
						StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) tmpFsm2pn;
						return new Object[] { p, pn, fsm, fsm2pn, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_11_1_performtransformation_blackBBBBFBB(Place p, PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn, StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { p, pn, fsm, fsm2pn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_11_1_performtransformation_bindingAndBlackFFFFFBB(
			StateToPlaceRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_StateToPlaceRule_11_1_performtransformation_binding = pattern_StateToPlaceRule_11_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_StateToPlaceRule_11_1_performtransformation_binding != null) {
			Place p = (Place) result_pattern_StateToPlaceRule_11_1_performtransformation_binding[0];
			PetriNet pn = (PetriNet) result_pattern_StateToPlaceRule_11_1_performtransformation_binding[1];
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_StateToPlaceRule_11_1_performtransformation_binding[2];
			StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) result_pattern_StateToPlaceRule_11_1_performtransformation_binding[3];

			Object[] result_pattern_StateToPlaceRule_11_1_performtransformation_black = pattern_StateToPlaceRule_11_1_performtransformation_blackBBBBFBB(
					p, pn, fsm, fsm2pn, _this, isApplicableMatch);
			if (result_pattern_StateToPlaceRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_StateToPlaceRule_11_1_performtransformation_black[4];

				return new Object[] { p, pn, fsm, fsm2pn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_11_1_performtransformation_greenBBFFB(Place p,
			FiniteStateMachine fsm, CSP csp) {
		StateToPlace s2p = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateToPlace();
		State s = FiniteStateMachinesFactory.eINSTANCE.createState();
		Object _localVariable_0 = csp.getValue("s", "name");
		s2p.setTarget(p);
		fsm.getStates().add(s);
		s2p.setSource(s);
		String s_name_prime = (String) _localVariable_0;
		s.setName(s_name_prime);
		return new Object[] { p, fsm, s2p, s, csp };
	}

	public static final Object[] pattern_StateToPlaceRule_11_2_collecttranslatedelements_blackBBB(Place p,
			StateToPlace s2p, State s) {
		return new Object[] { p, s2p, s };
	}

	public static final Object[] pattern_StateToPlaceRule_11_2_collecttranslatedelements_greenFBBB(Place p,
			StateToPlace s2p, State s) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getTranslatedElements().add(p);
		ruleresult.getCreatedLinkElements().add(s2p);
		ruleresult.getCreatedElements().add(s);
		return new Object[] { ruleresult, p, s2p, s };
	}

	public static final Object[] pattern_StateToPlaceRule_11_3_bookkeepingforedges_blackBBBBBBB(
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject fsm2pn, EObject s) {
		if (!p.equals(pn)) {
			if (!p.equals(s2p)) {
				if (!p.equals(s)) {
					if (!pn.equals(s2p)) {
						if (!pn.equals(s)) {
							if (!fsm.equals(p)) {
								if (!fsm.equals(pn)) {
									if (!fsm.equals(s2p)) {
										if (!fsm.equals(fsm2pn)) {
											if (!fsm.equals(s)) {
												if (!fsm2pn.equals(p)) {
													if (!fsm2pn.equals(pn)) {
														if (!fsm2pn.equals(s2p)) {
															if (!fsm2pn.equals(s)) {
																if (!s.equals(s2p)) {
																	return new Object[] { ruleresult, p, pn, fsm, s2p,
																			fsm2pn, s };
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_11_3_bookkeepingforedges_greenBBBBBBFFFF(
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject s) {
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2p__p____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s2p__s____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "StateToPlaceRule";
		String pn__p____places_name_prime = "places";
		String fsm__s____states_name_prime = "states";
		String s2p__p____target_name_prime = "target";
		String s2p__s____source_name_prime = "source";
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		ruleresult.getTranslatedEdges().add(pn__p____places);
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		ruleresult.getCreatedEdges().add(fsm__s____states);
		s2p__p____target.setSrc(s2p);
		s2p__p____target.setTrg(p);
		ruleresult.getCreatedEdges().add(s2p__p____target);
		s2p__s____source.setSrc(s2p);
		s2p__s____source.setTrg(s);
		ruleresult.getCreatedEdges().add(s2p__s____source);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		pn__p____places.setName(pn__p____places_name_prime);
		fsm__s____states.setName(fsm__s____states_name_prime);
		s2p__p____target.setName(s2p__p____target_name_prime);
		s2p__s____source.setName(s2p__s____source_name_prime);
		return new Object[] { ruleresult, p, pn, fsm, s2p, s, pn__p____places, fsm__s____states, s2p__p____target,
				s2p__s____source };
	}

	public static final void pattern_StateToPlaceRule_11_5_registerobjects_expressionBBBBBBBB(StateToPlaceRule _this,
			PerformRuleResult ruleresult, EObject p, EObject pn, EObject fsm, EObject s2p, EObject fsm2pn, EObject s) {
		_this.registerObjects_BWD(ruleresult, p, pn, fsm, s2p, fsm2pn, s);

	}

	public static final PerformRuleResult pattern_StateToPlaceRule_11_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_12_1_preparereturnvalue_bindingFB(StateToPlaceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			StateToPlaceRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			StateToPlaceRule _this) {
		Object[] result_pattern_StateToPlaceRule_12_1_preparereturnvalue_binding = pattern_StateToPlaceRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_StateToPlaceRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_StateToPlaceRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_StateToPlaceRule_12_1_preparereturnvalue_black = pattern_StateToPlaceRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_StateToPlaceRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_StateToPlaceRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_12_1_preparereturnvalue_greenBF(EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "StateToPlaceRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_StateToPlaceRule_12_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("p");
		EObject _localVariable_1 = match.getObject("pn");
		EObject tmpP = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		if (tmpP instanceof Place) {
			Place p = (Place) tmpP;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				return new Object[] { p, pn, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_12_2_corematch_blackBBFFB(Place p, PetriNet pn,
			Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (StateMachineToPetriNet fsm2pn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(pn,
				StateMachineToPetriNet.class, "target")) {
			FiniteStateMachine fsm = fsm2pn.getSource();
			if (fsm != null) {
				_result.add(new Object[] { p, pn, fsm, fsm2pn, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_12_3_findcontext_blackBBBB(Place p, PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (pn.getPlaces().contains(p)) {
			if (pn.equals(fsm2pn.getTarget())) {
				if (fsm.equals(fsm2pn.getSource())) {
					_result.add(new Object[] { p, pn, fsm, fsm2pn });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_12_3_findcontext_greenBBBBFFFF(Place p, PetriNet pn,
			FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm2pn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm2pn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String pn__p____places_name_prime = "places";
		String fsm2pn__pn____target_name_prime = "target";
		String fsm2pn__fsm____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(pn);
		isApplicableMatch.getAllContextElements().add(fsm);
		isApplicableMatch.getAllContextElements().add(fsm2pn);
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		isApplicableMatch.getAllContextElements().add(pn__p____places);
		fsm2pn__pn____target.setSrc(fsm2pn);
		fsm2pn__pn____target.setTrg(pn);
		isApplicableMatch.getAllContextElements().add(fsm2pn__pn____target);
		fsm2pn__fsm____source.setSrc(fsm2pn);
		fsm2pn__fsm____source.setTrg(fsm);
		isApplicableMatch.getAllContextElements().add(fsm2pn__fsm____source);
		pn__p____places.setName(pn__p____places_name_prime);
		fsm2pn__pn____target.setName(fsm2pn__pn____target_name_prime);
		fsm2pn__fsm____source.setName(fsm2pn__fsm____source_name_prime);
		return new Object[] { p, pn, fsm, fsm2pn, isApplicableMatch, pn__p____places, fsm2pn__pn____target,
				fsm2pn__fsm____source };
	}

	public static final Object[] pattern_StateToPlaceRule_12_4_solveCSP_bindingFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, Place p, PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, p, pn, fsm, fsm2pn);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, p, pn, fsm, fsm2pn };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_12_4_solveCSP_bindingAndBlackFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, Place p, PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn) {
		Object[] result_pattern_StateToPlaceRule_12_4_solveCSP_binding = pattern_StateToPlaceRule_12_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, p, pn, fsm, fsm2pn);
		if (result_pattern_StateToPlaceRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_StateToPlaceRule_12_4_solveCSP_black = pattern_StateToPlaceRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, p, pn, fsm, fsm2pn };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_12_5_checkCSP_expressionFBB(StateToPlaceRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "StateToPlaceRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_StateToPlaceRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_20_1_preparereturnvalue_bindingFB(StateToPlaceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			StateToPlaceRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			StateToPlaceRule _this) {
		Object[] result_pattern_StateToPlaceRule_20_1_preparereturnvalue_binding = pattern_StateToPlaceRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_StateToPlaceRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_StateToPlaceRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_StateToPlaceRule_20_1_preparereturnvalue_black = pattern_StateToPlaceRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_StateToPlaceRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_StateToPlaceRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_StateToPlaceRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_20_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_places) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpPn = _edge_places.getSrc();
		if (tmpPn instanceof PetriNet) {
			PetriNet pn = (PetriNet) tmpPn;
			EObject tmpP = _edge_places.getTrg();
			if (tmpP instanceof Place) {
				Place p = (Place) tmpP;
				if (pn.getPlaces().contains(p)) {
					_result.add(new Object[] { p, pn, _edge_places });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_StateToPlaceRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			StateToPlaceRule _this, Match match, Place p, PetriNet pn) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, p, pn);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			StateToPlaceRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_StateToPlaceRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_21_1_preparereturnvalue_bindingFB(StateToPlaceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			StateToPlaceRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			StateToPlaceRule _this) {
		Object[] result_pattern_StateToPlaceRule_21_1_preparereturnvalue_binding = pattern_StateToPlaceRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_StateToPlaceRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_StateToPlaceRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_StateToPlaceRule_21_1_preparereturnvalue_black = pattern_StateToPlaceRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_StateToPlaceRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_StateToPlaceRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_StateToPlaceRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_21_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_states) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpFsm = _edge_states.getSrc();
		if (tmpFsm instanceof FiniteStateMachine) {
			FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
			EObject tmpS = _edge_states.getTrg();
			if (tmpS instanceof State) {
				State s = (State) tmpS;
				if (fsm.getStates().contains(s)) {
					_result.add(new Object[] { fsm, s, _edge_states });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_StateToPlaceRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			StateToPlaceRule _this, Match match, FiniteStateMachine fsm, State s) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, fsm, s);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			StateToPlaceRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_StateToPlaceRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_24_1_prepare_blackB(StateToPlaceRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_StateToPlaceRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_StateToPlaceRule_24_2_matchsrctrgcontext_bindingFFFFBB(Match targetMatch,
			Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("p");
		EObject _localVariable_1 = targetMatch.getObject("pn");
		EObject _localVariable_2 = sourceMatch.getObject("fsm");
		EObject _localVariable_3 = sourceMatch.getObject("s");
		EObject tmpP = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		EObject tmpFsm = _localVariable_2;
		EObject tmpS = _localVariable_3;
		if (tmpP instanceof Place) {
			Place p = (Place) tmpP;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				if (tmpFsm instanceof FiniteStateMachine) {
					FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
					if (tmpS instanceof State) {
						State s = (State) tmpS;
						return new Object[] { p, pn, fsm, s, targetMatch, sourceMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_24_2_matchsrctrgcontext_blackBBBBBB(Place p, PetriNet pn,
			FiniteStateMachine fsm, State s, Match sourceMatch, Match targetMatch) {
		if (!sourceMatch.equals(targetMatch)) {
			return new Object[] { p, pn, fsm, s, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding = pattern_StateToPlaceRule_24_2_matchsrctrgcontext_bindingFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding != null) {
			Place p = (Place) result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding[0];
			PetriNet pn = (PetriNet) result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding[1];
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding[2];
			State s = (State) result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_binding[3];

			Object[] result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_black = pattern_StateToPlaceRule_24_2_matchsrctrgcontext_blackBBBBBB(
					p, pn, fsm, s, sourceMatch, targetMatch);
			if (result_pattern_StateToPlaceRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { p, pn, fsm, s, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_24_3_solvecsp_bindingFBBBBBBB(StateToPlaceRule _this, Place p,
			PetriNet pn, FiniteStateMachine fsm, State s, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_4 = _this.isApplicable_solveCsp_CC(p, pn, fsm, s, sourceMatch, targetMatch);
		CSP csp = _localVariable_4;
		if (csp != null) {
			return new Object[] { csp, _this, p, pn, fsm, s, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(StateToPlaceRule _this,
			Place p, PetriNet pn, FiniteStateMachine fsm, State s, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_StateToPlaceRule_24_3_solvecsp_binding = pattern_StateToPlaceRule_24_3_solvecsp_bindingFBBBBBBB(
				_this, p, pn, fsm, s, sourceMatch, targetMatch);
		if (result_pattern_StateToPlaceRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_StateToPlaceRule_24_3_solvecsp_black = pattern_StateToPlaceRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, p, pn, fsm, s, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_24_5_matchcorrcontext_blackBBFBB(PetriNet pn,
			FiniteStateMachine fsm, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			for (StateMachineToPetriNet fsm2pn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(pn,
					StateMachineToPetriNet.class, "target")) {
				if (fsm.equals(fsm2pn.getSource())) {
					_result.add(new Object[] { pn, fsm, fsm2pn, sourceMatch, targetMatch });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_24_5_matchcorrcontext_greenBBBF(StateMachineToPetriNet fsm2pn,
			Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "StateToPlaceRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(fsm2pn);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { fsm2pn, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_24_6_createcorrespondence_blackBBBBB(Place p, PetriNet pn,
			FiniteStateMachine fsm, State s, CCMatch ccMatch) {
		return new Object[] { p, pn, fsm, s, ccMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_24_6_createcorrespondence_greenBFBB(Place p, State s,
			CCMatch ccMatch) {
		StateToPlace s2p = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateToPlace();
		s2p.setTarget(p);
		s2p.setSource(s);
		ccMatch.getCreateCorr().add(s2p);
		return new Object[] { p, s2p, s, ccMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_StateToPlaceRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "StateToPlaceRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_StateToPlaceRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_27_1_matchtggpattern_blackBB(FiniteStateMachine fsm,
			State s) {
		if (fsm.getStates().contains(s)) {
			return new Object[] { fsm, s };
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_28_1_matchtggpattern_blackBB(Place p, PetriNet pn) {
		if (pn.getPlaces().contains(p)) {
			return new Object[] { p, pn };
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_StateToPlaceRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_29_1_createresult_blackB(StateToPlaceRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_StateToPlaceRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, PetriNet pn) {
		if (ruleResult.getTargetObjects().contains(pn)) {
			return new Object[] { ruleResult, pn };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, StateMachineToPetriNet fsm2pn) {
		if (ruleResult.getCorrObjects().contains(fsm2pn)) {
			return new Object[] { ruleResult, fsm2pn };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, FiniteStateMachine fsm) {
		if (ruleResult.getSourceObjects().contains(fsm)) {
			return new Object[] { ruleResult, fsm };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_StateToPlaceRule_29_2_isapplicablecore_blackFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList fsm2pnList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpFsm2pn : fsm2pnList.getEntryObjects()) {
				if (tmpFsm2pn instanceof StateMachineToPetriNet) {
					StateMachineToPetriNet fsm2pn = (StateMachineToPetriNet) tmpFsm2pn;
					PetriNet pn = fsm2pn.getTarget();
					if (pn != null) {
						FiniteStateMachine fsm = fsm2pn.getSource();
						if (fsm != null) {
							if (pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_1BB(ruleResult,
									fsm2pn) == null) {
								if (pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_0BB(ruleResult,
										pn) == null) {
									if (pattern_StateToPlaceRule_29_2_isapplicablecore_black_nac_2BB(ruleResult,
											fsm) == null) {
										_result.add(new Object[] { fsm2pnList, pn, fsm2pn, fsm, ruleEntryContainer,
												ruleResult });
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_29_3_solveCSP_bindingFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn,
			ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, pn, fsm, fsm2pn, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, pn, fsm, fsm2pn, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_StateToPlaceRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_StateToPlaceRule_29_3_solveCSP_bindingAndBlackFBBBBBB(StateToPlaceRule _this,
			IsApplicableMatch isApplicableMatch, PetriNet pn, FiniteStateMachine fsm, StateMachineToPetriNet fsm2pn,
			ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_StateToPlaceRule_29_3_solveCSP_binding = pattern_StateToPlaceRule_29_3_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, pn, fsm, fsm2pn, ruleResult);
		if (result_pattern_StateToPlaceRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_StateToPlaceRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_StateToPlaceRule_29_3_solveCSP_black = pattern_StateToPlaceRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_StateToPlaceRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, pn, fsm, fsm2pn, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_StateToPlaceRule_29_4_checkCSP_expressionFBB(StateToPlaceRule _this, CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_StateToPlaceRule_29_5_checknacs_blackBBB(PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn) {
		return new Object[] { pn, fsm, fsm2pn };
	}

	public static final Object[] pattern_StateToPlaceRule_29_6_perform_blackBBBB(PetriNet pn, FiniteStateMachine fsm,
			StateMachineToPetriNet fsm2pn, ModelgeneratorRuleResult ruleResult) {
		return new Object[] { pn, fsm, fsm2pn, ruleResult };
	}

	public static final Object[] pattern_StateToPlaceRule_29_6_perform_greenFBBFFBB(PetriNet pn, FiniteStateMachine fsm,
			ModelgeneratorRuleResult ruleResult, CSP csp) {
		Place p = PetriNetsFactory.eINSTANCE.createPlace();
		StateToPlace s2p = FiniteStatesToPetriNetsFactory.eINSTANCE.createStateToPlace();
		State s = FiniteStateMachinesFactory.eINSTANCE.createState();
		Object _localVariable_0 = csp.getValue("p", "id");
		Object _localVariable_1 = csp.getValue("s", "name");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		pn.getPlaces().add(p);
		ruleResult.getTargetObjects().add(p);
		s2p.setTarget(p);
		ruleResult.getCorrObjects().add(s2p);
		fsm.getStates().add(s);
		s2p.setSource(s);
		ruleResult.getSourceObjects().add(s);
		String p_id_prime = (String) _localVariable_0;
		String s_name_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		p.setId(p_id_prime);
		s.setName(s_name_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { p, pn, fsm, s2p, s, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_StateToPlaceRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //StateToPlaceRuleImpl
