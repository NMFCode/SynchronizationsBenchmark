/**
 */
package FiniteStatesToPetriNets.Rules.impl;

import FiniteStateMachines.FiniteStateMachine;
import FiniteStateMachines.State;

import FiniteStatesToPetriNets.FiniteStatesToPetriNetsFactory;

import FiniteStatesToPetriNets.Rules.EndStateToTransition;
import FiniteStatesToPetriNets.Rules.RulesPackage;

import FiniteStatesToPetriNets.StateMachineToPetriNet;
import FiniteStatesToPetriNets.StateToPlace;

import PetriNets.PetriNet;
import PetriNets.PetriNetsFactory;
import PetriNets.Place;
import PetriNets.Transition;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.csp.*;
import csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>End State To Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class EndStateToTransitionImpl extends AbstractRuleImpl implements EndStateToTransition {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EndStateToTransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.Literals.END_STATE_TO_TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, State s, FiniteStateMachine fsm) {
		// initial bindings
		Object[] result1_black = EndStateToTransitionImpl
				.pattern_EndStateToTransition_0_1_initialbindings_blackBBBB(this, match, s, fsm);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [initial bindings] failed." + " Variables: " + "[this] = " + this + ", "
							+ "[match] = " + match + ", " + "[s] = " + s + ", " + "[fsm] = " + fsm + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_0_2_SolveCSP_bindingAndBlackFBBBB(this, match, s, fsm);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[s] = " + s + ", " + "[fsm] = " + fsm + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (EndStateToTransitionImpl.pattern_EndStateToTransition_0_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = EndStateToTransitionImpl
					.pattern_EndStateToTransition_0_4_collectelementstobetranslated_blackBBB(match, s, fsm);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[s] = " + s + ", " + "[fsm] = " + fsm + ".");
			}

			// collect context elements
			Object[] result5_black = EndStateToTransitionImpl
					.pattern_EndStateToTransition_0_5_collectcontextelements_blackBBB(match, s, fsm);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching in node [collect context elements] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[s] = " + s + ", " + "[fsm] = " + fsm + ".");
			}
			EndStateToTransitionImpl.pattern_EndStateToTransition_0_5_collectcontextelements_greenBBBF(match, s, fsm);
			// EMoflonEdge fsm__s____states = (EMoflonEdge) result5_green[3];

			// register objects to match
			EndStateToTransitionImpl.pattern_EndStateToTransition_0_6_registerobjectstomatch_expressionBBBB(this, match,
					s, fsm);
			return EndStateToTransitionImpl.pattern_EndStateToTransition_0_7_expressionF();
		} else {
			return EndStateToTransitionImpl.pattern_EndStateToTransition_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {
		// [user code injected with eMoflon]

		// TODO: implement this method here but do not remove the injection marker 
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {
		// [user code injected with eMoflon]

		// TODO: implement this method here but do not remove the injection marker 
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, State s, FiniteStateMachine fsm) {
		match.registerObject("s", s);
		match.registerObject("fsm", fsm);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, State s, FiniteStateMachine fsm) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, Transition t, PetriNet pn, Place p) {
		// initial bindings
		Object[] result1_black = EndStateToTransitionImpl
				.pattern_EndStateToTransition_7_1_initialbindings_blackBBBBB(this, match, t, pn, p);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching in node [initial bindings] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[match] = " + match + ", " + "[t] = " + t + ", " + "[pn] = " + pn
					+ ", " + "[p] = " + p + ".");
		}

		// Solve CSP
		Object[] result2_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_7_2_SolveCSP_bindingAndBlackFBBBBB(this, match, t, pn, p);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [Solve CSP] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[match] = " + match + ", " + "[t] = " + t + ", " + "[pn] = " + pn + ", " + "[p] = "
					+ p + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// Check CSP
		if (EndStateToTransitionImpl.pattern_EndStateToTransition_7_3_CheckCSP_expressionFBB(this, csp)) {

			// collect elements to be translated
			Object[] result4_black = EndStateToTransitionImpl
					.pattern_EndStateToTransition_7_4_collectelementstobetranslated_blackBBBB(match, t, pn, p);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching in node [collect elements to be translated] failed."
						+ " Variables: " + "[match] = " + match + ", " + "[t] = " + t + ", " + "[pn] = " + pn + ", "
						+ "[p] = " + p + ".");
			}
			EndStateToTransitionImpl.pattern_EndStateToTransition_7_4_collectelementstobetranslated_greenBBBBFFF(match,
					t, pn, p);
			// EMoflonEdge t__p____from = (EMoflonEdge) result4_green[4];
			// EMoflonEdge p__t____outgoing = (EMoflonEdge) result4_green[5];
			// EMoflonEdge pn__t____transitions = (EMoflonEdge) result4_green[6];

			// collect context elements
			Object[] result5_black = EndStateToTransitionImpl
					.pattern_EndStateToTransition_7_5_collectcontextelements_blackBBBB(match, t, pn, p);
			if (result5_black == null) {
				throw new RuntimeException(
						"Pattern matching in node [collect context elements] failed." + " Variables: " + "[match] = "
								+ match + ", " + "[t] = " + t + ", " + "[pn] = " + pn + ", " + "[p] = " + p + ".");
			}
			EndStateToTransitionImpl.pattern_EndStateToTransition_7_5_collectcontextelements_greenBBBF(match, pn, p);
			// EMoflonEdge pn__p____places = (EMoflonEdge) result5_green[3];

			// register objects to match
			EndStateToTransitionImpl.pattern_EndStateToTransition_7_6_registerobjectstomatch_expressionBBBBB(this,
					match, t, pn, p);
			return EndStateToTransitionImpl.pattern_EndStateToTransition_7_7_expressionF();
		} else {
			return EndStateToTransitionImpl.pattern_EndStateToTransition_7_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {
		// perform transformation
		Object[] result1_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_8_1_performtransformation_bindingAndBlackFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [perform transformation] failed." + " Variables: "
					+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		Transition t = (Transition) result1_bindingAndBlack[0];
		PetriNet pn = (PetriNet) result1_bindingAndBlack[1];
		State s = (State) result1_bindingAndBlack[2];
		StateToPlace sToP = (StateToPlace) result1_bindingAndBlack[3];
		FiniteStateMachine fsm = (FiniteStateMachine) result1_bindingAndBlack[4];
		Place p = (Place) result1_bindingAndBlack[5];
		StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result1_bindingAndBlack[6];
		// CSP csp = (CSP) result1_bindingAndBlack[7];
		Object[] result1_green = EndStateToTransitionImpl
				.pattern_EndStateToTransition_8_1_performtransformation_greenFBB(t, s);
		FiniteStatesToPetriNets.EndStateToTransition sToT = (FiniteStatesToPetriNets.EndStateToTransition) result1_green[0];

		// collect translated elements
		Object[] result2_black = EndStateToTransitionImpl
				.pattern_EndStateToTransition_8_2_collecttranslatedelements_blackBB(sToT, t);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching in node [collect translated elements] failed." + " Variables: "
					+ "[sToT] = " + sToT + ", " + "[t] = " + t + ".");
		}
		Object[] result2_green = EndStateToTransitionImpl
				.pattern_EndStateToTransition_8_2_collecttranslatedelements_greenFBB(sToT, t);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		// bookkeeping for edges
		Object[] result3_black = EndStateToTransitionImpl
				.pattern_EndStateToTransition_8_3_bookkeepingforedges_blackBBBBBBBBB(ruleresult, sToT, t, pn, s, sToP,
						fsm, p, fsmToPn);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching in node [bookkeeping for edges] failed." + " Variables: "
					+ "[ruleresult] = " + ruleresult + ", " + "[sToT] = " + sToT + ", " + "[t] = " + t + ", "
					+ "[pn] = " + pn + ", " + "[s] = " + s + ", " + "[sToP] = " + sToP + ", " + "[fsm] = " + fsm + ", "
					+ "[p] = " + p + ", " + "[fsmToPn] = " + fsmToPn + ".");
		}
		EndStateToTransitionImpl.pattern_EndStateToTransition_8_3_bookkeepingforedges_greenBBBBBBFFFFF(ruleresult, sToT,
				t, pn, s, p);
		// EMoflonEdge t__p____from = (EMoflonEdge) result3_green[6];
		// EMoflonEdge p__t____outgoing = (EMoflonEdge) result3_green[7];
		// EMoflonEdge sToT__t____target = (EMoflonEdge) result3_green[8];
		// EMoflonEdge sToT__s____source = (EMoflonEdge) result3_green[9];
		// EMoflonEdge pn__t____transitions = (EMoflonEdge) result3_green[10];

		// perform postprocessing story node is empty
		// register objects
		EndStateToTransitionImpl.pattern_EndStateToTransition_8_5_registerobjects_expressionBBBBBBBBBB(this, ruleresult,
				sToT, t, pn, s, sToP, fsm, p, fsmToPn);
		return EndStateToTransitionImpl.pattern_EndStateToTransition_8_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {
		// prepare return value
		Object[] result1_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_9_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		// EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = EndStateToTransitionImpl
				.pattern_EndStateToTransition_9_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach core match
		Object[] result2_binding = EndStateToTransitionImpl
				.pattern_EndStateToTransition_9_2_corematch_bindingFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		Transition t = (Transition) result2_binding[0];
		PetriNet pn = (PetriNet) result2_binding[1];
		Place p = (Place) result2_binding[2];
		for (Object[] result2_black : EndStateToTransitionImpl
				.pattern_EndStateToTransition_9_2_corematch_blackBBFFFBFB(t, pn, p, match)) {
			State s = (State) result2_black[2];
			StateToPlace sToP = (StateToPlace) result2_black[3];
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[4];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result2_black[6];
			EndStateToTransitionImpl.pattern_EndStateToTransition_9_2_corematch_greenB(s);

			// ForEach find context
			for (Object[] result3_black : EndStateToTransitionImpl
					.pattern_EndStateToTransition_9_3_findcontext_blackBBBBBBB(t, pn, s, sToP, fsm, p, fsmToPn)) {
				Object[] result3_green = EndStateToTransitionImpl
						.pattern_EndStateToTransition_9_3_findcontext_greenBBBBBBBFFFFFFFFFF(t, pn, s, sToP, fsm, p,
								fsmToPn);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[7];
				// EMoflonEdge t__p____from = (EMoflonEdge) result3_green[8];
				// EMoflonEdge p__t____outgoing = (EMoflonEdge) result3_green[9];
				// EMoflonEdge pn__p____places = (EMoflonEdge) result3_green[10];
				// EMoflonEdge sToP__s____source = (EMoflonEdge) result3_green[11];
				// EMoflonEdge fsmToPn__pn____target = (EMoflonEdge) result3_green[12];
				// EMoflonEdge fsmToPn__fsm____source = (EMoflonEdge) result3_green[13];
				// EMoflonEdge fsm__s____states = (EMoflonEdge) result3_green[14];
				// EMoflonEdge sToP__p____target = (EMoflonEdge) result3_green[15];
				// EMoflonEdge pn__t____transitions = (EMoflonEdge) result3_green[16];

				// solve CSP
				Object[] result4_bindingAndBlack = EndStateToTransitionImpl
						.pattern_EndStateToTransition_9_4_solveCSP_bindingAndBlackFBBBBBBBBB(this, isApplicableMatch, t,
								pn, s, sToP, fsm, p, fsmToPn);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching in node [solve CSP] failed." + " Variables: "
							+ "[this] = " + this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ", " + "[t] = "
							+ t + ", " + "[pn] = " + pn + ", " + "[s] = " + s + ", " + "[sToP] = " + sToP + ", "
							+ "[fsm] = " + fsm + ", " + "[p] = " + p + ", " + "[fsmToPn] = " + fsmToPn + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// check CSP
				if (EndStateToTransitionImpl.pattern_EndStateToTransition_9_5_checkCSP_expressionFBB(this, csp)) {

					// add match to rule result
					Object[] result6_black = EndStateToTransitionImpl
							.pattern_EndStateToTransition_9_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [add match to rule result] failed."
								+ " Variables: " + "[ruleresult] = " + ruleresult + ", " + "[isApplicableMatch] = "
								+ isApplicableMatch + ".");
					}
					EndStateToTransitionImpl.pattern_EndStateToTransition_9_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return EndStateToTransitionImpl.pattern_EndStateToTransition_9_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, Transition t, PetriNet pn, Place p) {
		match.registerObject("t", t);
		match.registerObject("pn", pn);
		match.registerObject("p", p);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, Transition t, PetriNet pn, Place p) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, Transition t, PetriNet pn, State s,
			StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("sToP", sToP);
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("fsmToPn", fsmToPn);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject sToT, EObject t, EObject pn, EObject s,
			EObject sToP, EObject fsm, EObject p, EObject fsmToPn) {
		ruleresult.registerObject("sToT", sToT);
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("pn", pn);
		ruleresult.registerObject("s", s);
		ruleresult.registerObject("sToP", sToP);
		ruleresult.registerObject("fsm", fsm);
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("fsmToPn", fsmToPn);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true
				&& org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("t").eClass()).equals("PetriNets.Transition.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_State_3(State s) {
		// prepare return value
		Object[] result1_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_17_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = EndStateToTransitionImpl.pattern_EndStateToTransition_17_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : EndStateToTransitionImpl
				.pattern_EndStateToTransition_17_2_testcorematchandDECs_blackBF(s)) {
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[1];
			Object[] result2_green = EndStateToTransitionImpl
					.pattern_EndStateToTransition_17_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (EndStateToTransitionImpl
					.pattern_EndStateToTransition_17_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, s, fsm)) {
				// Ensure that the correct types of elements are matched
				if (EndStateToTransitionImpl
						.pattern_EndStateToTransition_17_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = EndStateToTransitionImpl
							.pattern_EndStateToTransition_17_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					EndStateToTransitionImpl.pattern_EndStateToTransition_17_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return EndStateToTransitionImpl.pattern_EndStateToTransition_17_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_9(EMoflonEdge _edge_from) {
		// prepare return value
		Object[] result1_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_18_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [prepare return value] failed." + " Variables: "
					+ "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = EndStateToTransitionImpl.pattern_EndStateToTransition_18_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach test core match and DECs
		for (Object[] result2_black : EndStateToTransitionImpl
				.pattern_EndStateToTransition_18_2_testcorematchandDECs_blackFFFB(_edge_from)) {
			Transition t = (Transition) result2_black[0];
			PetriNet pn = (PetriNet) result2_black[1];
			Place p = (Place) result2_black[2];
			Object[] result2_green = EndStateToTransitionImpl
					.pattern_EndStateToTransition_18_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// bookkeeping with generic isAppropriate method
			if (EndStateToTransitionImpl
					.pattern_EndStateToTransition_18_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(this,
							match, t, pn, p)) {
				// Ensure that the correct types of elements are matched
				if (EndStateToTransitionImpl
						.pattern_EndStateToTransition_18_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					// Add match to rule result
					Object[] result5_black = EndStateToTransitionImpl
							.pattern_EndStateToTransition_18_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching in node [Add match to rule result] failed."
								+ " Variables: " + "[match] = " + match + ", " + "[__performOperation] = "
								+ __performOperation + ", " + "[__result] = " + __result + ", " + "[isApplicableCC] = "
								+ isApplicableCC + ".");
					}
					EndStateToTransitionImpl.pattern_EndStateToTransition_18_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return EndStateToTransitionImpl.pattern_EndStateToTransition_18_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("EndStateToTransition");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		if (!__helper.hasExpectedValue("s", "isEndState", true, ComparingOperator.EQUAL)) {
			ruleResult.setSuccess(false);
			return ruleResult;
		}

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("EndStateToTransition");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		if (!__helper.hasExpectedValue("s", "isEndState", true, ComparingOperator.EQUAL)) {
			ruleResult.setSuccess(false);
			return ruleResult;
		}

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {
		// prepare
		Object[] result1_black = EndStateToTransitionImpl.pattern_EndStateToTransition_21_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [prepare] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = EndStateToTransitionImpl.pattern_EndStateToTransition_21_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		// match src trg context
		Object[] result2_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_21_2_matchsrctrgcontext_bindingAndBlackFFFFFBB(sourceMatch, targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [match src trg context] failed." + " Variables: "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		Transition t = (Transition) result2_bindingAndBlack[0];
		PetriNet pn = (PetriNet) result2_bindingAndBlack[1];
		State s = (State) result2_bindingAndBlack[2];
		FiniteStateMachine fsm = (FiniteStateMachine) result2_bindingAndBlack[3];
		Place p = (Place) result2_bindingAndBlack[4];

		// solve csp
		Object[] result3_bindingAndBlack = EndStateToTransitionImpl
				.pattern_EndStateToTransition_21_3_solvecsp_bindingAndBlackFBBBBBBBB(this, t, pn, s, fsm, p,
						sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching in node [solve csp] failed." + " Variables: " + "[this] = "
					+ this + ", " + "[t] = " + t + ", " + "[pn] = " + pn + ", " + "[s] = " + s + ", " + "[fsm] = " + fsm
					+ ", " + "[p] = " + p + ", " + "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = "
					+ targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// check CSP
		if (EndStateToTransitionImpl.pattern_EndStateToTransition_21_4_checkCSP_expressionFB(csp)) {
			// ForEach match corr context
			for (Object[] result5_black : EndStateToTransitionImpl
					.pattern_EndStateToTransition_21_5_matchcorrcontext_blackBBFBBFBB(pn, s, fsm, p, sourceMatch,
							targetMatch)) {
				StateToPlace sToP = (StateToPlace) result5_black[2];
				StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result5_black[5];
				Object[] result5_green = EndStateToTransitionImpl
						.pattern_EndStateToTransition_21_5_matchcorrcontext_greenBBBBF(sToP, fsmToPn, sourceMatch,
								targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[4];

				// create correspondence
				Object[] result6_black = EndStateToTransitionImpl
						.pattern_EndStateToTransition_21_6_createcorrespondence_blackBBBBBB(t, pn, s, fsm, p, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching in node [create correspondence] failed."
							+ " Variables: " + "[t] = " + t + ", " + "[pn] = " + pn + ", " + "[s] = " + s + ", "
							+ "[fsm] = " + fsm + ", " + "[p] = " + p + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				EndStateToTransitionImpl.pattern_EndStateToTransition_21_6_createcorrespondence_greenFBBB(t, s,
						ccMatch);
				// FiniteStatesToPetriNets.EndStateToTransition sToT = (FiniteStatesToPetriNets.EndStateToTransition) result6_green[0];

				// add to returned result
				Object[] result7_black = EndStateToTransitionImpl
						.pattern_EndStateToTransition_21_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching in node [add to returned result] failed."
							+ " Variables: " + "[result] = " + result + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				EndStateToTransitionImpl.pattern_EndStateToTransition_21_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return EndStateToTransitionImpl.pattern_EndStateToTransition_21_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(Transition t, PetriNet pn, State s, FiniteStateMachine fsm, Place p,
			Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(State s, FiniteStateMachine fsm) {// match tgg pattern
		Object[] result1_black = EndStateToTransitionImpl.pattern_EndStateToTransition_24_1_matchtggpattern_blackBB(s,
				fsm);
		if (result1_black != null) {
			EndStateToTransitionImpl.pattern_EndStateToTransition_24_1_matchtggpattern_greenB(s);

			return EndStateToTransitionImpl.pattern_EndStateToTransition_24_2_expressionF();
		} else {
			return EndStateToTransitionImpl.pattern_EndStateToTransition_24_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(Transition t, PetriNet pn, Place p) {// match tgg pattern
		Object[] result1_black = EndStateToTransitionImpl.pattern_EndStateToTransition_25_1_matchtggpattern_blackBBB(t,
				pn, p);
		if (result1_black != null) {
			return EndStateToTransitionImpl.pattern_EndStateToTransition_25_2_expressionF();
		} else {
			return EndStateToTransitionImpl.pattern_EndStateToTransition_25_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer, StateToPlace sToPParameter) {
		// create result
		Object[] result1_black = EndStateToTransitionImpl.pattern_EndStateToTransition_26_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException(
					"Pattern matching in node [create result] failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = EndStateToTransitionImpl.pattern_EndStateToTransition_26_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach is applicable core
		for (Object[] result2_black : EndStateToTransitionImpl
				.pattern_EndStateToTransition_26_2_isapplicablecore_blackFFFFFFFBB(ruleEntryContainer, ruleResult)) {
			// RuleEntryList sToPList = (RuleEntryList) result2_black[0];
			PetriNet pn = (PetriNet) result2_black[1];
			Place p = (Place) result2_black[2];
			StateToPlace sToP = (StateToPlace) result2_black[3];
			State s = (State) result2_black[4];
			FiniteStateMachine fsm = (FiniteStateMachine) result2_black[5];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result2_black[6];
			EndStateToTransitionImpl.pattern_EndStateToTransition_26_2_isapplicablecore_greenB(s);

			// solve CSP
			Object[] result3_bindingAndBlack = EndStateToTransitionImpl
					.pattern_EndStateToTransition_26_3_solveCSP_bindingAndBlackFBBBBBBBBB(this, isApplicableMatch, pn,
							s, sToP, fsm, p, fsmToPn, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching in node [solve CSP] failed." + " Variables: " + "[this] = "
						+ this + ", " + "[isApplicableMatch] = " + isApplicableMatch + ", " + "[pn] = " + pn + ", "
						+ "[s] = " + s + ", " + "[sToP] = " + sToP + ", " + "[fsm] = " + fsm + ", " + "[p] = " + p
						+ ", " + "[fsmToPn] = " + fsmToPn + ", " + "[ruleResult] = " + ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// check CSP
			if (EndStateToTransitionImpl.pattern_EndStateToTransition_26_4_checkCSP_expressionFBB(this, csp)) {
				// check nacs
				Object[] result5_black = EndStateToTransitionImpl
						.pattern_EndStateToTransition_26_5_checknacs_blackBBBBBB(pn, s, sToP, fsm, p, fsmToPn);
				if (result5_black != null) {
					EndStateToTransitionImpl.pattern_EndStateToTransition_26_5_checknacs_greenB(s);

					// perform
					Object[] result6_black = EndStateToTransitionImpl
							.pattern_EndStateToTransition_26_6_perform_blackBBBBBBB(pn, s, sToP, fsm, p, fsmToPn,
									ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching in node [perform] failed." + " Variables: "
								+ "[pn] = " + pn + ", " + "[s] = " + s + ", " + "[sToP] = " + sToP + ", " + "[fsm] = "
								+ fsm + ", " + "[p] = " + p + ", " + "[fsmToPn] = " + fsmToPn + ", " + "[ruleResult] = "
								+ ruleResult + ".");
					}
					EndStateToTransitionImpl.pattern_EndStateToTransition_26_6_perform_greenFFBBBB(pn, s, p,
							ruleResult);
					// FiniteStatesToPetriNets.EndStateToTransition sToT = (FiniteStatesToPetriNets.EndStateToTransition) result6_green[0];
					// Transition t = (Transition) result6_green[1];

				} else {
				}

			} else {
			}

		}
		return EndStateToTransitionImpl.pattern_EndStateToTransition_26_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, PetriNet pn, State s, StateToPlace sToP,
			FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("pn", pn);
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("sToP", sToP);
		isApplicableMatch.registerObject("fsm", fsm);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("fsmToPn", fsmToPn);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_STATE_FINITESTATEMACHINE:
			return isAppropriate_FWD((Match) arguments.get(0), (State) arguments.get(1),
					(FiniteStateMachine) arguments.get(2));
		case RulesPackage.END_STATE_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_STATE_FINITESTATEMACHINE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (State) arguments.get(1),
					(FiniteStateMachine) arguments.get(2));
			return null;
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_STATE_FINITESTATEMACHINE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (State) arguments.get(1),
					(FiniteStateMachine) arguments.get(2));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PETRINET_PLACE:
			return isAppropriate_BWD((Match) arguments.get(0), (Transition) arguments.get(1),
					(PetriNet) arguments.get(2), (Place) arguments.get(3));
		case RulesPackage.END_STATE_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PETRINET_PLACE:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (Transition) arguments.get(1),
					(PetriNet) arguments.get(2), (Place) arguments.get(3));
			return null;
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PETRINET_PLACE:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (Transition) arguments.get(1),
					(PetriNet) arguments.get(2), (Place) arguments.get(3));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_TRANSITION_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (Transition) arguments.get(1),
					(PetriNet) arguments.get(2), (State) arguments.get(3), (StateToPlace) arguments.get(4),
					(FiniteStateMachine) arguments.get(5), (Place) arguments.get(6),
					(StateMachineToPetriNet) arguments.get(7));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8));
			return null;
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD_STATE_3__STATE:
			return isAppropriate_FWD_State_3((State) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_9__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_9((EMoflonEdge) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__TRANSITION_PETRINET_STATE_FINITESTATEMACHINE_PLACE_MATCH_MATCH:
			return isApplicable_solveCsp_CC((Transition) arguments.get(0), (PetriNet) arguments.get(1),
					(State) arguments.get(2), (FiniteStateMachine) arguments.get(3), (Place) arguments.get(4),
					(Match) arguments.get(5), (Match) arguments.get(6));
		case RulesPackage.END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_DEC_FWD__STATE_FINITESTATEMACHINE:
			return checkDEC_FWD((State) arguments.get(0), (FiniteStateMachine) arguments.get(1));
		case RulesPackage.END_STATE_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PETRINET_PLACE:
			return checkDEC_BWD((Transition) arguments.get(0), (PetriNet) arguments.get(1), (Place) arguments.get(2));
		case RulesPackage.END_STATE_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE:
			return generateModel((RuleEntryContainer) arguments.get(0), (StateToPlace) arguments.get(1));
		case RulesPackage.END_STATE_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (PetriNet) arguments.get(1),
					(State) arguments.get(2), (StateToPlace) arguments.get(3), (FiniteStateMachine) arguments.get(4),
					(Place) arguments.get(5), (StateMachineToPetriNet) arguments.get(6),
					(ModelgeneratorRuleResult) arguments.get(7));
		case RulesPackage.END_STATE_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_EndStateToTransition_0_1_initialbindings_blackBBBB(EndStateToTransition _this,
			Match match, State s, FiniteStateMachine fsm) {
		return new Object[] { _this, match, s, fsm };
	}

	public static final Object[] pattern_EndStateToTransition_0_2_SolveCSP_bindingFBBBB(EndStateToTransition _this,
			Match match, State s, FiniteStateMachine fsm) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, s, fsm);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, s, fsm };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_EndStateToTransition_0_2_SolveCSP_bindingAndBlackFBBBB(
			EndStateToTransition _this, Match match, State s, FiniteStateMachine fsm) {
		Object[] result_pattern_EndStateToTransition_0_2_SolveCSP_binding = pattern_EndStateToTransition_0_2_SolveCSP_bindingFBBBB(
				_this, match, s, fsm);
		if (result_pattern_EndStateToTransition_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_EndStateToTransition_0_2_SolveCSP_binding[0];

			Object[] result_pattern_EndStateToTransition_0_2_SolveCSP_black = pattern_EndStateToTransition_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_EndStateToTransition_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, s, fsm };
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_0_3_CheckCSP_expressionFBB(EndStateToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_0_4_collectelementstobetranslated_blackBBB(Match match,
			State s, FiniteStateMachine fsm) {
		return new Object[] { match, s, fsm };
	}

	public static final Object[] pattern_EndStateToTransition_0_5_collectcontextelements_blackBBB(Match match, State s,
			FiniteStateMachine fsm) {
		return new Object[] { match, s, fsm };
	}

	public static final Object[] pattern_EndStateToTransition_0_5_collectcontextelements_greenBBBF(Match match, State s,
			FiniteStateMachine fsm) {
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(s);
		match.getContextNodes().add(fsm);
		String fsm__s____states_name_prime = "states";
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		match.getContextEdges().add(fsm__s____states);
		fsm__s____states.setName(fsm__s____states_name_prime);
		return new Object[] { match, s, fsm, fsm__s____states };
	}

	public static final void pattern_EndStateToTransition_0_6_registerobjectstomatch_expressionBBBB(
			EndStateToTransition _this, Match match, State s, FiniteStateMachine fsm) {
		_this.registerObjectsToMatch_FWD(match, s, fsm);

	}

	public static final boolean pattern_EndStateToTransition_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_7_1_initialbindings_blackBBBBB(EndStateToTransition _this,
			Match match, Transition t, PetriNet pn, Place p) {
		return new Object[] { _this, match, t, pn, p };
	}

	public static final Object[] pattern_EndStateToTransition_7_2_SolveCSP_bindingFBBBBB(EndStateToTransition _this,
			Match match, Transition t, PetriNet pn, Place p) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, t, pn, p);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, t, pn, p };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_7_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_EndStateToTransition_7_2_SolveCSP_bindingAndBlackFBBBBB(
			EndStateToTransition _this, Match match, Transition t, PetriNet pn, Place p) {
		Object[] result_pattern_EndStateToTransition_7_2_SolveCSP_binding = pattern_EndStateToTransition_7_2_SolveCSP_bindingFBBBBB(
				_this, match, t, pn, p);
		if (result_pattern_EndStateToTransition_7_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_EndStateToTransition_7_2_SolveCSP_binding[0];

			Object[] result_pattern_EndStateToTransition_7_2_SolveCSP_black = pattern_EndStateToTransition_7_2_SolveCSP_blackB(
					csp);
			if (result_pattern_EndStateToTransition_7_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, t, pn, p };
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_7_3_CheckCSP_expressionFBB(EndStateToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_7_4_collectelementstobetranslated_blackBBBB(Match match,
			Transition t, PetriNet pn, Place p) {
		return new Object[] { match, t, pn, p };
	}

	public static final Object[] pattern_EndStateToTransition_7_4_collectelementstobetranslated_greenBBBBFFF(
			Match match, Transition t, PetriNet pn, Place p) {
		EMoflonEdge t__p____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__t____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__t____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(t);
		String t__p____from_name_prime = "from";
		String p__t____outgoing_name_prime = "outgoing";
		String pn__t____transitions_name_prime = "transitions";
		t__p____from.setSrc(t);
		t__p____from.setTrg(p);
		match.getToBeTranslatedEdges().add(t__p____from);
		p__t____outgoing.setSrc(p);
		p__t____outgoing.setTrg(t);
		match.getToBeTranslatedEdges().add(p__t____outgoing);
		pn__t____transitions.setSrc(pn);
		pn__t____transitions.setTrg(t);
		match.getToBeTranslatedEdges().add(pn__t____transitions);
		t__p____from.setName(t__p____from_name_prime);
		p__t____outgoing.setName(p__t____outgoing_name_prime);
		pn__t____transitions.setName(pn__t____transitions_name_prime);
		return new Object[] { match, t, pn, p, t__p____from, p__t____outgoing, pn__t____transitions };
	}

	public static final Object[] pattern_EndStateToTransition_7_5_collectcontextelements_blackBBBB(Match match,
			Transition t, PetriNet pn, Place p) {
		return new Object[] { match, t, pn, p };
	}

	public static final Object[] pattern_EndStateToTransition_7_5_collectcontextelements_greenBBBF(Match match,
			PetriNet pn, Place p) {
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(pn);
		match.getContextNodes().add(p);
		String pn__p____places_name_prime = "places";
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		match.getContextEdges().add(pn__p____places);
		pn__p____places.setName(pn__p____places_name_prime);
		return new Object[] { match, pn, p, pn__p____places };
	}

	public static final void pattern_EndStateToTransition_7_6_registerobjectstomatch_expressionBBBBB(
			EndStateToTransition _this, Match match, Transition t, PetriNet pn, Place p) {
		_this.registerObjectsToMatch_BWD(match, t, pn, p);

	}

	public static final boolean pattern_EndStateToTransition_7_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_7_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_8_1_performtransformation_bindingFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("t");
		EObject _localVariable_1 = isApplicableMatch.getObject("pn");
		EObject _localVariable_2 = isApplicableMatch.getObject("s");
		EObject _localVariable_3 = isApplicableMatch.getObject("sToP");
		EObject _localVariable_4 = isApplicableMatch.getObject("fsm");
		EObject _localVariable_5 = isApplicableMatch.getObject("p");
		EObject _localVariable_6 = isApplicableMatch.getObject("fsmToPn");
		EObject tmpT = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		EObject tmpS = _localVariable_2;
		EObject tmpSToP = _localVariable_3;
		EObject tmpFsm = _localVariable_4;
		EObject tmpP = _localVariable_5;
		EObject tmpFsmToPn = _localVariable_6;
		if (tmpT instanceof Transition) {
			Transition t = (Transition) tmpT;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				if (tmpS instanceof State) {
					State s = (State) tmpS;
					if (tmpSToP instanceof StateToPlace) {
						StateToPlace sToP = (StateToPlace) tmpSToP;
						if (tmpFsm instanceof FiniteStateMachine) {
							FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
							if (tmpP instanceof Place) {
								Place p = (Place) tmpP;
								if (tmpFsmToPn instanceof StateMachineToPetriNet) {
									StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) tmpFsmToPn;
									return new Object[] { t, pn, s, sToP, fsm, p, fsmToPn, isApplicableMatch };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_8_1_performtransformation_blackBBBBBBBFBB(Transition t,
			PetriNet pn, State s, StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn,
			EndStateToTransition _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { t, pn, s, sToP, fsm, p, fsmToPn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_8_1_performtransformation_bindingAndBlackFFFFFFFFBB(
			EndStateToTransition _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_EndStateToTransition_8_1_performtransformation_binding = pattern_EndStateToTransition_8_1_performtransformation_bindingFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_EndStateToTransition_8_1_performtransformation_binding != null) {
			Transition t = (Transition) result_pattern_EndStateToTransition_8_1_performtransformation_binding[0];
			PetriNet pn = (PetriNet) result_pattern_EndStateToTransition_8_1_performtransformation_binding[1];
			State s = (State) result_pattern_EndStateToTransition_8_1_performtransformation_binding[2];
			StateToPlace sToP = (StateToPlace) result_pattern_EndStateToTransition_8_1_performtransformation_binding[3];
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_EndStateToTransition_8_1_performtransformation_binding[4];
			Place p = (Place) result_pattern_EndStateToTransition_8_1_performtransformation_binding[5];
			StateMachineToPetriNet fsmToPn = (StateMachineToPetriNet) result_pattern_EndStateToTransition_8_1_performtransformation_binding[6];

			Object[] result_pattern_EndStateToTransition_8_1_performtransformation_black = pattern_EndStateToTransition_8_1_performtransformation_blackBBBBBBBFBB(
					t, pn, s, sToP, fsm, p, fsmToPn, _this, isApplicableMatch);
			if (result_pattern_EndStateToTransition_8_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_EndStateToTransition_8_1_performtransformation_black[7];

				return new Object[] { t, pn, s, sToP, fsm, p, fsmToPn, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_8_1_performtransformation_greenFBB(Transition t,
			State s) {
		FiniteStatesToPetriNets.EndStateToTransition sToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createEndStateToTransition();
		boolean s_isEndState_prime = Boolean.valueOf(true);
		sToT.setTarget(t);
		sToT.setSource(s);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		return new Object[] { sToT, t, s };
	}

	public static final Object[] pattern_EndStateToTransition_8_2_collecttranslatedelements_blackBB(
			FiniteStatesToPetriNets.EndStateToTransition sToT, Transition t) {
		return new Object[] { sToT, t };
	}

	public static final Object[] pattern_EndStateToTransition_8_2_collecttranslatedelements_greenFBB(
			FiniteStatesToPetriNets.EndStateToTransition sToT, Transition t) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(sToT);
		ruleresult.getTranslatedElements().add(t);
		return new Object[] { ruleresult, sToT, t };
	}

	public static final Object[] pattern_EndStateToTransition_8_3_bookkeepingforedges_blackBBBBBBBBB(
			PerformRuleResult ruleresult, EObject sToT, EObject t, EObject pn, EObject s, EObject sToP, EObject fsm,
			EObject p, EObject fsmToPn) {
		if (!sToT.equals(t)) {
			if (!pn.equals(sToT)) {
				if (!pn.equals(t)) {
					if (!pn.equals(s)) {
						if (!pn.equals(sToP)) {
							if (!s.equals(sToT)) {
								if (!s.equals(t)) {
									if (!s.equals(sToP)) {
										if (!sToP.equals(sToT)) {
											if (!sToP.equals(t)) {
												if (!fsm.equals(sToT)) {
													if (!fsm.equals(t)) {
														if (!fsm.equals(pn)) {
															if (!fsm.equals(s)) {
																if (!fsm.equals(sToP)) {
																	if (!fsm.equals(p)) {
																		if (!fsm.equals(fsmToPn)) {
																			if (!p.equals(sToT)) {
																				if (!p.equals(t)) {
																					if (!p.equals(pn)) {
																						if (!p.equals(s)) {
																							if (!p.equals(sToP)) {
																								if (!fsmToPn
																										.equals(sToT)) {
																									if (!fsmToPn.equals(
																											t)) {
																										if (!fsmToPn
																												.equals(pn)) {
																											if (!fsmToPn
																													.equals(s)) {
																												if (!fsmToPn
																														.equals(sToP)) {
																													if (!fsmToPn
																															.equals(p)) {
																														return new Object[] {
																																ruleresult,
																																sToT,
																																t,
																																pn,
																																s,
																																sToP,
																																fsm,
																																p,
																																fsmToPn };
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_8_3_bookkeepingforedges_greenBBBBBBFFFFF(
			PerformRuleResult ruleresult, EObject sToT, EObject t, EObject pn, EObject s, EObject p) {
		EMoflonEdge t__p____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__t____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge sToT__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge sToT__s____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__t____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "EndStateToTransition";
		String t__p____from_name_prime = "from";
		String p__t____outgoing_name_prime = "outgoing";
		String sToT__t____target_name_prime = "target";
		String sToT__s____source_name_prime = "source";
		String pn__t____transitions_name_prime = "transitions";
		t__p____from.setSrc(t);
		t__p____from.setTrg(p);
		ruleresult.getTranslatedEdges().add(t__p____from);
		p__t____outgoing.setSrc(p);
		p__t____outgoing.setTrg(t);
		ruleresult.getTranslatedEdges().add(p__t____outgoing);
		sToT__t____target.setSrc(sToT);
		sToT__t____target.setTrg(t);
		ruleresult.getCreatedEdges().add(sToT__t____target);
		sToT__s____source.setSrc(sToT);
		sToT__s____source.setTrg(s);
		ruleresult.getCreatedEdges().add(sToT__s____source);
		pn__t____transitions.setSrc(pn);
		pn__t____transitions.setTrg(t);
		ruleresult.getTranslatedEdges().add(pn__t____transitions);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		t__p____from.setName(t__p____from_name_prime);
		p__t____outgoing.setName(p__t____outgoing_name_prime);
		sToT__t____target.setName(sToT__t____target_name_prime);
		sToT__s____source.setName(sToT__s____source_name_prime);
		pn__t____transitions.setName(pn__t____transitions_name_prime);
		return new Object[] { ruleresult, sToT, t, pn, s, p, t__p____from, p__t____outgoing, sToT__t____target,
				sToT__s____source, pn__t____transitions };
	}

	public static final void pattern_EndStateToTransition_8_5_registerobjects_expressionBBBBBBBBBB(
			EndStateToTransition _this, PerformRuleResult ruleresult, EObject sToT, EObject t, EObject pn, EObject s,
			EObject sToP, EObject fsm, EObject p, EObject fsmToPn) {
		_this.registerObjects_BWD(ruleresult, sToT, t, pn, s, sToP, fsm, p, fsmToPn);

	}

	public static final PerformRuleResult pattern_EndStateToTransition_8_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_9_1_preparereturnvalue_bindingFB(
			EndStateToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_9_1_preparereturnvalue_blackFBB(EClass eClass,
			EndStateToTransition _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_9_1_preparereturnvalue_bindingAndBlackFFB(
			EndStateToTransition _this) {
		Object[] result_pattern_EndStateToTransition_9_1_preparereturnvalue_binding = pattern_EndStateToTransition_9_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_EndStateToTransition_9_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_EndStateToTransition_9_1_preparereturnvalue_binding[0];

			Object[] result_pattern_EndStateToTransition_9_1_preparereturnvalue_black = pattern_EndStateToTransition_9_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_EndStateToTransition_9_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_EndStateToTransition_9_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_9_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "EndStateToTransition";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_EndStateToTransition_9_2_corematch_bindingFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("t");
		EObject _localVariable_1 = match.getObject("pn");
		EObject _localVariable_2 = match.getObject("p");
		EObject tmpT = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		EObject tmpP = _localVariable_2;
		if (tmpT instanceof Transition) {
			Transition t = (Transition) tmpT;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				if (tmpP instanceof Place) {
					Place p = (Place) tmpP;
					return new Object[] { t, pn, p, match };
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_9_2_corematch_blackBBFFFBFB(Transition t,
			PetriNet pn, Place p, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(pn,
				StateMachineToPetriNet.class, "target")) {
			FiniteStateMachine fsm = fsmToPn.getSource();
			if (fsm != null) {
				for (StateToPlace sToP : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(p,
						StateToPlace.class, "target")) {
					State s = sToP.getSource();
					if (s != null) {
						_result.add(new Object[] { t, pn, s, sToP, fsm, p, fsmToPn, match });
					}

				}
			}

		}
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_9_2_corematch_greenB(State s) {
		boolean s_isEndState_prime = Boolean.valueOf(true);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		return new Object[] { s };
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_9_3_findcontext_blackBBBBBBB(Transition t,
			PetriNet pn, State s, StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (t.getFrom().contains(p)) {
			if (pn.getPlaces().contains(p)) {
				if (s.equals(sToP.getSource())) {
					if (pn.equals(fsmToPn.getTarget())) {
						if (fsm.equals(fsmToPn.getSource())) {
							if (fsm.getStates().contains(s)) {
								if (p.equals(sToP.getTarget())) {
									if (pn.getTransitions().contains(t)) {
										_result.add(new Object[] { t, pn, s, sToP, fsm, p, fsmToPn });
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_9_3_findcontext_greenBBBBBBBFFFFFFFFFF(Transition t,
			PetriNet pn, State s, StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge t__p____from = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__t____outgoing = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__p____places = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge sToP__s____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__pn____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsmToPn__fsm____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge fsm__s____states = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge sToP__p____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge pn__t____transitions = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		boolean s_isEndState_prime = Boolean.valueOf(true);
		String t__p____from_name_prime = "from";
		String p__t____outgoing_name_prime = "outgoing";
		String pn__p____places_name_prime = "places";
		String sToP__s____source_name_prime = "source";
		String fsmToPn__pn____target_name_prime = "target";
		String fsmToPn__fsm____source_name_prime = "source";
		String fsm__s____states_name_prime = "states";
		String sToP__p____target_name_prime = "target";
		String pn__t____transitions_name_prime = "transitions";
		isApplicableMatch.getAllContextElements().add(t);
		isApplicableMatch.getAllContextElements().add(pn);
		isApplicableMatch.getAllContextElements().add(s);
		isApplicableMatch.getAllContextElements().add(sToP);
		isApplicableMatch.getAllContextElements().add(fsm);
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(fsmToPn);
		t__p____from.setSrc(t);
		t__p____from.setTrg(p);
		isApplicableMatch.getAllContextElements().add(t__p____from);
		p__t____outgoing.setSrc(p);
		p__t____outgoing.setTrg(t);
		isApplicableMatch.getAllContextElements().add(p__t____outgoing);
		pn__p____places.setSrc(pn);
		pn__p____places.setTrg(p);
		isApplicableMatch.getAllContextElements().add(pn__p____places);
		sToP__s____source.setSrc(sToP);
		sToP__s____source.setTrg(s);
		isApplicableMatch.getAllContextElements().add(sToP__s____source);
		fsmToPn__pn____target.setSrc(fsmToPn);
		fsmToPn__pn____target.setTrg(pn);
		isApplicableMatch.getAllContextElements().add(fsmToPn__pn____target);
		fsmToPn__fsm____source.setSrc(fsmToPn);
		fsmToPn__fsm____source.setTrg(fsm);
		isApplicableMatch.getAllContextElements().add(fsmToPn__fsm____source);
		fsm__s____states.setSrc(fsm);
		fsm__s____states.setTrg(s);
		isApplicableMatch.getAllContextElements().add(fsm__s____states);
		sToP__p____target.setSrc(sToP);
		sToP__p____target.setTrg(p);
		isApplicableMatch.getAllContextElements().add(sToP__p____target);
		pn__t____transitions.setSrc(pn);
		pn__t____transitions.setTrg(t);
		isApplicableMatch.getAllContextElements().add(pn__t____transitions);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		t__p____from.setName(t__p____from_name_prime);
		p__t____outgoing.setName(p__t____outgoing_name_prime);
		pn__p____places.setName(pn__p____places_name_prime);
		sToP__s____source.setName(sToP__s____source_name_prime);
		fsmToPn__pn____target.setName(fsmToPn__pn____target_name_prime);
		fsmToPn__fsm____source.setName(fsmToPn__fsm____source_name_prime);
		fsm__s____states.setName(fsm__s____states_name_prime);
		sToP__p____target.setName(sToP__p____target_name_prime);
		pn__t____transitions.setName(pn__t____transitions_name_prime);
		return new Object[] { t, pn, s, sToP, fsm, p, fsmToPn, isApplicableMatch, t__p____from, p__t____outgoing,
				pn__p____places, sToP__s____source, fsmToPn__pn____target, fsmToPn__fsm____source, fsm__s____states,
				sToP__p____target, pn__t____transitions };
	}

	public static final Object[] pattern_EndStateToTransition_9_4_solveCSP_bindingFBBBBBBBBB(EndStateToTransition _this,
			IsApplicableMatch isApplicableMatch, Transition t, PetriNet pn, State s, StateToPlace sToP,
			FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, t, pn, s, sToP, fsm, p, fsmToPn);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, t, pn, s, sToP, fsm, p, fsmToPn };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_9_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_EndStateToTransition_9_4_solveCSP_bindingAndBlackFBBBBBBBBB(
			EndStateToTransition _this, IsApplicableMatch isApplicableMatch, Transition t, PetriNet pn, State s,
			StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {
		Object[] result_pattern_EndStateToTransition_9_4_solveCSP_binding = pattern_EndStateToTransition_9_4_solveCSP_bindingFBBBBBBBBB(
				_this, isApplicableMatch, t, pn, s, sToP, fsm, p, fsmToPn);
		if (result_pattern_EndStateToTransition_9_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_EndStateToTransition_9_4_solveCSP_binding[0];

			Object[] result_pattern_EndStateToTransition_9_4_solveCSP_black = pattern_EndStateToTransition_9_4_solveCSP_blackB(
					csp);
			if (result_pattern_EndStateToTransition_9_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, t, pn, s, sToP, fsm, p, fsmToPn };
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_9_5_checkCSP_expressionFBB(EndStateToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_9_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_EndStateToTransition_9_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "EndStateToTransition";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_EndStateToTransition_9_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_17_1_preparereturnvalue_bindingFB(
			EndStateToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_17_1_preparereturnvalue_blackFBBF(EClass __eClass,
			EndStateToTransition _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_17_1_preparereturnvalue_bindingAndBlackFFBF(
			EndStateToTransition _this) {
		Object[] result_pattern_EndStateToTransition_17_1_preparereturnvalue_binding = pattern_EndStateToTransition_17_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_EndStateToTransition_17_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_EndStateToTransition_17_1_preparereturnvalue_binding[0];

			Object[] result_pattern_EndStateToTransition_17_1_preparereturnvalue_black = pattern_EndStateToTransition_17_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_EndStateToTransition_17_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_EndStateToTransition_17_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_EndStateToTransition_17_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_17_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_17_2_testcorematchandDECs_blackBF(State s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		boolean s_isEndState = s.isIsEndState();
		if (Boolean.valueOf(s_isEndState).equals(Boolean.valueOf(true))) {
			for (FiniteStateMachine fsm : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s,
					FiniteStateMachine.class, "states")) {
				_result.add(new Object[] { s, fsm });
			}
		}

		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_17_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_EndStateToTransition_17_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			EndStateToTransition _this, Match match, State s, FiniteStateMachine fsm) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, s, fsm);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_17_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			EndStateToTransition _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_17_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_17_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_EndStateToTransition_17_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_18_1_preparereturnvalue_bindingFB(
			EndStateToTransition _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_1_preparereturnvalue_blackFBBF(EClass __eClass,
			EndStateToTransition _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_1_preparereturnvalue_bindingAndBlackFFBF(
			EndStateToTransition _this) {
		Object[] result_pattern_EndStateToTransition_18_1_preparereturnvalue_binding = pattern_EndStateToTransition_18_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_EndStateToTransition_18_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_EndStateToTransition_18_1_preparereturnvalue_binding[0];

			Object[] result_pattern_EndStateToTransition_18_1_preparereturnvalue_black = pattern_EndStateToTransition_18_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_EndStateToTransition_18_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_EndStateToTransition_18_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_EndStateToTransition_18_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Object[] pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_0BB(Transition t,
			Place p) {
		for (Place __DEC_t_from_687552 : t.getFrom()) {
			if (!p.equals(__DEC_t_from_687552)) {
				return new Object[] { t, p };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_1BB(Transition t,
			Place p) {
		for (Place __DEC_t_to_794260 : t.getTo()) {
			if (!p.equals(__DEC_t_to_794260)) {
				return new Object[] { t, p };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_2BB(Transition t,
			Place p) {
		if (t.getTo().contains(p)) {
			return new Object[] { t, p };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_18_2_testcorematchandDECs_blackFFFB(
			EMoflonEdge _edge_from) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpT = _edge_from.getSrc();
		if (tmpT instanceof Transition) {
			Transition t = (Transition) tmpT;
			EObject tmpP = _edge_from.getTrg();
			if (tmpP instanceof Place) {
				Place p = (Place) tmpP;
				if (t.getFrom().contains(p)) {
					if (pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_0BB(t, p) == null) {
						if (pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_1BB(t, p) == null) {
							if (pattern_EndStateToTransition_18_2_testcorematchandDECs_black_nac_2BB(t, p) == null) {
								for (PetriNet pn : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(t,
										PetriNet.class, "transitions")) {
									if (pn.getPlaces().contains(p)) {
										_result.add(new Object[] { t, pn, p, _edge_from });
									}
								}
							}
						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_18_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_EndStateToTransition_18_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(
			EndStateToTransition _this, Match match, Transition t, PetriNet pn, Place p) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, t, pn, p);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_18_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			EndStateToTransition _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_18_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_18_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_EndStateToTransition_18_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_21_1_prepare_blackB(EndStateToTransition _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_EndStateToTransition_21_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_EndStateToTransition_21_2_matchsrctrgcontext_bindingFFFFFBB(Match targetMatch,
			Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("t");
		EObject _localVariable_1 = targetMatch.getObject("pn");
		EObject _localVariable_2 = sourceMatch.getObject("s");
		EObject _localVariable_3 = sourceMatch.getObject("fsm");
		EObject _localVariable_4 = targetMatch.getObject("p");
		EObject tmpT = _localVariable_0;
		EObject tmpPn = _localVariable_1;
		EObject tmpS = _localVariable_2;
		EObject tmpFsm = _localVariable_3;
		EObject tmpP = _localVariable_4;
		if (tmpT instanceof Transition) {
			Transition t = (Transition) tmpT;
			if (tmpPn instanceof PetriNet) {
				PetriNet pn = (PetriNet) tmpPn;
				if (tmpS instanceof State) {
					State s = (State) tmpS;
					if (tmpFsm instanceof FiniteStateMachine) {
						FiniteStateMachine fsm = (FiniteStateMachine) tmpFsm;
						if (tmpP instanceof Place) {
							Place p = (Place) tmpP;
							return new Object[] { t, pn, s, fsm, p, targetMatch, sourceMatch };
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_21_2_matchsrctrgcontext_blackBBBBBBB(Transition t,
			PetriNet pn, State s, FiniteStateMachine fsm, Place p, Match sourceMatch, Match targetMatch) {
		if (!sourceMatch.equals(targetMatch)) {
			boolean s_isEndState = s.isIsEndState();
			if (Boolean.valueOf(s_isEndState).equals(Boolean.valueOf(true))) {
				return new Object[] { t, pn, s, fsm, p, sourceMatch, targetMatch };
			}

		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_21_2_matchsrctrgcontext_bindingAndBlackFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding = pattern_EndStateToTransition_21_2_matchsrctrgcontext_bindingFFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding != null) {
			Transition t = (Transition) result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding[0];
			PetriNet pn = (PetriNet) result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding[1];
			State s = (State) result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding[2];
			FiniteStateMachine fsm = (FiniteStateMachine) result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding[3];
			Place p = (Place) result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_binding[4];

			Object[] result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_black = pattern_EndStateToTransition_21_2_matchsrctrgcontext_blackBBBBBBB(
					t, pn, s, fsm, p, sourceMatch, targetMatch);
			if (result_pattern_EndStateToTransition_21_2_matchsrctrgcontext_black != null) {

				return new Object[] { t, pn, s, fsm, p, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_21_3_solvecsp_bindingFBBBBBBBB(EndStateToTransition _this,
			Transition t, PetriNet pn, State s, FiniteStateMachine fsm, Place p, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_5 = _this.isApplicable_solveCsp_CC(t, pn, s, fsm, p, sourceMatch, targetMatch);
		CSP csp = _localVariable_5;
		if (csp != null) {
			return new Object[] { csp, _this, t, pn, s, fsm, p, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_21_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_EndStateToTransition_21_3_solvecsp_bindingAndBlackFBBBBBBBB(
			EndStateToTransition _this, Transition t, PetriNet pn, State s, FiniteStateMachine fsm, Place p,
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_EndStateToTransition_21_3_solvecsp_binding = pattern_EndStateToTransition_21_3_solvecsp_bindingFBBBBBBBB(
				_this, t, pn, s, fsm, p, sourceMatch, targetMatch);
		if (result_pattern_EndStateToTransition_21_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_EndStateToTransition_21_3_solvecsp_binding[0];

			Object[] result_pattern_EndStateToTransition_21_3_solvecsp_black = pattern_EndStateToTransition_21_3_solvecsp_blackB(
					csp);
			if (result_pattern_EndStateToTransition_21_3_solvecsp_black != null) {

				return new Object[] { csp, _this, t, pn, s, fsm, p, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_21_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_21_5_matchcorrcontext_blackBBFBBFBB(PetriNet pn,
			State s, FiniteStateMachine fsm, Place p, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			boolean s_isEndState = s.isIsEndState();
			if (Boolean.valueOf(s_isEndState).equals(Boolean.valueOf(true))) {
				for (StateToPlace sToP : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s,
						StateToPlace.class, "source")) {
					if (p.equals(sToP.getTarget())) {
						for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil
								.getOppositeReferenceTyped(pn, StateMachineToPetriNet.class, "target")) {
							if (fsm.equals(fsmToPn.getSource())) {
								_result.add(new Object[] { pn, s, sToP, fsm, p, fsmToPn, sourceMatch, targetMatch });
							}
						}
					}
				}
			}

		}
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_21_5_matchcorrcontext_greenBBBBF(StateToPlace sToP,
			StateMachineToPetriNet fsmToPn, Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "EndStateToTransition";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(sToP);
		ccMatch.getAllContextElements().add(fsmToPn);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { sToP, fsmToPn, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_EndStateToTransition_21_6_createcorrespondence_blackBBBBBB(Transition t,
			PetriNet pn, State s, FiniteStateMachine fsm, Place p, CCMatch ccMatch) {
		return new Object[] { t, pn, s, fsm, p, ccMatch };
	}

	public static final Object[] pattern_EndStateToTransition_21_6_createcorrespondence_greenFBBB(Transition t, State s,
			CCMatch ccMatch) {
		FiniteStatesToPetriNets.EndStateToTransition sToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createEndStateToTransition();
		sToT.setTarget(t);
		sToT.setSource(s);
		ccMatch.getCreateCorr().add(sToT);
		return new Object[] { sToT, t, s, ccMatch };
	}

	public static final Object[] pattern_EndStateToTransition_21_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_EndStateToTransition_21_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "EndStateToTransition";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_EndStateToTransition_21_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_24_1_matchtggpattern_blackBB(State s,
			FiniteStateMachine fsm) {
		if (fsm.getStates().contains(s)) {
			return new Object[] { s, fsm };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_24_1_matchtggpattern_greenB(State s) {
		boolean s_isEndState_prime = Boolean.valueOf(true);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		return new Object[] { s };
	}

	public static final boolean pattern_EndStateToTransition_24_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_24_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_0BB(Transition t,
			Place p) {
		for (Place __DEC_t_from_860027 : t.getFrom()) {
			if (!p.equals(__DEC_t_from_860027)) {
				return new Object[] { t, p };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_1BB(Transition t,
			Place p) {
		for (Place __DEC_t_to_492673 : t.getTo()) {
			if (!p.equals(__DEC_t_to_492673)) {
				return new Object[] { t, p };
			}
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_2BB(Transition t,
			Place p) {
		if (t.getTo().contains(p)) {
			return new Object[] { t, p };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_25_1_matchtggpattern_blackBBB(Transition t, PetriNet pn,
			Place p) {
		if (t.getFrom().contains(p)) {
			if (pn.getPlaces().contains(p)) {
				if (pn.getTransitions().contains(t)) {
					if (pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_0BB(t, p) == null) {
						if (pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_1BB(t, p) == null) {
							if (pattern_EndStateToTransition_25_1_matchtggpattern_black_nac_2BB(t, p) == null) {
								return new Object[] { t, pn, p };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_25_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_EndStateToTransition_25_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_26_1_createresult_blackB(EndStateToTransition _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_EndStateToTransition_26_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, PetriNet pn) {
		if (ruleResult.getTargetObjects().contains(pn)) {
			return new Object[] { ruleResult, pn };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, Place p) {
		if (ruleResult.getTargetObjects().contains(p)) {
			return new Object[] { ruleResult, p };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, StateToPlace sToP) {
		if (ruleResult.getCorrObjects().contains(sToP)) {
			return new Object[] { ruleResult, sToP };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_3BB(
			ModelgeneratorRuleResult ruleResult, State s) {
		if (ruleResult.getSourceObjects().contains(s)) {
			return new Object[] { ruleResult, s };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_4BB(
			ModelgeneratorRuleResult ruleResult, FiniteStateMachine fsm) {
		if (ruleResult.getSourceObjects().contains(fsm)) {
			return new Object[] { ruleResult, fsm };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_5BB(
			ModelgeneratorRuleResult ruleResult, StateMachineToPetriNet fsmToPn) {
		if (ruleResult.getCorrObjects().contains(fsmToPn)) {
			return new Object[] { ruleResult, fsmToPn };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_EndStateToTransition_26_2_isapplicablecore_blackFFFFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList sToPList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpSToP : sToPList.getEntryObjects()) {
				if (tmpSToP instanceof StateToPlace) {
					StateToPlace sToP = (StateToPlace) tmpSToP;
					Place p = sToP.getTarget();
					if (p != null) {
						State s = sToP.getSource();
						if (s != null) {
							if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_2BB(ruleResult,
									sToP) == null) {
								if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_1BB(ruleResult,
										p) == null) {
									if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_3BB(ruleResult,
											s) == null) {
										for (PetriNet pn : org.moflon.core.utilities.eMoflonEMFUtil
												.getOppositeReferenceTyped(p, PetriNet.class, "places")) {
											if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_0BB(
													ruleResult, pn) == null) {
												for (FiniteStateMachine fsm : org.moflon.core.utilities.eMoflonEMFUtil
														.getOppositeReferenceTyped(s, FiniteStateMachine.class,
																"states")) {
													if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_4BB(
															ruleResult, fsm) == null) {
														for (StateMachineToPetriNet fsmToPn : org.moflon.core.utilities.eMoflonEMFUtil
																.getOppositeReferenceTyped(pn,
																		StateMachineToPetriNet.class, "target")) {
															if (fsm.equals(fsmToPn.getSource())) {
																if (pattern_EndStateToTransition_26_2_isapplicablecore_black_nac_5BB(
																		ruleResult, fsmToPn) == null) {
																	_result.add(new Object[] { sToPList, pn, p, sToP, s,
																			fsm, fsmToPn, ruleEntryContainer,
																			ruleResult });
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_26_2_isapplicablecore_greenB(State s) {
		boolean s_isEndState_prime = Boolean.valueOf(true);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		return new Object[] { s };
	}

	public static final Object[] pattern_EndStateToTransition_26_3_solveCSP_bindingFBBBBBBBBB(
			EndStateToTransition _this, IsApplicableMatch isApplicableMatch, PetriNet pn, State s, StateToPlace sToP,
			FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn, ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, pn, s, sToP, fsm, p, fsmToPn,
				ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, pn, s, sToP, fsm, p, fsmToPn, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_EndStateToTransition_26_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_EndStateToTransition_26_3_solveCSP_bindingAndBlackFBBBBBBBBB(
			EndStateToTransition _this, IsApplicableMatch isApplicableMatch, PetriNet pn, State s, StateToPlace sToP,
			FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn, ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_EndStateToTransition_26_3_solveCSP_binding = pattern_EndStateToTransition_26_3_solveCSP_bindingFBBBBBBBBB(
				_this, isApplicableMatch, pn, s, sToP, fsm, p, fsmToPn, ruleResult);
		if (result_pattern_EndStateToTransition_26_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_EndStateToTransition_26_3_solveCSP_binding[0];

			Object[] result_pattern_EndStateToTransition_26_3_solveCSP_black = pattern_EndStateToTransition_26_3_solveCSP_blackB(
					csp);
			if (result_pattern_EndStateToTransition_26_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, pn, s, sToP, fsm, p, fsmToPn, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_EndStateToTransition_26_4_checkCSP_expressionFBB(EndStateToTransition _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_EndStateToTransition_26_5_checknacs_blackBBBBBB(PetriNet pn, State s,
			StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn) {
		return new Object[] { pn, s, sToP, fsm, p, fsmToPn };
	}

	public static final Object[] pattern_EndStateToTransition_26_5_checknacs_greenB(State s) {
		boolean s_isEndState_prime = Boolean.valueOf(true);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		return new Object[] { s };
	}

	public static final Object[] pattern_EndStateToTransition_26_6_perform_blackBBBBBBB(PetriNet pn, State s,
			StateToPlace sToP, FiniteStateMachine fsm, Place p, StateMachineToPetriNet fsmToPn,
			ModelgeneratorRuleResult ruleResult) {
		return new Object[] { pn, s, sToP, fsm, p, fsmToPn, ruleResult };
	}

	public static final Object[] pattern_EndStateToTransition_26_6_perform_greenFFBBBB(PetriNet pn, State s, Place p,
			ModelgeneratorRuleResult ruleResult) {
		FiniteStatesToPetriNets.EndStateToTransition sToT = FiniteStatesToPetriNetsFactory.eINSTANCE
				.createEndStateToTransition();
		Transition t = PetriNetsFactory.eINSTANCE.createTransition();
		boolean s_isEndState_prime = Boolean.valueOf(true);
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_0 = ruleResult.getIncrementedPerformCount();
		sToT.setSource(s);
		ruleResult.getCorrObjects().add(sToT);
		t.getFrom().add(p);
		sToT.setTarget(t);
		pn.getTransitions().add(t);
		ruleResult.getTargetObjects().add(t);
		s.setIsEndState(Boolean.valueOf(s_isEndState_prime));
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_0);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { sToT, t, pn, s, p, ruleResult };
	}

	public static final ModelgeneratorRuleResult pattern_EndStateToTransition_26_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //EndStateToTransitionImpl
