/**
 */
package FiniteStatesToPetriNets.Rules;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.moflon.tgg.runtime.RuntimePackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see FiniteStatesToPetriNets.Rules.RulesFactory
 * @model kind="package"
 * @generated
 */
public interface RulesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Rules";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/plugin/FiniteStatesToPetriNets/model/FiniteStatesToPetriNets.ecore#//Rules";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "Rules";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RulesPackage eINSTANCE = FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl.init();

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.Rules.impl.EndStateToTransitionImpl <em>End State To Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.Rules.impl.EndStateToTransitionImpl
	 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getEndStateToTransition()
	 * @generated
	 */
	int END_STATE_TO_TRANSITION = 0;

	/**
	 * The number of structural features of the '<em>End State To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_STATE_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_STATE_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_STATE_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 6;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 7;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 8;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 11;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_TRANSITION_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 14;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 15;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 16;

	/**
	 * The operation id for the '<em>Is Appropriate FWD State 3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD_STATE_3__STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 9</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_9__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 20;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 21;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__TRANSITION_PETRINET_STATE_FINITESTATEMACHINE_PLACE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 22;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_DEC_FWD__STATE_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 24;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 26;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The number of operations of the '<em>End State To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int END_STATE_TO_TRANSITION_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 29;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.Rules.impl.FsmToPetriNetRuleImpl <em>Fsm To Petri Net Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.Rules.impl.FsmToPetriNetRuleImpl
	 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getFsmToPetriNetRule()
	 * @generated
	 */
	int FSM_TO_PETRI_NET_RULE = 1;

	/**
	 * The number of structural features of the '<em>Fsm To Petri Net Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD__MATCH_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate BWD Petri Net 3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD_PETRI_NET_3__PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate FWD Finite State Machine 3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD_FINITE_STATE_MACHINE_3__FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_PETRINET_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___CHECK_DEC_BWD__PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___GENERATE_MODEL__RULEENTRYCONTAINER = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Fsm To Petri Net Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FSM_TO_PETRI_NET_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.Rules.impl.StateToPlaceRuleImpl <em>State To Place Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.Rules.impl.StateToPlaceRuleImpl
	 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getStateToPlaceRule()
	 * @generated
	 */
	int STATE_TO_PLACE_RULE = 2;

	/**
	 * The number of structural features of the '<em>State To Place Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD__MATCH_PLACE_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PLACE_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PLACE_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PLACE_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 10</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_10__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 6</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_6__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__PLACE_PETRINET_FINITESTATEMACHINE_STATE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___CHECK_DEC_BWD__PLACE_PETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_STATEMACHINETOPETRINET = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>State To Place Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_TO_PLACE_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link FiniteStatesToPetriNets.Rules.impl.TransitionToTransitionImpl <em>Transition To Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see FiniteStatesToPetriNets.Rules.impl.TransitionToTransitionImpl
	 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getTransitionToTransition()
	 * @generated
	 */
	int TRANSITION_TO_TRANSITION = 3;

	/**
	 * The number of structural features of the '<em>Transition To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_TRANSITION_STATE_PETRINET_PLACE_STATETOPLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_TRANSITION_PLACE_STATE_PETRINET_PLACE_STATETOPLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 11</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_11__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 7</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD_EMOFLON_EDGE_7__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_STATE_TRANSITION_PLACE_TRANSITION_STATE_PETRINET_PLACE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE_TRANSITION_STATE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PLACE_PETRINET_PLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_STATE_PETRINET_PLACE_STATETOPLACE_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 31;

	/**
	 * The number of operations of the '<em>Transition To Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_TO_TRANSITION_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition <em>End State To Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>End State To Transition</em>'.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition
	 * @generated
	 */
	EClass getEndStateToTransition();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_FWD__Match_State_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getEndStateToTransition__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getEndStateToTransition__RegisterObjectsToMatch_FWD__Match_State_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_solveCsp_FWD__Match_State_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_BWD__Match_Transition_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getEndStateToTransition__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getEndStateToTransition__RegisterObjectsToMatch_BWD__Match_Transition_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.Transition, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, FiniteStatesToPetriNets.StateMachineToPetriNet) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.Transition, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, FiniteStatesToPetriNets.StateMachineToPetriNet)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_Transition_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getEndStateToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_FWD_State_3(FiniteStateMachines.State) <em>Is Appropriate FWD State 3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD State 3</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_FWD_State_3(FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_FWD_State_3__State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_BWD_EMoflonEdge_9(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 9</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 9</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isAppropriate_BWD_EMoflonEdge_9(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsAppropriate_BWD_EMoflonEdge_9__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_solveCsp_CC(PetriNets.Transition, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_solveCsp_CC(PetriNets.Transition, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_solveCsp_CC__Transition_PetriNet_State_FiniteStateMachine_Place_Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getEndStateToTransition__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkDEC_FWD(FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkDEC_FWD(FiniteStateMachines.State, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckDEC_FWD__State_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#checkDEC_BWD(PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#checkDEC_BWD(PetriNets.Transition, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getEndStateToTransition__CheckDEC_BWD__Transition_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateToPlace) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateToPlace)
	 * @generated
	 */
	EOperation getEndStateToTransition__GenerateModel__RuleEntryContainer_StateToPlace();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, FiniteStatesToPetriNets.StateMachineToPetriNet, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStateMachines.FiniteStateMachine, PetriNets.Place, FiniteStatesToPetriNets.StateMachineToPetriNet, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getEndStateToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.EndStateToTransition#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getEndStateToTransition__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule <em>Fsm To Petri Net Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fsm To Petri Net Rule</em>'.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule
	 * @generated
	 */
	EClass getFsmToPetriNetRule();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_FWD__Match_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_BWD__Match_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__RegisterObjectsToMatch_BWD__Match_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_solveCsp_BWD__Match_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_BWD_PetriNet_3(PetriNets.PetriNet) <em>Is Appropriate BWD Petri Net 3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD Petri Net 3</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_BWD_PetriNet_3(PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_BWD_PetriNet_3__PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_FWD_FiniteStateMachine_3(FiniteStateMachines.FiniteStateMachine) <em>Is Appropriate FWD Finite State Machine 3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD Finite State Machine 3</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isAppropriate_FWD_FiniteStateMachine_3(FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsAppropriate_FWD_FiniteStateMachine_3__FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_CC(FiniteStateMachines.FiniteStateMachine, PetriNets.PetriNet, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_solveCsp_CC(FiniteStateMachines.FiniteStateMachine, PetriNets.PetriNet, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_solveCsp_CC__FiniteStateMachine_PetriNet_Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckDEC_FWD__FiniteStateMachine();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkDEC_BWD(PetriNets.PetriNet) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#checkDEC_BWD(PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__CheckDEC_BWD__PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__GenerateModel__RuleEntryContainer();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.FsmToPetriNetRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getFsmToPetriNetRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule <em>State To Place Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State To Place Rule</em>'.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule
	 * @generated
	 */
	EClass getStateToPlaceRule();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_FWD__Match_FiniteStateMachine_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getStateToPlaceRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getStateToPlaceRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet, FiniteStateMachines.State) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getStateToPlaceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_BWD__Match_Place_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getStateToPlaceRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__RegisterObjectsToMatch_BWD__Match_Place_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Place, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_solveCsp_BWD__Match_Place_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.Place, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.Place, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_Place_PetriNet_FiniteStateMachine_StateMachineToPetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getStateToPlaceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_BWD_EMoflonEdge_10(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 10</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 10</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_BWD_EMoflonEdge_10(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_BWD_EMoflonEdge_10__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_FWD_EMoflonEdge_6(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 6</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 6</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isAppropriate_FWD_EMoflonEdge_6(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsAppropriate_FWD_EMoflonEdge_6__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_CC(PetriNets.Place, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_solveCsp_CC(PetriNets.Place, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_solveCsp_CC__Place_PetriNet_FiniteStateMachine_State_Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckDEC_FWD__FiniteStateMachine_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkDEC_BWD(PetriNets.Place, PetriNets.PetriNet) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#checkDEC_BWD(PetriNets.Place, PetriNets.PetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__CheckDEC_BWD__Place_PetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateMachineToPetriNet) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateMachineToPetriNet)
	 * @generated
	 */
	EOperation getStateToPlaceRule__GenerateModel__RuleEntryContainer_StateMachineToPetriNet();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, PetriNets.PetriNet, FiniteStateMachines.FiniteStateMachine, FiniteStatesToPetriNets.StateMachineToPetriNet, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getStateToPlaceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.StateToPlaceRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getStateToPlaceRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition <em>Transition To Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition To Transition</em>'.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition
	 * @generated
	 */
	EClass getTransitionToTransition();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_FWD__Match_FiniteStateMachine_State_Transition_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitionToTransition__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getTransitionToTransition__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State_Transition_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State_Transition_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Place, FiniteStateMachines.Transition, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Place, FiniteStateMachines.Transition, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_Transition_State_PetriNet_Place_StateToPlace();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitionToTransition__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_BWD__Match_Transition_Place_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitionToTransition__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getTransitionToTransition__RegisterObjectsToMatch_BWD__Match_Transition_Place_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_Place_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Transition, PetriNets.Place, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Transition, PetriNets.Place, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Transition_Place_State_PetriNet_Place_StateToPlace();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitionToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_BWD_EMoflonEdge_11(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 11</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 11</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_BWD_EMoflonEdge_11(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_BWD_EMoflonEdge_11__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_FWD_EMoflonEdge_7(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 7</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 7</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isAppropriate_FWD_EMoflonEdge_7(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsAppropriate_FWD_EMoflonEdge_7__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_CC(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, PetriNets.Transition, PetriNets.Place, FiniteStateMachines.Transition, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_solveCsp_CC(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, PetriNets.Transition, PetriNets.Place, FiniteStateMachines.Transition, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_solveCsp_CC__FiniteStateMachine_State_Transition_Place_Transition_State_PetriNet_Place_Match_Match();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkDEC_FWD(FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStateMachines.Transition, FiniteStateMachines.State)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckDEC_FWD__FiniteStateMachine_State_Transition_State();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#checkDEC_BWD(PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#checkDEC_BWD(PetriNets.Transition, PetriNets.Place, PetriNets.PetriNet, PetriNets.Place)
	 * @generated
	 */
	EOperation getTransitionToTransition__CheckDEC_BWD__Transition_Place_PetriNet_Place();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateToPlace) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, FiniteStatesToPetriNets.StateToPlace)
	 * @generated
	 */
	EOperation getTransitionToTransition__GenerateModel__RuleEntryContainer_StateToPlace();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Place, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, FiniteStateMachines.FiniteStateMachine, FiniteStateMachines.State, FiniteStatesToPetriNets.StateToPlace, FiniteStatesToPetriNets.StateMachineToPetriNet, PetriNets.Place, FiniteStateMachines.State, PetriNets.PetriNet, PetriNets.Place, FiniteStatesToPetriNets.StateToPlace, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getTransitionToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_State_PetriNet_Place_StateToPlace_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see FiniteStatesToPetriNets.Rules.TransitionToTransition#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitionToTransition__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RulesFactory getRulesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.Rules.impl.EndStateToTransitionImpl <em>End State To Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.Rules.impl.EndStateToTransitionImpl
		 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getEndStateToTransition()
		 * @generated
		 */
		EClass END_STATE_TO_TRANSITION = eINSTANCE.getEndStateToTransition();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_STATE_FINITESTATEMACHINE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_FWD__Match_State_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Perform FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH = eINSTANCE
				.getEndStateToTransition__Perform_FWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH = eINSTANCE
				.getEndStateToTransition__IsApplicable_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_STATE_FINITESTATEMACHINE = eINSTANCE
				.getEndStateToTransition__RegisterObjectsToMatch_FWD__Match_State_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_STATE_FINITESTATEMACHINE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_solveCsp_FWD__Match_State_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getEndStateToTransition__IsAppropriate_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Check Types FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_TYPES_FWD__MATCH = eINSTANCE
				.getEndStateToTransition__CheckTypes_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PETRINET_PLACE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_BWD__Match_Transition_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Perform BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH = eINSTANCE
				.getEndStateToTransition__Perform_BWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH = eINSTANCE
				.getEndStateToTransition__IsApplicable_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PETRINET_PLACE = eINSTANCE
				.getEndStateToTransition__RegisterObjectsToMatch_BWD__Match_Transition_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PETRINET_PLACE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getEndStateToTransition__IsAppropriate_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_TRANSITION_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET = eINSTANCE
				.getEndStateToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_Transition_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getEndStateToTransition__IsApplicable_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getEndStateToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_TYPES_BWD__MATCH = eINSTANCE
				.getEndStateToTransition__CheckTypes_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD State 3</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_FWD_STATE_3__STATE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_FWD_State_3__State();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD EMoflon Edge 9</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_9__EMOFLONEDGE = eINSTANCE
				.getEndStateToTransition__IsAppropriate_BWD_EMoflonEdge_9__EMoflonEdge();

		/**
		 * The meta object literal for the '<em><b>Check Attributes FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = eINSTANCE
				.getEndStateToTransition__CheckAttributes_FWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Check Attributes BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = eINSTANCE
				.getEndStateToTransition__CheckAttributes_BWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH = eINSTANCE
				.getEndStateToTransition__IsApplicable_CC__Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__TRANSITION_PETRINET_STATE_FINITESTATEMACHINE_PLACE_MATCH_MATCH = eINSTANCE
				.getEndStateToTransition__IsApplicable_solveCsp_CC__Transition_PetriNet_State_FiniteStateMachine_Place_Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP = eINSTANCE
				.getEndStateToTransition__IsApplicable_checkCsp_CC__CSP();

		/**
		 * The meta object literal for the '<em><b>Check DEC FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_DEC_FWD__STATE_FINITESTATEMACHINE = eINSTANCE
				.getEndStateToTransition__CheckDEC_FWD__State_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Check DEC BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PETRINET_PLACE = eINSTANCE
				.getEndStateToTransition__CheckDEC_BWD__Transition_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Generate Model</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE = eINSTANCE
				.getEndStateToTransition__GenerateModel__RuleEntryContainer_StateToPlace();

		/**
		 * The meta object literal for the '<em><b>Generate Model solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_STATE_STATETOPLACE_FINITESTATEMACHINE_PLACE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT = eINSTANCE
				.getEndStateToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_State_StateToPlace_FiniteStateMachine_Place_StateMachineToPetriNet_ModelgeneratorRuleResult();

		/**
		 * The meta object literal for the '<em><b>Generate Model check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation END_STATE_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP = eINSTANCE
				.getEndStateToTransition__GenerateModel_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.Rules.impl.FsmToPetriNetRuleImpl <em>Fsm To Petri Net Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.Rules.impl.FsmToPetriNetRuleImpl
		 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getFsmToPetriNetRule()
		 * @generated
		 */
		EClass FSM_TO_PETRI_NET_RULE = eINSTANCE.getFsmToPetriNetRule();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_FWD__Match_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Perform FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = eINSTANCE
				.getFsmToPetriNetRule__Perform_FWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_FWD__MATCH = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getFsmToPetriNetRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_TYPES_FWD__MATCH = eINSTANCE
				.getFsmToPetriNetRule__CheckTypes_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD__MATCH_PETRINET = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_BWD__Match_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Perform BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = eINSTANCE
				.getFsmToPetriNetRule__Perform_BWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_BWD__MATCH = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PETRINET = eINSTANCE
				.getFsmToPetriNetRule__RegisterObjectsToMatch_BWD__Match_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PETRINET = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_solveCsp_BWD__Match_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getFsmToPetriNetRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_TYPES_BWD__MATCH = eINSTANCE
				.getFsmToPetriNetRule__CheckTypes_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD Petri Net 3</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_BWD_PETRI_NET_3__PETRINET = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_BWD_PetriNet_3__PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD Finite State Machine 3</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPROPRIATE_FWD_FINITE_STATE_MACHINE_3__FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__IsAppropriate_FWD_FiniteStateMachine_3__FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Check Attributes FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = eINSTANCE
				.getFsmToPetriNetRule__CheckAttributes_FWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Check Attributes BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = eINSTANCE
				.getFsmToPetriNetRule__CheckAttributes_BWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CC__MATCH_MATCH = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_CC__Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_PETRINET_MATCH_MATCH = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_solveCsp_CC__FiniteStateMachine_PetriNet_Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = eINSTANCE
				.getFsmToPetriNetRule__IsApplicable_checkCsp_CC__CSP();

		/**
		 * The meta object literal for the '<em><b>Check DEC FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE = eINSTANCE
				.getFsmToPetriNetRule__CheckDEC_FWD__FiniteStateMachine();

		/**
		 * The meta object literal for the '<em><b>Check DEC BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___CHECK_DEC_BWD__PETRINET = eINSTANCE
				.getFsmToPetriNetRule__CheckDEC_BWD__PetriNet();

		/**
		 * The meta object literal for the '<em><b>Generate Model</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___GENERATE_MODEL__RULEENTRYCONTAINER = eINSTANCE
				.getFsmToPetriNetRule__GenerateModel__RuleEntryContainer();

		/**
		 * The meta object literal for the '<em><b>Generate Model solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_MODELGENERATORRULERESULT = eINSTANCE
				.getFsmToPetriNetRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult();

		/**
		 * The meta object literal for the '<em><b>Generate Model check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FSM_TO_PETRI_NET_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = eINSTANCE
				.getFsmToPetriNetRule__GenerateModel_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.Rules.impl.StateToPlaceRuleImpl <em>State To Place Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.Rules.impl.StateToPlaceRuleImpl
		 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getStateToPlaceRule()
		 * @generated
		 */
		EClass STATE_TO_PLACE_RULE = eINSTANCE.getStateToPlaceRule();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_FWD__Match_FiniteStateMachine_State();

		/**
		 * The meta object literal for the '<em><b>Perform FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = eINSTANCE
				.getStateToPlaceRule__Perform_FWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_FWD__MATCH = eINSTANCE
				.getStateToPlaceRule__IsApplicable_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE = eINSTANCE
				.getStateToPlaceRule__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_STATE = eINSTANCE
				.getStateToPlaceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_State();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getStateToPlaceRule__IsApplicable_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getStateToPlaceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_TYPES_FWD__MATCH = eINSTANCE
				.getStateToPlaceRule__CheckTypes_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD__MATCH_PLACE_PETRINET = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_BWD__Match_Place_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Perform BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = eINSTANCE
				.getStateToPlaceRule__Perform_BWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_BWD__MATCH = eINSTANCE
				.getStateToPlaceRule__IsApplicable_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_PLACE_PETRINET = eINSTANCE
				.getStateToPlaceRule__RegisterObjectsToMatch_BWD__Match_Place_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_PLACE_PETRINET = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_solveCsp_BWD__Match_Place_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PLACE_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET = eINSTANCE
				.getStateToPlaceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_Place_PetriNet_FiniteStateMachine_StateMachineToPetriNet();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getStateToPlaceRule__IsApplicable_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getStateToPlaceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_TYPES_BWD__MATCH = eINSTANCE
				.getStateToPlaceRule__CheckTypes_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD EMoflon Edge 10</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_10__EMOFLONEDGE = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_BWD_EMoflonEdge_10__EMoflonEdge();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD EMoflon Edge 6</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_6__EMOFLONEDGE = eINSTANCE
				.getStateToPlaceRule__IsAppropriate_FWD_EMoflonEdge_6__EMoflonEdge();

		/**
		 * The meta object literal for the '<em><b>Check Attributes FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = eINSTANCE
				.getStateToPlaceRule__CheckAttributes_FWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Check Attributes BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = eINSTANCE
				.getStateToPlaceRule__CheckAttributes_BWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = eINSTANCE
				.getStateToPlaceRule__IsApplicable_CC__Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__PLACE_PETRINET_FINITESTATEMACHINE_STATE_MATCH_MATCH = eINSTANCE
				.getStateToPlaceRule__IsApplicable_solveCsp_CC__Place_PetriNet_FiniteStateMachine_State_Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = eINSTANCE
				.getStateToPlaceRule__IsApplicable_checkCsp_CC__CSP();

		/**
		 * The meta object literal for the '<em><b>Check DEC FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE = eINSTANCE
				.getStateToPlaceRule__CheckDEC_FWD__FiniteStateMachine_State();

		/**
		 * The meta object literal for the '<em><b>Check DEC BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___CHECK_DEC_BWD__PLACE_PETRINET = eINSTANCE
				.getStateToPlaceRule__CheckDEC_BWD__Place_PetriNet();

		/**
		 * The meta object literal for the '<em><b>Generate Model</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_STATEMACHINETOPETRINET = eINSTANCE
				.getStateToPlaceRule__GenerateModel__RuleEntryContainer_StateMachineToPetriNet();

		/**
		 * The meta object literal for the '<em><b>Generate Model solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PETRINET_FINITESTATEMACHINE_STATEMACHINETOPETRINET_MODELGENERATORRULERESULT = eINSTANCE
				.getStateToPlaceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PetriNet_FiniteStateMachine_StateMachineToPetriNet_ModelgeneratorRuleResult();

		/**
		 * The meta object literal for the '<em><b>Generate Model check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation STATE_TO_PLACE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = eINSTANCE
				.getStateToPlaceRule__GenerateModel_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '{@link FiniteStatesToPetriNets.Rules.impl.TransitionToTransitionImpl <em>Transition To Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see FiniteStatesToPetriNets.Rules.impl.TransitionToTransitionImpl
		 * @see FiniteStatesToPetriNets.Rules.impl.RulesPackageImpl#getTransitionToTransition()
		 * @generated
		 */
		EClass TRANSITION_TO_TRANSITION = eINSTANCE.getTransitionToTransition();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_FWD__Match_FiniteStateMachine_State_Transition_State();

		/**
		 * The meta object literal for the '<em><b>Perform FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___PERFORM_FWD__ISAPPLICABLEMATCH = eINSTANCE
				.getTransitionToTransition__Perform_FWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_FWD__MATCH = eINSTANCE
				.getTransitionToTransition__IsApplicable_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = eINSTANCE
				.getTransitionToTransition__RegisterObjectsToMatch_FWD__Match_FiniteStateMachine_State_Transition_State();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_FINITESTATEMACHINE_STATE_TRANSITION_STATE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_solveCsp_FWD__Match_FiniteStateMachine_State_Transition_State();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getTransitionToTransition__IsAppropriate_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_TRANSITION_STATE_PETRINET_PLACE_STATETOPLACE = eINSTANCE
				.getTransitionToTransition__IsApplicable_solveCsp_FWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_Transition_State_PetriNet_Place_StateToPlace();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_FWD__CSP = eINSTANCE
				.getTransitionToTransition__IsApplicable_checkCsp_FWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getTransitionToTransition__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_TYPES_FWD__MATCH = eINSTANCE
				.getTransitionToTransition__CheckTypes_FWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_BWD__Match_Transition_Place_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Perform BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___PERFORM_BWD__ISAPPLICABLEMATCH = eINSTANCE
				.getTransitionToTransition__Perform_BWD__IsApplicableMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_BWD__MATCH = eINSTANCE
				.getTransitionToTransition__IsApplicable_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Register Objects To Match BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = eINSTANCE
				.getTransitionToTransition__RegisterObjectsToMatch_BWD__Match_Transition_Place_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_TRANSITION_PLACE_PETRINET_PLACE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_solveCsp_BWD__Match_Transition_Place_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getTransitionToTransition__IsAppropriate_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_TRANSITION_PLACE_STATE_PETRINET_PLACE_STATETOPLACE = eINSTANCE
				.getTransitionToTransition__IsApplicable_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Transition_Place_State_PetriNet_Place_StateToPlace();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_BWD__CSP = eINSTANCE
				.getTransitionToTransition__IsApplicable_checkCsp_BWD__CSP();

		/**
		 * The meta object literal for the '<em><b>Register Objects BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = eINSTANCE
				.getTransitionToTransition__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

		/**
		 * The meta object literal for the '<em><b>Check Types BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_TYPES_BWD__MATCH = eINSTANCE
				.getTransitionToTransition__CheckTypes_BWD__Match();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate BWD EMoflon Edge 11</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_BWD_EMOFLON_EDGE_11__EMOFLONEDGE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_BWD_EMoflonEdge_11__EMoflonEdge();

		/**
		 * The meta object literal for the '<em><b>Is Appropriate FWD EMoflon Edge 7</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPROPRIATE_FWD_EMOFLON_EDGE_7__EMOFLONEDGE = eINSTANCE
				.getTransitionToTransition__IsAppropriate_FWD_EMoflonEdge_7__EMoflonEdge();

		/**
		 * The meta object literal for the '<em><b>Check Attributes FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = eINSTANCE
				.getTransitionToTransition__CheckAttributes_FWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Check Attributes BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = eINSTANCE
				.getTransitionToTransition__CheckAttributes_BWD__TripleMatch();

		/**
		 * The meta object literal for the '<em><b>Is Applicable CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_CC__MATCH_MATCH = eINSTANCE
				.getTransitionToTransition__IsApplicable_CC__Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable solve Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_SOLVE_CSP_CC__FINITESTATEMACHINE_STATE_TRANSITION_PLACE_TRANSITION_STATE_PETRINET_PLACE_MATCH_MATCH = eINSTANCE
				.getTransitionToTransition__IsApplicable_solveCsp_CC__FiniteStateMachine_State_Transition_Place_Transition_State_PetriNet_Place_Match_Match();

		/**
		 * The meta object literal for the '<em><b>Is Applicable check Csp CC</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___IS_APPLICABLE_CHECK_CSP_CC__CSP = eINSTANCE
				.getTransitionToTransition__IsApplicable_checkCsp_CC__CSP();

		/**
		 * The meta object literal for the '<em><b>Check DEC FWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_DEC_FWD__FINITESTATEMACHINE_STATE_TRANSITION_STATE = eINSTANCE
				.getTransitionToTransition__CheckDEC_FWD__FiniteStateMachine_State_Transition_State();

		/**
		 * The meta object literal for the '<em><b>Check DEC BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___CHECK_DEC_BWD__TRANSITION_PLACE_PETRINET_PLACE = eINSTANCE
				.getTransitionToTransition__CheckDEC_BWD__Transition_Place_PetriNet_Place();

		/**
		 * The meta object literal for the '<em><b>Generate Model</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___GENERATE_MODEL__RULEENTRYCONTAINER_STATETOPLACE = eINSTANCE
				.getTransitionToTransition__GenerateModel__RuleEntryContainer_StateToPlace();

		/**
		 * The meta object literal for the '<em><b>Generate Model solve Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_FINITESTATEMACHINE_STATE_STATETOPLACE_STATEMACHINETOPETRINET_PLACE_STATE_PETRINET_PLACE_STATETOPLACE_MODELGENERATORRULERESULT = eINSTANCE
				.getTransitionToTransition__GenerateModel_solveCsp_BWD__IsApplicableMatch_FiniteStateMachine_State_StateToPlace_StateMachineToPetriNet_Place_State_PetriNet_Place_StateToPlace_ModelgeneratorRuleResult();

		/**
		 * The meta object literal for the '<em><b>Generate Model check Csp BWD</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation TRANSITION_TO_TRANSITION___GENERATE_MODEL_CHECK_CSP_BWD__CSP = eINSTANCE
				.getTransitionToTransition__GenerateModel_checkCsp_BWD__CSP();

	}

} //RulesPackage
