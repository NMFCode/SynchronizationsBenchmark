/**
 */
package FiniteStatesToPetriNets.Rules;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see FiniteStatesToPetriNets.Rules.RulesPackage
 * @generated
 */
public interface RulesFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RulesFactory eINSTANCE = FiniteStatesToPetriNets.Rules.impl.RulesFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>End State To Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>End State To Transition</em>'.
	 * @generated
	 */
	EndStateToTransition createEndStateToTransition();

	/**
	 * Returns a new object of class '<em>Fsm To Petri Net Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fsm To Petri Net Rule</em>'.
	 * @generated
	 */
	FsmToPetriNetRule createFsmToPetriNetRule();

	/**
	 * Returns a new object of class '<em>State To Place Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>State To Place Rule</em>'.
	 * @generated
	 */
	StateToPlaceRule createStateToPlaceRule();

	/**
	 * Returns a new object of class '<em>Transition To Transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transition To Transition</em>'.
	 * @generated
	 */
	TransitionToTransition createTransitionToTransition();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	RulesPackage getRulesPackage();

} //RulesFactory
