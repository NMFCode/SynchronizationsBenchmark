/**
 */
package PetriNets;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link PetriNets.Transition#getInput <em>Input</em>}</li>
 *   <li>{@link PetriNets.Transition#getFrom <em>From</em>}</li>
 *   <li>{@link PetriNets.Transition#getTo <em>To</em>}</li>
 * </ul>
 * </p>
 *
 * @see PetriNets.PetriNetsPackage#getTransition()
 * @model
 * @generated
 */
public interface Transition extends EObject {
	/**
	 * Returns the value of the '<em><b>Input</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Input</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input</em>' attribute.
	 * @see #setInput(String)
	 * @see PetriNets.PetriNetsPackage#getTransition_Input()
	 * @model required="true"
	 * @generated
	 */
	String getInput();

	/**
	 * Sets the value of the '{@link PetriNets.Transition#getInput <em>Input</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input</em>' attribute.
	 * @see #getInput()
	 * @generated
	 */
	void setInput(String value);

	/**
	 * Returns the value of the '<em><b>From</b></em>' reference list.
	 * The list contents are of type {@link PetriNets.Place}.
	 * It is bidirectional and its opposite is '{@link PetriNets.Place#getOutgoing <em>Outgoing</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' reference list.
	 * @see PetriNets.PetriNetsPackage#getTransition_From()
	 * @see PetriNets.Place#getOutgoing
	 * @model opposite="outgoing"
	 * @generated
	 */
	EList<Place> getFrom();

	/**
	 * Returns the value of the '<em><b>To</b></em>' reference list.
	 * The list contents are of type {@link PetriNets.Place}.
	 * It is bidirectional and its opposite is '{@link PetriNets.Place#getIncoming <em>Incoming</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference list.
	 * @see PetriNets.PetriNetsPackage#getTransition_To()
	 * @see PetriNets.Place#getIncoming
	 * @model opposite="incoming"
	 * @generated
	 */
	EList<Place> getTo();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // Transition
